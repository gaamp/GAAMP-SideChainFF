#!/bin/bash


icc -O3 -o gen_soft_list_sc gen_soft_list.cpp ff.cpp ../../opt/nlopt-2.4.2/.libs/libnlopt.a

cp gen_soft_list_sc ..
chmod g+rx ../gen_soft_list_sc

