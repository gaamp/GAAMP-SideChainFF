#!/bin/bash

g++ -O3 -o reorganize_aa re-organize.cpp ff.cpp 

cp reorganize_aa ..
chmod g+rx ../reorganize_aa
