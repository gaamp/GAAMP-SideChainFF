#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ff.h"


CMol Mol;
CForceField ff;

void Quit_With_Error_Msg(char szMsg[]);


FILE *fFile_Run_Log;	// will be shared by other source code

int main(void)
{
	fFile_Run_Log = fopen("log-opt-sc.txt", "w");
	if(fFile_Run_Log==NULL)	{
		printf("Fail to create the log file.\n\n");
		exit(1);
	}

	ff.ReadForceField("full.prm");

	Mol.ReadPSF("full.xpsf", 0);
	Mol.AssignForceFieldParameters(&ff);

	Mol.ReadPDB("full-opt.pdb");

	Mol.Cal_E(1);

	Mol.Fix_All_Backbone_Atom = 1;
	Mol.BuildActiveEnergyTermList();
	Mol.FullGeometryOptimization_LBFGS();

	Mol.Fix_All_Backbone_Atom = 0;
	Mol.BuildActiveEnergyTermList();
	Mol.Cal_E(1);

	Mol.SaveCrd("mol-opt.crd");

	fclose(fFile_Run_Log);

	return 0;
}

void Quit_With_Error_Msg(char szMsg[])
{
	fprintf(fFile_Run_Log, "%s", szMsg);
	fflush(fFile_Run_Log);
	exit(1);
}
