#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ATOM	(256)
#define MAX_BOND	(2048)

int nAtom, nBond, SC_Start, SC_End, Out_Start, Out_End;
char Flag_Is_Backbone_Atom[MAX_ATOM];
int Output_Atom[MAX_ATOM];
int BondList[MAX_BOND][3];

char szAtomList[MAX_ATOM][256], szAtomName[MAX_ATOM][16], szAtomName_Out[MAX_ATOM][16], szChemName[MAX_ATOM][16];
double cg_List[MAX_ATOM];

void Generate_RTF(void);
void Generate_PRM(void);
void Identify_All_Backbone_Atoms(void);
int Query_Atom_by_Name(char szName[]);
int Is_A_New_Chem_Type(char szChem[]);	// check '_'
void Quit_With_Message(const char szMsg[]);

int main(void)
{
	Generate_RTF();
	Generate_PRM();



	return 0;
}


void Generate_RTF(void)
{
	FILE *fIn, *fOut;
	char szLine[256], *ReadLine, szTmp[256], szChem[256], szName[256], szName2[256], szRec_Impro[4096];
	double chg=0.0, mass;
	int i, ReadItem, AtomID;

	fIn = fopen("mol-tor.rtf", "r");
	if(fIn == NULL)	{
		Quit_With_Message("Fail to open file: mol-tor.rtf\n");
	}
	fOut = fopen("aa.rtf", "w");

	fprintf(fOut, "* Topology file generated for amino acid side chain \n");
	fprintf(fOut, "* parameter fitting with the program written by Lei Huang.\n\n");

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "RESI MOL", 8)==0)	{
			fprintf(fOut, "\nAUTO ANGLES DIHE\n\n");
	
			fprintf(fOut, "%s", szLine);
			break;
		}
		if(strncmp(szLine, "MASS", 4)==0)	{
			ReadItem = sscanf(szLine, "%s%d%s%lf", szTmp, &AtomID, szChem, &mass);
			if( (ReadItem == 4) && (AtomID > 100) )	{	// new atom types not existing in CHARMM
				fprintf(fOut, "%s", szLine);
			}
		}
	}

	nAtom = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "ATOM", 4)==0)	{
			ReadItem = sscanf(szLine, "%s%s%s%lf", szTmp, szName, szChem, &chg);
			if(ReadItem == 4)	{
				strcpy(szAtomList[nAtom], szLine);
				strcpy(szAtomName[nAtom], szName);
				strcpy(szAtomName_Out[nAtom], szName);
				strcpy(szChemName[nAtom], szChem);
				cg_List[nAtom] = chg;
				nAtom++;
			}
		}
	}

	Identify_All_Backbone_Atoms();

	strcpy(szAtomName_Out[6], "N");
	strcpy(szAtomName_Out[7], "HN");
	strcpy(szAtomName_Out[8], "CA");
	strcpy(szAtomName_Out[9], "HA");

	strcpy(szAtomName_Out[Out_End-1], "C");
	strcpy(szAtomName_Out[Out_End], "O");

	fprintf(fOut, "GROUP\n");
	for(i=6; i<10; i++)	{
		fprintf(fOut, "ATOM %-5s %-8s %8.3lf\n", szAtomName_Out[i], szChemName[i], cg_List[i]);
	}

	fprintf(fOut, "GROUP\n");
	for(i=SC_Start; i<=SC_End; i++)	{
		fprintf(fOut, "%s", szAtomList[i]);
	}

	fprintf(fOut, "GROUP\n");
	for(i=SC_End+1; i<=(SC_End+2); i++)	{
		fprintf(fOut, "ATOM %-5s %-8s %8.3lf\n", szAtomName_Out[i], szChemName[i], cg_List[i]);
	}

	//start	to read in bond list
	fseek(fIn, 0, SEEK_SET);
	nBond = 0;
	szRec_Impro[0] = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "BOND", 4)==0)	{
			ReadItem = sscanf(szLine, "%s%s%s", szTmp, szName, szName2);
			if(ReadItem == 3)	{
				BondList[nBond][0] = Query_Atom_by_Name(szName);
				BondList[nBond][1] = Query_Atom_by_Name(szName2);
				if( (Output_Atom[BondList[nBond][0]]) && (Output_Atom[BondList[nBond][1]]) )	{
					BondList[nBond][2] = 1;
				}
				else	{
					BondList[nBond][2] = 0;	// not output
				}
				nBond++;
			}
		}
		if( (strncmp(szLine, "IMPR", 4)==0) || (strncmp(szLine, "IMPH", 4)==0) )	{	// the record of improper dihedral
			if( szLine[3] == 'H' )	{
				szLine[3] = 'R';
			}
			strcat(szRec_Impro, szLine);
		}
	}
	//end	to read in bond list

	fprintf(fOut, "\n");

	for(i=0; i<nBond; i++)	{
		if(BondList[i][2])	{	// to output
			fprintf(fOut, "BOND %-6s%-6s\n", szAtomName_Out[BondList[i][0]], szAtomName_Out[BondList[i][1]]);
		}
	}
	fprintf(fOut, "BOND C     +N    \n\n");
	fprintf(fOut, "IMPR N  -C  CA  HN   C CA +N O   \n");
	fprintf(fOut, "CMAP -C  N  CA  C   N  CA  C  +N\n");
	
	fprintf(fOut, "%s\n", szRec_Impro);

	fprintf(fOut, "\nEND\n");

	fclose(fOut);
	fclose(fIn);
}




void Generate_PRM(void)
{
	FILE *fIn, *fOut;
	double fDummy_1, fDummy_2, fDummy_3;
	char szLine[256], *ReadLine, szChemName[4][256];
	int ReadItem, Count_New_Type;

	fIn = fopen("mol.prm", "r");
	if(fIn == NULL)	{
		Quit_With_Message("Fail to open file: mol.prm\n");
	}

	fOut = fopen("aa.prm", "w");

	fprintf(fOut, "BONDS\n");
	while(1)	{	// bond
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "ANGLE", 5)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%lf%lf", szChemName[0], szChemName[1], &fDummy_1, &fDummy_2);
		if(ReadItem == 4)	{
			Count_New_Type = Is_A_New_Chem_Type(szChemName[0]) + Is_A_New_Chem_Type(szChemName[1]);
			if(Count_New_Type > 0)	{
				fprintf(fOut, "%s", szLine);
			}
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "ANGLES\n");
	while(1)	{	// angle
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "DIHEDRAL", 8)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%lf%lf", szChemName[0], szChemName[1], szChemName[2], &fDummy_1, &fDummy_2);
		if(ReadItem == 5)	{
			Count_New_Type = Is_A_New_Chem_Type(szChemName[0]) + Is_A_New_Chem_Type(szChemName[1]) + Is_A_New_Chem_Type(szChemName[2]);
			if(Count_New_Type > 0)	{
				fprintf(fOut, "%s", szLine);
			}
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "DIHEDRALS\n");
	while(1)	{	// dihedral
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "IMPROPER", 8)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			Count_New_Type = Is_A_New_Chem_Type(szChemName[0]) + Is_A_New_Chem_Type(szChemName[1]) + Is_A_New_Chem_Type(szChemName[2]) + Is_A_New_Chem_Type(szChemName[3]);
			if(Count_New_Type > 0)	{
				fprintf(fOut, "%s", szLine);
			}
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "IMPROPERS\n");
	while(1)	{	// improper
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "NONBONDED", 9)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			Count_New_Type = Is_A_New_Chem_Type(szChemName[0]) + Is_A_New_Chem_Type(szChemName[1]) + Is_A_New_Chem_Type(szChemName[2]) + Is_A_New_Chem_Type(szChemName[3]);
			if(Count_New_Type > 0)	{
				fprintf(fOut, "%s", szLine);
			}
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "NONBONDED\n");
	while(1)	{	// LJ
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		ReadItem = sscanf(szLine, "%s%lf%lf%lf", szChemName[0], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 4)	{
			Count_New_Type = Is_A_New_Chem_Type(szChemName[0]);
			if(Count_New_Type > 0)	{
				fprintf(fOut, "%s", szLine);
			}
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "\nEND\n");


	fclose(fIn);
	fclose(fOut);
}


void Identify_All_Backbone_Atoms(void)
{
	int i;

	memset(Flag_Is_Backbone_Atom, 0, sizeof(char)*nAtom);
	memset(Flag_Is_Backbone_Atom, 1, sizeof(char)*10);
	memset(Flag_Is_Backbone_Atom + nAtom - 8, 1, sizeof(char)*8);
	SC_Start = 10;
	SC_End = nAtom - 9;

	for(i=0; i<nAtom; i++)	{
		Output_Atom[i] = 1;
	}

	for(i=0; i<6; i++)	{
		Output_Atom[i] = 0;
	}
	for(i=nAtom-6; i<nAtom; i++)	{
		Output_Atom[i] = 0;
	}

	Out_Start = SC_Start-4;
	Out_End = SC_End + 2;
}

int Query_Atom_by_Name(char szName[])
{
	int i;

	for(i=0; i<nAtom; i++)	{
		if(strcmp(szName, szAtomName[i])==0)	{
			return i;
		}
	}

	printf("Fail to find atom %s\nQuit\n", szName);
	exit(1);
}

int Is_A_New_Chem_Type(char szChem[])
{
	int i=0;

	while(szChem[i] != 0)	{
		if(szChem[i] == '_')	{
			return 1;
		}
		i++;
	}
	return 0;
}

void Quit_With_Message(const char szMsg[])
{
	printf("%s\n", szMsg);
	exit(1);
}

