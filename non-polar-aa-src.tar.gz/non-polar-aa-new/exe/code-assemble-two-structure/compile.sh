#!/bin/bash

g++ -O2 -o assemble_full assemble.cpp ff.cpp 

cp assemble_full ..
chmod g+rx ../assemble_full

