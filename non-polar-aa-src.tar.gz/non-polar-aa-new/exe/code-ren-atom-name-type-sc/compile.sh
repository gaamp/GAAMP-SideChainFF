#!/bin/bash

g++ -O2 -o rename_atom_sc re-org-rtf.cpp 

cp rename_atom_sc ..
chmod g+rx ../rename_atom_sc
