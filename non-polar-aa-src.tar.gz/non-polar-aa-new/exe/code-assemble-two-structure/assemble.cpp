#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ff.h"


CMol Mol;
CForceField ff, ff_Methyl_Mol;

#define IDX_CA		(8)
#define IDX_H_D		(9)
#define IDX_H_L		(10)

#define MAX_BUFF_LEN	(65536)
#define MAX_REC_ANGLE_GAFF	(1600)

void Quit_With_Error_Msg(char szMsg[]);
void Read_Alad_Coord(void);
void To_Upper_Case(char szBuff[]);
void Modify_Chem_Name_SC_Back(char szBuff[]);

extern double Normalize(double& vect_x, double& vect_y, double& vect_z);
double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b);
void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product);

void Assign_Alad_Coord(void);
void Determine_Cb(void);
void Determine_Cb_Neighbor(void);
void Read_Element_List_Side_Chain(void);
void Rotate_Side_Chain_Mol(void);

void Save_Full_Pdb(char szName[]);
void Assemble_Full_Molecule(void);
void Edit_Dihedral_Ca_Cb(int ia, int ib, int ic, int id, double phi);
double Cal_Dihedral_Full_Molecule(int ia, int ib, int ic, int id);

void Count_Atom_Type_in_SC(void);
int Is_This_Atom_Type_Exist(char szType[]);
void Modify_Atom_Name_Type_SC(void);
int Locate_Character(char szStr[], char c);

void Cal_Net_Charge_Full(void);
void Read_PRM_Entries(char szName[], char szPrm_Bond[], char szPrm_Angle[], char szPrm_Dihedral[], char szPrm_Impro[], char szPrm_LJ[]);

void Write_Full_RTF(void);
void Write_Full_PRM(void);
void Determine_Bond_Para_CA_CB_GAFF(void);
void Determine_Bond_Para_CA_CB_CGenFF(void);
void Output_RTF_Improper(FILE *fOut);
void Output_PRM_Improper(FILE *fOut);

void Read_Org_Chem_Type_Side_Chain(void);
void Read_Chem_Type_Methyl_Side_Chain(void);

void Build_Dist_Matrix(void);
void Cal_Nonbonded_VDW_Elec_BB_SC(double& E_VDW, double& E_Elec);
void Check_SC_Parameters(void);
void Add_SC_Parameters_New_Types(void);
int Is_A_Non_Used_ChemName(char szName[]);

char DistMatrix[MAX_ATOM][MAX_ATOM];
int nAtom_Full=0, Idx_Cb_Full, Idx_Cb_Neighbor_Full, Idx_SC_Full_Start, Idx_SC_Full_End;
int Is_L_Ca;	// Is L or D for Ca atom
int Idx_SC_BB;
int Idx_H_To_del, Idx_Cb_SC, Idx_Cb_Neighbor_SC;
int nBond_Full=0, Bond_List[MAX_ATOM*4][2];
int Bond_Count[MAX_ATOM], Bond_Array[MAX_ATOM][8];
int Idx_SC_in_Full_Mol[MAX_ATOM];
int Is_BB_Atom[MAX_ATOM];
double net_charge;
double x_Alad[MAX_ATOM], y_Alad[MAX_ATOM], z_Alad[MAX_ATOM];
double x_Full[MAX_ATOM], y_Full[MAX_ATOM], z_Full[MAX_ATOM];
double E_min_Full[MAX_ATOM], R_min_Full[MAX_ATOM], cg_Full[MAX_ATOM], mass_Full[MAX_ATOM];
char szChemName_Full[MAX_ATOM][16];
char szAtmName_Full[MAX_ATOM][16];
char szElemName_Full[MAX_ATOM][16];
double vx_Ca_Cb, vy_Ca_Cb, vz_Ca_Cb;
char szElem_SC[MAX_ATOM][16];
int nAtomType_SC=0;
int Idx_Atom_Type_SC[MAX_ATOM];
double k_b_Ca_Cb=0.0, b0_Ca_Cb=2.0;

int nNonbond_Pair=0, NonBonded_Pair[MAX_ATOM*MAX_ATOM][2];
double Para_LJ_Pair_Sigma[MAX_ATOM*MAX_ATOM], Para_LJ_Pair_Epsilon[MAX_ATOM*MAX_ATOM], Para_Elec_Pair[MAX_ATOM*MAX_ATOM];
double Para_LJ_Pair_Sigma_Pow_6[MAX_ATOM*MAX_ATOM], Para_LJ_Pair_Sigma_Pow_12[MAX_ATOM*MAX_ATOM];

int nRec_Angle_Para_Gaff;
char szAngleGaffChem[MAX_REC_ANGLE_GAFF][3][16];
double k_Angle_Gaff[MAX_REC_ANGLE_GAFF], theta_Angle_Gaff[MAX_REC_ANGLE_GAFF], Para_k_Urey[MAX_REC_ANGLE_GAFF], Para_b0_Urey[MAX_REC_ANGLE_GAFF];
void Read_Angle_Para_GAFF(void);
void Query_Angle_Para_GAFF(char szChem_1[], char szChem_2[], char szChem_3[], double& k_Angle, double& theta, double& k_Urey, double& b0_Urey);
void Read_Angle_Para_CGenFF(void);

char szBondPara[MAX_BUFF_LEN], szAnglePara[MAX_BUFF_LEN], szDihedralPara[MAX_BUFF_LEN], szImproPara[MAX_BUFF_LEN], szLJPara[MAX_BUFF_LEN];
char szBondPara_SC[MAX_BUFF_LEN], szAnglePara_SC[MAX_BUFF_LEN], szDihedralPara_SC[MAX_BUFF_LEN], szImproPara_SC[MAX_BUFF_LEN], szLJPara_SC[MAX_BUFF_LEN];

char szOrgChemName_SC[MAX_ATOM][24], szChemName_SC_Bak[MAX_ATOM][24];
char szChemName_Methyl_SC[MAX_ATOM][24];

int F_Chem_Type_Changed[MAX_ATOM];
int nDihe_Para_SC_Rec=0;
char szChem_Dihe_SC_Rec[MAX_ATOM][4][16];

int nBond_Type_Cb;
char Bonded_Type_Cb[5][16], Bonded_Type_Cb_Org_Chem[5][16];
void Determine_Atom_Bonded_with_Cb(void);
int Exist_Type_in_List_Cb(char szType[]);
void Output_Improper_SC_H_Cb();

#define MAX_BOND_ADD	(128)
#define MAX_ANGLE_ADD	(128)
#define MAX_DIHEDRAL_ADD	(256)
#define MAX_IMPROPER_ADD	(256)
#define MAX_LJ_ADD		(8)

BOND_REC Bond_Rec_Add[MAX_BOND_ADD];
ANGLE_REC Angle_Rec_Add[MAX_ANGLE_ADD];
DIHEDRAL_REC Dihedral_Rec_Add[MAX_DIHEDRAL_ADD];
IMPRODIHEDRAL_REC ImproDihedral_Rec_Add[MAX_IMPROPER_ADD];
LJ_REC LJ_Rec_Add[MAX_LJ_ADD];
int nBond_Add=0, nAngle_Add=0, nDihedral_Add=0, nImproper_Add=0, nLJ_Add=0;
int To_Add_Bond[MAX_BOND_ADD], To_Add_Angle[MAX_ANGLE_ADD], To_Add_Dihedral[MAX_DIHEDRAL_ADD], To_Add_Improper[MAX_IMPROPER_ADD], To_Add_LJ[MAX_LJ_ADD];

FILE *fFile_Run_Log;	// will be shared by other source code

int Gaff_Sidechain;

int main(int argc, char *argv[])
{
	double Phi, E_VDW, E_Elec, E_VDW_Elec, E_VDW_Elec_Min=1.0E200, Phi_Save;
	FILE *fOut;

	if(argc != 4)	{
		printf("Usage: assemble-pdb Idx_H L_Ca gaff\n");
		exit(1);
	}


	fFile_Run_Log = fopen("log-assemble-pdb.txt", "w");
	if(fFile_Run_Log==NULL)	{
		printf("Fail to create the log file.\n\n");
		exit(1);
	}

	Idx_H_To_del = atoi(argv[1]);
	Idx_H_To_del--;	// the index starting from 0
	Is_L_Ca = atoi(argv[2]);

	if( (strcmp(argv[3],"gaff")==0) || (strcmp(argv[3],"GAFF")==0) )	{
		Gaff_Sidechain = 1;	// Using GAFF
	}
	else {
		Gaff_Sidechain = 0;	// Using CGenFF: match or ParamChem
	}

	szBondPara_SC[0] = szAnglePara_SC[0] = szDihedralPara_SC[0] = szImproPara_SC[0] = szLJPara_SC[0] = 0;

	ff.ReadForceField("sc.prm");

	Mol.ReadPSF("sc.xpsf", 0);
	Mol.AssignForceFieldParameters(&ff);
	Cal_Net_Charge_Full();

//	Read_Org_Chem_Type_Side_Chain();
	if(!Gaff_Sidechain)	{
		Read_Chem_Type_Methyl_Side_Chain();
	}
	else	{
		for(int i=0; i<Mol.nAtom; i++)	{
			strcpy(szOrgChemName_SC[i], Mol.ChemName[i]);
		}
	}

	Determine_Cb();
	Determine_Atom_Bonded_with_Cb();	// update atom types in Cb group
	if(Gaff_Sidechain)	{
		Determine_Bond_Para_CA_CB_GAFF();
	}
	else {
		Check_SC_Parameters();
		Add_SC_Parameters_New_Types();
		Determine_Bond_Para_CA_CB_CGenFF();
	}
	Determine_Cb_Neighbor();
	if(Gaff_Sidechain)	{
		Read_Angle_Para_GAFF();	// read in the angle parameters in GAFF
	}
	else {
		Read_Angle_Para_CGenFF();	// read in the angle parameters in CGenFF
	}
	Read_Element_List_Side_Chain();

	Assign_Alad_Coord();


	Mol.ReadCRD("sc.crd");

//	Mol.Cal_E(1);

	Rotate_Side_Chain_Mol();

	Assemble_Full_Molecule();

	Write_Full_RTF();
	Write_Full_PRM();

//	Save_Full_Pdb("full.pdb");

	fOut = fopen("test.dat", "w");
	for(Phi=0.0; Phi<=360.0; Phi+=1.0)	{
		Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, Phi);
		Cal_Nonbonded_VDW_Elec_BB_SC(E_VDW, E_Elec);
		E_VDW_Elec = E_VDW + E_Elec;
		if( E_VDW_Elec < E_VDW_Elec_Min )	{
			Phi_Save = Phi;
			E_VDW_Elec_Min = E_VDW_Elec;
		}
		fprintf(fOut, "%.0lf %lf %lf %lf\n", Phi, E_VDW, E_Elec, E_VDW_Elec);
	}
	fclose(fOut);

	Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, Phi_Save);
	Cal_Nonbonded_VDW_Elec_BB_SC(E_VDW, E_Elec);
	Save_Full_Pdb("full-opt.pdb");



//	Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, 90.0);
//	Save_Full_Pdb("full-90.pdb");

//	Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, 180.0);
//	Save_Full_Pdb("full-180.pdb");

//	Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, 270.0);
//	Save_Full_Pdb("full-270.pdb");

//	Edit_Dihedral_Ca_Cb(6, 8, Idx_Cb_Full, Idx_Cb_Neighbor_Full, 360.0);
//	Save_Full_Pdb("full-360.pdb");

	fclose(fFile_Run_Log);

	return 0;
}

void Quit_With_Error_Msg(char szMsg[])
{
	fprintf(fFile_Run_Log, "%s", szMsg);
	fflush(fFile_Run_Log);
	exit(1);
}

#define LEN_C_H	(1.0967)
void Assign_Alad_Coord(void)	// assume alad is in alpha-helix form
{
	double vx, vy, vz, r, d_Ca_Cb, x_Ca, y_Ca, z_Ca;
	int nAtom_BB=19;

	x_Alad[ 0] =   2.975;   y_Alad[ 0] =   0.679;   z_Alad[ 0] =   0.644; 
	x_Alad[ 1] =   2.962;   y_Alad[ 1] =   0.320;   z_Alad[ 1] =   1.675; 
	x_Alad[ 2] =   3.866;   y_Alad[ 2] =   0.291;   z_Alad[ 2] =   0.144; 
	x_Alad[ 3] =   3.036;   y_Alad[ 3] =   1.768;   z_Alad[ 3] =   0.635; 
	x_Alad[ 4] =   1.750;   y_Alad[ 4] =   0.263;   z_Alad[ 4] =  -0.139; 
	x_Alad[ 5] =   1.432;   y_Alad[ 5] =   0.802;   z_Alad[ 5] =  -1.204; 
	x_Alad[ 6] =   1.034;   y_Alad[ 6] =  -0.761;   z_Alad[ 6] =   0.394; 
	x_Alad[ 7] =   1.275;   y_Alad[ 7] =  -1.204;   z_Alad[ 7] =   1.274; 
	x_Alad[ 8] =  -0.157;   y_Alad[ 8] =  -1.258;   z_Alad[ 8] =  -0.255; 
	x_Alad[ 9] =   0.122;   y_Alad[ 9] =  -1.597;   z_Alad[ 9] =  -1.260; 
	x_Alad[10] =  -0.778;   y_Alad[10] =  -2.424;   z_Alad[10] =   0.515; 
	x_Alad[11] =  -1.135;   y_Alad[11] =  -0.092;   z_Alad[11] =  -0.338; 
	x_Alad[12] =  -1.713;   y_Alad[12] =   0.190;   z_Alad[12] =  -1.393; 
	x_Alad[13] =  -1.251;   y_Alad[13] =   0.637;   z_Alad[13] =   0.801; 
	x_Alad[14] =  -0.766;   y_Alad[14] =   0.317;   z_Alad[14] =   1.629; 
	x_Alad[15] =  -2.094;   y_Alad[15] =   1.814;   z_Alad[15] =   0.891; 
	x_Alad[16] =  -2.546;   y_Alad[16] =   1.960;   z_Alad[16] =  -0.090; 
	x_Alad[17] =  -2.885;   y_Alad[17] =   1.669;   z_Alad[17] =   1.632; 
	x_Alad[18] =  -1.508;   y_Alad[18] =   2.697;   z_Alad[18] =   1.157; 

	vx = x_Alad[IDX_H_L] - x_Alad[IDX_CA];
	vy = y_Alad[IDX_H_L] - y_Alad[IDX_CA];
	vz = z_Alad[IDX_H_L] - z_Alad[IDX_CA];

	r = Normalize(vx, vy, vz);

	x_Alad[IDX_H_L] = x_Alad[IDX_CA] + LEN_C_H * vx;	// generate the coordinates for H atom 
	y_Alad[IDX_H_L] = y_Alad[IDX_CA] + LEN_C_H * vy;
	z_Alad[IDX_H_L] = z_Alad[IDX_CA] + LEN_C_H * vz;

	if(Is_L_Ca)	{	// L
		Idx_SC_BB = IDX_H_L;
	}
	else	{		// D
		Idx_SC_BB = IDX_H_D;
	}

	d_Ca_Cb = b0_Ca_Cb;

/*
	//start	to determine the proper bond length betweeb Ca and Cb (it could be other element than carbon)
	if(strcmp(szElem_SC[Idx_Cb_SC],"H")==0)	{	// should never happen
		d_Ca_Cb = 1.10;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"B")==0)	{
		d_Ca_Cb = 1.56;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"C")==0)	{
		d_Ca_Cb = 1.54;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"SI")==0)	{
		d_Ca_Cb = 1.94;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"N")==0)	{
		d_Ca_Cb = 1.47;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"P")==0)	{
		d_Ca_Cb = 1.87;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"O")==0)	{
		d_Ca_Cb = 1.43;
	}
	else if(strcmp(szElem_SC[Idx_Cb_SC],"S")==0)	{
		d_Ca_Cb = 1.81;
	}
	else	{
		Quit_With_Error_Msg("Unsupported element at Cb position!\nQuit.\n");
	}
	//end	to determine the proper bond length betweeb Ca and Cb (it could be other element than carbon)
*/

	vx = x_Alad[Idx_SC_BB] - x_Alad[IDX_CA];
	vy = y_Alad[Idx_SC_BB] - y_Alad[IDX_CA];
	vz = z_Alad[Idx_SC_BB] - z_Alad[IDX_CA];

	r = Normalize(vx, vy, vz);

	x_Alad[Idx_SC_BB] = x_Alad[IDX_CA] + d_Ca_Cb * vx;	// generate the coordinates for Cb atom 
	y_Alad[Idx_SC_BB] = y_Alad[IDX_CA] + d_Ca_Cb * vy;
	z_Alad[Idx_SC_BB] = z_Alad[IDX_CA] + d_Ca_Cb * vz;

	vx_Ca_Cb=vx; vy_Ca_Cb=vy; vz_Ca_Cb=vz;

	x_Ca = x_Alad[IDX_CA];
	y_Ca = y_Alad[IDX_CA];
	z_Ca = z_Alad[IDX_CA];

	//start	to translate the molecule to position Ca at origin
	for(int i=0; i<nAtom_BB; i++)	{
		x_Alad[i] -= x_Ca;
		y_Alad[i] -= y_Ca;
		z_Alad[i] -= z_Ca;
	}
	//end	to translate the molecule to position Ca at origin
}
#undef LEN_C_H


inline double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b)
{
	return (x_a*x_b + y_a*y_b + z_a*z_b);
}

inline void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product)
{
	x_Product = y_a*z_b - y_b*z_a;
	y_Product = z_a*x_b - z_b*x_a;
	z_Product = x_a*y_b - x_b*y_a;

	Normalize(x_Product, y_Product, z_Product);
}

void Determine_Cb(void)
{
	int i, iPos, ia, ib;

	Idx_Cb_SC = -1;
	for(i=0; i<Mol.nBond; i++)	{
		iPos = 2*i;
		ia = Mol.BondList[iPos  ];
		ib = Mol.BondList[iPos+1];

		if( ia == Idx_H_To_del )	{
			Idx_Cb_SC = ib;
			break;
		}
		if( ib == Idx_H_To_del )	{
			Idx_Cb_SC = ia;
			break;
		}
	}

	if(Idx_Cb_SC < 0)	{
		Quit_With_Error_Msg("Fail to determine the Cb atom in side chain molecule.\n");
	}
}

void Determine_Cb_Neighbor(void)
{
	int i, iPos, ia, ib;

	Idx_Cb_Neighbor_SC = -1;

	for(i=0; i<Mol.nBond; i++)	{
		iPos = 2*i;
		ia = Mol.BondList[iPos  ];
		ib = Mol.BondList[iPos+1];

		if( (ia == Idx_Cb_SC) && (ib != Idx_H_To_del) )	{
			Idx_Cb_Neighbor_SC = ib;
			break;
		}
		if( (ib == Idx_Cb_SC) && (ia != Idx_H_To_del) )	{
			Idx_Cb_Neighbor_SC = ia;
			break;
		}
	}

	if(Idx_Cb_Neighbor_SC < 0)	{
		Quit_With_Error_Msg("Fail to determine the Cb atom in side chain molecule.\n");
	}
}

void Read_Element_List_Side_Chain(void)
{
	FILE *fIn;
	int i, ReadItem;

	fIn = fopen("sc-elem-list.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file sc-elem-list.txt for read in the element list of side chain molecule.\n");
	}

	for(i=0; i<Mol.nAtom; i++)	{
		ReadItem = fscanf(fIn, "%s", szElem_SC[i]);
		if(ReadItem != 1)	{
			fclose(fIn);
			Quit_With_Error_Msg("Error in reading sc-elem-list.txt for the element list of side chain molecule.\n");
		}
	}

	fclose(fIn);
}

void Rotate_Side_Chain_Mol(void)
{
	double diag_x=vx_Ca_Cb, diag_y=vy_Ca_Cb, diag_z=vz_Ca_Cb;
	double cos_theta, sin_theta, RotM[3][3], dot_H_Cb;
	double Cen_x, Cen_y, Cen_z, x_New, y_New, z_New;
	double *x_Mol, *y_Mol, *z_Mol;
	double x_H_Cb, y_H_Cb, z_H_Cb;
	double x_H, y_H, z_H, dx, dy, dz;
	int i;

	x_Mol = Mol.x;
	y_Mol = Mol.y;
	z_Mol = Mol.z;

	//start	to do translation for the side chain molecule to make H atom at origin
	x_H = x_Mol[Idx_H_To_del];  y_H = y_Mol[Idx_H_To_del];  z_H = z_Mol[Idx_H_To_del];
	for(i=0; i<Mol.nAtom; i++)	{
		x_Mol[i] -= x_H;
		y_Mol[i] -= y_H;
		z_Mol[i] -= z_H;
	}
	//end	to do translation for the side chain molecule to make H atom at origin


	Normalize(diag_x, diag_y, diag_z);

	x_H_Cb = x_Mol[Idx_Cb_SC] - x_Mol[Idx_H_To_del];
	y_H_Cb = y_Mol[Idx_Cb_SC] - y_Mol[Idx_H_To_del];
	z_H_Cb = z_Mol[Idx_Cb_SC] - z_Mol[Idx_H_To_del];
	Normalize(x_H_Cb, y_H_Cb, z_H_Cb);


	cos_theta = Dot_Product(x_H_Cb, y_H_Cb, z_H_Cb, diag_x, diag_y, diag_z);
	sin_theta = sqrt(1.0 - cos_theta*cos_theta);

	Cross_Product(x_H_Cb, y_H_Cb, z_H_Cb, diag_x, diag_y, diag_z, Cen_x, Cen_y, Cen_z);

	RotM[0][0] = Cen_x*Cen_x + (1-Cen_x*Cen_x)*cos_theta;
	RotM[0][1] = Cen_x*Cen_y*(1.0-cos_theta) - Cen_z*sin_theta;
	RotM[0][2] = Cen_x*Cen_z*(1.0-cos_theta) + Cen_y*sin_theta;
	
	RotM[1][0] = Cen_x*Cen_y*(1.0-cos_theta) + Cen_z*sin_theta;
	RotM[1][1] = Cen_y*Cen_y + (1-Cen_y*Cen_y)*cos_theta;
	RotM[1][2] = Cen_y*Cen_z*(1.0-cos_theta) - Cen_x*sin_theta;
	
	RotM[2][0] = Cen_x*Cen_z*(1.0-cos_theta) - Cen_y*sin_theta;
	RotM[2][1] = Cen_y*Cen_z*(1.0-cos_theta) + Cen_x*sin_theta;
	RotM[2][2] = Cen_z*Cen_z + (1-Cen_z*Cen_z)*cos_theta;

	//start	to calculate the determinant of RotM[3][3]
	double Sum=0.0;
	Sum = RotM[0][0] * ( RotM[1][1]*RotM[2][2] - RotM[1][2]*RotM[2][1] ) + 
		RotM[0][1] * ( RotM[1][2]*RotM[2][0] - RotM[1][0]*RotM[2][2] ) + 
		RotM[0][2] * ( RotM[1][0]*RotM[2][1] - RotM[1][1]*RotM[2][0] );
	//end	to calculate the determinant of RotM[3][3]


	for(i=0; i<Mol.nAtom; i++)	{
		x_New = RotM[0][0] * x_Mol[i] + RotM[0][1] * y_Mol[i] + RotM[0][2] * z_Mol[i];
		y_New = RotM[1][0] * x_Mol[i] + RotM[1][1] * y_Mol[i] + RotM[1][2] * z_Mol[i];
		z_New = RotM[2][0] * x_Mol[i] + RotM[2][1] * y_Mol[i] + RotM[2][2] * z_Mol[i];

		x_Mol[i] = x_New;
		y_Mol[i] = y_New;
		z_Mol[i] = z_New;
	}

	dot_H_Cb = Dot_Product(x_Mol[Idx_Cb_SC]-x_Mol[Idx_H_To_del], y_Mol[Idx_Cb_SC]-y_Mol[Idx_H_To_del], z_Mol[Idx_Cb_SC]-z_Mol[Idx_H_To_del], diag_x, diag_y, diag_z);

	if(dot_H_Cb < 0.0)	{	// flip the coordinates
		for(i=0; i<Mol.nAtom; i++)	{
			x_Mol[i] = -x_Mol[i];
			y_Mol[i] = -y_Mol[i];
			z_Mol[i] = -z_Mol[i];
		}
	}

	dx = x_Alad[Idx_SC_BB] - x_Mol[Idx_Cb_SC];
	dy = y_Alad[Idx_SC_BB] - y_Mol[Idx_Cb_SC];
	dz = z_Alad[Idx_SC_BB] - z_Mol[Idx_Cb_SC];

	//start	to translate
	for(i=0; i<Mol.nAtom; i++)	{
		x_Mol[i] += dx;
		y_Mol[i] += dy;
		z_Mol[i] += dz;
	}
	//end	to translate

//	if(strcmp(szElem_SC[Idx_Cb_SC], "C")==0)	{	// carbon at Cb
//		strcpy(Mol.AtomName[Idx_Cb_SC], "CB");
//	}
}

int Is_This_Atom_Type_Exist(char szType[])
{
	for(int i=0; i<nAtomType_SC; i++)	{
		if(strcmp(szType, Mol.ChemName[Idx_Atom_Type_SC[i]])==0)	{
			return i;
		}
	}
	return -1;
}

void Count_Atom_Type_in_SC(void)
{
	int i, nAtom;

	nAtom = Mol.nAtom;
	nAtomType_SC = 0;

	for(i=0; i<nAtom; i++)	{
		if(i==Idx_H_To_del)	{
			continue;
		}
		if(Is_This_Atom_Type_Exist(Mol.ChemName[i])<0)	{	// a type not existing
			Idx_Atom_Type_SC[nAtomType_SC] = i;
			nAtomType_SC++;
		}
	}
}

void Modify_Atom_Name_Type_SC(void)
{
	int i, nAtom;

	nAtom = Mol.nAtom;

	//start	to add '_' after the atom name and chem type
	for(i=0; i<nAtom; i++)	{
		if(Locate_Character(Mol.AtomName[i], '_') < 0)	{	// atom name is not changed. To add "_"
			strcat(Mol.AtomName[i], "_");
		}
		if(Locate_Character(Mol.ChemName[i], '_') < 0)	{	// atom chem name is not changed. To add "_"
			strcat(Mol.ChemName[i], "_");
		}
	}
	//end	to add '_' after the atom name and chem type
}

int Locate_Character(char szStr[], char c)
{
	int i=0;

	while(szStr[i] != 0)	{
		if(szStr[i] == c)	{
			return i;
		}
		i++;
	}
	return -1;
}


void Assemble_Full_Molecule(void)
{
	int i, ia, ib, iPos, Count;
	char szChemName[][16]={"CT3", "HA", "HA", "HA", "C", "O", "NH1", "H", "CT1", "HB", "HB", "C", "O", "NH1", "H", "CT3", "HA", "HA", "HA"};
	char szAtomName[][16]={"CL", "HL1", "HL2", "HL3", "CLP", "OL", "NL", "HL", "CA", "HA", "HB", "CRP", "OR", "NR", "HR", "CR", "HR1", "HR2", "HR3"};
	char szElemName[][16]={"C", "H", "H", "H", "C", "O", "N", "H", "C", "H", "H", "C", "O", "N", "H", "C", "H", "H", "H"};
	double E_Min_BB[]={-0.08000, -0.02200, -0.02200, -0.02200, -0.11000, -0.12000, -0.20000, -0.04600, -0.02000, -0.02200, -0.02200, -0.11000, -0.12000, -0.20000, -0.04600, -0.08000, -0.02200, -0.02200, -0.02200};
	double R_Min_BB[]={2.0600, 1.3200, 1.3200, 1.3200, 2.0000, 1.7000, 1.8500, 0.2245, 2.2750, 1.3200, 1.3200, 2.0000, 1.7000, 1.8500, 0.2245, 2.0600, 1.3200, 1.3200, 1.3200};
	double cg_BB[]={-0.27, 0.09, 0.09, 0.09, 0.51, -0.51, -0.47, 0.31, 0.07, 0.09, 0.09, 0.51, -0.51, -0.47, 0.31, -0.11, 0.09, 0.09, 0.09};
	double mass_BB[]={12.011,  1.008,  1.008,  1.008, 12.011, 15.999, 14.007,  1.008, 12.011,  1.008,  1.008, 12.011, 15.999, 14.007,  1.008, 12.011,  1.008,  1.008,  1.008};
	int Bond_List_p1[8][2]={{1, 2}, {1, 3}, {1, 4}, {1, 5}, {5, 6}, {5, 7}, {7, 8}, {7, 9}};
	int Idx_CRP;

	nBond_Full = 0;

	Modify_Atom_Name_Type_SC();
	Count_Atom_Type_in_SC();

	for(i=0; i<=IDX_CA; i++)	{
		x_Full[i] = x_Alad[i];
		y_Full[i] = y_Alad[i];
		z_Full[i] = z_Alad[i];
		strcpy(szElemName_Full[i], szElemName[i]);
		strcpy(szAtmName_Full[i], szAtomName[i]);
		strcpy(szChemName_Full[i], szChemName[i]);
		E_min_Full[i] = E_Min_BB[i];
		R_min_Full[i] = R_Min_BB[i];
		cg_Full[i] = cg_BB[i];
		mass_Full[i] = mass_BB[i];
	}
	Count = IDX_CA+1;

	if(Is_L_Ca)	{	// to output IDX_H_D
		i = IDX_H_D;
		x_Full[Count] = x_Alad[i];
		y_Full[Count] = y_Alad[i];
		z_Full[Count] = z_Alad[i];
		strcpy(szElemName_Full[Count], szElemName[i]);
		strcpy(szAtmName_Full[Count], szAtomName[i]);
		strcpy(szChemName_Full[Count], szChemName[i]);
		E_min_Full[Count] = E_Min_BB[i];
		R_min_Full[Count] = R_Min_BB[i];
		cg_Full[Count] = cg_BB[i];
		mass_Full[Count] = mass_BB[i];
	}
	else	{		// to output IDX_H_L
		i = IDX_H_L;
		x_Full[Count] = x_Alad[i];
		y_Full[Count] = y_Alad[i];
		z_Full[Count] = z_Alad[i];
		strcpy(szElemName_Full[Count], szElemName[i]);
		strcpy(szAtmName_Full[Count], szAtomName[i]);
		strcpy(szChemName_Full[Count], szChemName[i]);
		E_min_Full[Count] = E_Min_BB[i];
		R_min_Full[Count] = R_Min_BB[i];
		cg_Full[Count] = cg_BB[i];
		mass_Full[Count] = mass_BB[i];
	}

	Count++;

	//start	to build bond list for the first part of BB atoms
	for(i=0; i<8; i++)	{
		Bond_List[nBond_Full][0] = Bond_List_p1[i][0] - 1;
		Bond_List[nBond_Full][1] = Bond_List_p1[i][1] - 1;
		nBond_Full++;
	}
	Bond_List[nBond_Full][0] = 8;	// CA
	Bond_List[nBond_Full][1] = 9;	// H
	nBond_Full++;
	//end	to build bond list for the first part of BB atoms

	Idx_SC_Full_Start = Count;
	
	//start	to assign Cb atom in side-chain
	Idx_SC_in_Full_Mol[Idx_Cb_SC] = Count;	// an invalid index
	x_Full[Count] = Mol.x[Idx_Cb_SC];
	y_Full[Count] = Mol.y[Idx_Cb_SC];
	z_Full[Count] = Mol.z[Idx_Cb_SC];
	strcpy(szElemName_Full[Count], szElem_SC[Idx_Cb_SC]);
	strcpy(szAtmName_Full[Count], Mol.AtomName[Idx_Cb_SC]);
	strcpy(szChemName_Full[Count], Mol.ChemName[Idx_Cb_SC]);
	E_min_Full[Count] = Mol.Para_LJ_Epsilon[Idx_Cb_SC];
	R_min_Full[Count] = Mol.Para_LJ_Sigma[Idx_Cb_SC];
	cg_Full[Count] = Mol.CG[Idx_Cb_SC];
	mass_Full[Count] = Mol.mass[Idx_Cb_SC];
	Idx_Cb_Full = Count;
	Count++;
	//end	to assign Cb atom in side-chain

	for(i=0; i<Mol.nAtom; i++)	{	// all atoms in side chain exclude H bonded with Cb and Cb
		if( (i != Idx_H_To_del) && (i != Idx_Cb_SC) )	{
			Idx_SC_in_Full_Mol[i] = -1;	// an invalid index
			x_Full[Count] = Mol.x[i];
			y_Full[Count] = Mol.y[i];
			z_Full[Count] = Mol.z[i];
			strcpy(szElemName_Full[Count], szElem_SC[i]);
			strcpy(szAtmName_Full[Count], Mol.AtomName[i]);
			strcpy(szChemName_Full[Count], Mol.ChemName[i]);
			E_min_Full[Count] = Mol.Para_LJ_Epsilon[i];
			R_min_Full[Count] = Mol.Para_LJ_Sigma[i];
			cg_Full[Count] = Mol.CG[i];
			mass_Full[Count] = Mol.mass[i];

			if(i==Idx_Cb_Neighbor_SC)	{
				Idx_Cb_Neighbor_Full = Count;
			}

			Idx_SC_in_Full_Mol[i] = Count;
			Count++;
		}
	}
	Idx_SC_Full_End = Count-1;

	//start	to build bond list for the side chain atoms
	for(i=0; i<Mol.nBond; i++)	{
		iPos = 2 * i;
		ia = Mol.BondList[iPos  ];
		ib = Mol.BondList[iPos+1];
		if( (ia != Idx_H_To_del) && (ib != Idx_H_To_del) )	{
			Bond_List[nBond_Full][0] = Idx_SC_in_Full_Mol[ia];
			Bond_List[nBond_Full][1] = Idx_SC_in_Full_Mol[ib];
			nBond_Full++;
		}
	}
	//end	to build bond list for the side chain atoms


	for(i=11; i<19; i++)	{
		x_Full[Count] = x_Alad[i];
		y_Full[Count] = y_Alad[i];
		z_Full[Count] = z_Alad[i];
		strcpy(szElemName_Full[Count], szElemName[i]);
		strcpy(szAtmName_Full[Count], szAtomName[i]);
		strcpy(szChemName_Full[Count], szChemName[i]);
		E_min_Full[Count] = E_Min_BB[i];
		R_min_Full[Count] = R_Min_BB[i];
		cg_Full[Count] = cg_BB[i];
		mass_Full[Count] = mass_BB[i];
		
		Count++;
	}

	nAtom_Full = Count;

	//start	to build bond between CA and CB
	Bond_List[nBond_Full][0] = 8;	// CA
	Bond_List[nBond_Full][1] = Idx_Cb_Full;	// CB
	nBond_Full++;
	//end	to build bond between CA and CB

	//start	to build bond list for the second part of BB atoms
	Idx_CRP = Idx_SC_Full_End + 1;

	Bond_List[nBond_Full][0] = 8;	// CA
	Bond_List[nBond_Full][1] = Idx_CRP;	// CRP
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP;	// CRP
	Bond_List[nBond_Full][1] = Idx_CRP+1;	// OR
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP;	// CRP
	Bond_List[nBond_Full][1] = Idx_CRP+2;	// NR
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP+2;	// NR
	Bond_List[nBond_Full][1] = Idx_CRP+3;	// HR
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP+2;	// NR
	Bond_List[nBond_Full][1] = Idx_CRP+4;	// CR
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP+4;	// CR
	Bond_List[nBond_Full][1] = Idx_CRP+5;	// HR1
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP+4;	// CR
	Bond_List[nBond_Full][1] = Idx_CRP+6;	// HR2
	nBond_Full++;

	Bond_List[nBond_Full][0] = Idx_CRP+4;	// CR
	Bond_List[nBond_Full][1] = Idx_CRP+7;	// HR3
	nBond_Full++;
	//end	to build bond list for the second part of BB atoms

	memset(Bond_Count, 0, sizeof(int)*nAtom_Full);
	for(i=0; i<nBond_Full; i++)	{
//		printf("Bond: %3d  %3d\n", Bond_List[i][0]+1, Bond_List[i][1]+1);
		Bond_Array[Bond_List[i][0]][Bond_Count[Bond_List[i][0]]]=Bond_List[i][1];
		Bond_Array[Bond_List[i][1]][Bond_Count[Bond_List[i][1]]]=Bond_List[i][0];

		Bond_Count[Bond_List[i][0]]++;
		Bond_Count[Bond_List[i][1]]++;
	}

	if( (mass_Full[Idx_Cb_Full] > 12.0) && (mass_Full[Idx_Cb_Full] < 12.05) && (Bond_Count[Idx_Cb_Full]==4) )	{	// sp3 carbon
		strcpy(szAtmName_Full[Idx_Cb_Full], "CB");
	}

	for(i=0; i<nAtom_Full; i++)	{
		if( (i>=Idx_SC_Full_Start) && (i<=Idx_SC_Full_End) )	{
			Is_BB_Atom[i] = 0;
		}
		else	{
			Is_BB_Atom[i] = 1;
		}
	}

	Build_Dist_Matrix();

	FILE *fOut;
	fOut = fopen("elem-full.txt", "w");
	for(i=0; i<nAtom_Full; i++)	{
		fprintf(fOut, "%s\n", szElemName_Full[i]);
	}
	fclose(fOut);
}

void Save_Full_Pdb(char szName[])
{
	FILE *fOut;
	int i;

	fOut = fopen(szName, "w");

	for(i=0; i<nAtom_Full; i++)	{
		if(strlen(szAtmName_Full[i]) == 4)	{
			fprintf(fOut, "ATOM%7d %-4s %-4sA%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
				i+1, szAtmName_Full[i], "MOL ", 1, x_Full[i], y_Full[i], z_Full[i]);
		}
		else	{
			fprintf(fOut, "ATOM%7d  %-3s %-4sA%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
				i+1, szAtmName_Full[i], "MOL ", 1, x_Full[i], y_Full[i], z_Full[i]);
		}
	}
	fprintf(fOut, "END\n");

	fclose(fOut);
}


void Edit_Dihedral_Ca_Cb(int ia, int ib, int ic, int id, double Phi)
{
	int i, j, indx[4];
	double x_perp, y_perp, z_perp;
	double x_cb, y_cb, z_cb, x_ba, y_ba, z_ba;
	double *x, *y, *z;
	double **MRotateTmp, col[4], d, d_Phi, sinfai, cosfai;
	double dx, dy, dz;

	x = x_Full;  y=y_Full;  z=z_Full;

//	ia = 6;	// N
//	ib = 8;	// CA
//	ic =Idx_Cb_Full;	// CB

	x_cb = x[ib] - x[ic];	y_cb = y[ib] - y[ic];	z_cb = z[ib] - z[ic];
	Normalize(x_cb, y_cb, z_cb);	// Z
	
	x_ba = x[ia] - x[ib];	y_ba = y[ia] - y[ib];	z_ba = z[ia] - z[ib];
	Normalize(x_ba, y_ba, z_ba);	// X

	x_perp = y_cb * z_ba - z_cb * y_ba;
	y_perp = z_cb * x_ba - x_cb * z_ba;
	z_perp = x_cb * y_ba - y_cb * x_ba;
	Normalize(x_perp, y_perp, z_perp);	// Y

	// rebuild the x vector. Y X Z
	x_ba = y_perp * z_cb - z_perp * y_cb;
	y_ba = z_perp * x_cb - x_perp * z_cb;
	z_ba = x_perp * y_cb - y_perp * x_cb;

	Mol.MRotate[1][1]=x_ba;		Mol.MRotate[1][2]=x_perp;		Mol.MRotate[1][3]=x_cb;
	Mol.MRotate[2][1]=y_ba;		Mol.MRotate[2][2]=y_perp;		Mol.MRotate[2][3]=y_cb;
	Mol.MRotate[3][1]=z_ba;		Mol.MRotate[3][2]=z_perp;		Mol.MRotate[3][3]=z_cb;

	//start	to inverse 3*3 matrix
	MRotateTmp=dmatrix(1, 3, 1, 3);
	for(i=1; i<=3; i++)	{
		for(j=1; j<=3; j++)	{
			MRotateTmp[i][j]=Mol.MRotate[i][j];
		}
	}

	ludcmp(MRotateTmp, 3, indx, &d); //Decompose the matrix just once.
	for(j=1;j<=3;j++) { //Find inverse by columns.
		for(i=1;i<=3;i++) col[i]=0.0;
		col[j]=1.0;
		lubksb(MRotateTmp, 3, indx, col);
		for(i=1;i<=3;i++) Mol.InvM[i][j]=col[i];
	}
	free_dmatrix(MRotateTmp, 1, 3, 1, 3);
	//end	to inverse 3*3 matrix
	
	//start	to set up the matrix for the rotation with Z-axis (CB)
	d_Phi = -(Phi - Cal_Dihedral_Full_Molecule(ia, ib, ic, id))*radianInv;	// the dihedral to rotate. Minus sign is necessary!
	cosfai = cos(d_Phi);
	sinfai = sin(d_Phi);
	Mol.MRz[1][1]=cosfai;		Mol.MRz[1][2]=-sinfai;			Mol.MRz[1][3]=0.0;	
	Mol.MRz[2][1]=sinfai;		Mol.MRz[2][2]=cosfai;			Mol.MRz[2][3]=0.0;	
	Mol.MRz[3][1]=0.0;			Mol.MRz[3][2]=0.0;				Mol.MRz[3][3]=1.0;	
	//end	to set up the matrix for the rotation with Z-axis (CB)

	for(i=Idx_SC_Full_Start; i<=Idx_SC_Full_End; i++)	{
		if(i != ic)	{
			dx = x[i] - x[Idx_Cb_Full];
			dy = y[i] - y[Idx_Cb_Full];
			dz = z[i] - z[Idx_Cb_Full];
			Mol.CoordinateCal(&dx, &dy, &dz);
			x[i] = x[Idx_Cb_Full] + dx;
			y[i] = y[Idx_Cb_Full] + dy;
			z[i] = z[Idx_Cb_Full] + dz;
		}
	}

}

double Cal_Dihedral_Full_Molecule(int ia, int ib, int ic, int id)
{
	double xia, yia, zia;
	double xib, yib, zib;
	double xic, yic, zic;
	double xid, yid, zid;
	double xba, yba, zba;
	double xcb, ycb, zcb;
	double xdc, ydc, zdc;
	double xt, yt, zt;
	double xu, yu, zu;
	double xtu, ytu, ztu;
	double rt2, ru2, rtru, rcb, cosine, sine, fai;

	xia = x_Full[ia];		yia = y_Full[ia];		zia = z_Full[ia];
	xib = x_Full[ib];		yib = y_Full[ib];		zib = z_Full[ib];
	xic = x_Full[ic];		yic = y_Full[ic];		zic = z_Full[ic];
	xid = x_Full[id];		yid = y_Full[id];		zid = z_Full[id];
	xba = xib - xia;	yba = yib - yia;	zba = zib - zia;
	xcb = xic - xib;	ycb = yic - yib;	zcb = zic - zib;
	xdc = xid - xic;	ydc = yid - yic;	zdc = zid - zic;
	
	xt = yba*zcb - ycb*zba;
	yt = zba*xcb - zcb*xba;
	zt = xba*ycb - xcb*yba;
	xu = ycb*zdc - ydc*zcb;
	yu = zcb*xdc - zdc*xcb;
	zu = xcb*ydc - xdc*ycb;
	xtu = yt*zu - yu*zt;
	ytu = zt*xu - zu*xt;
	ztu = xt*yu - xu*yt;
	rt2 = xt*xt + yt*yt + zt*zt;
	ru2 = xu*xu + yu*yu + zu*zu;
	rt2=max(rt2, 0.000000001);
	ru2=max(ru2, 0.000000001);
	rtru = sqrt(rt2 * ru2);
	
	if(rtru!=0.0)	{
		rcb = sqrt(xcb*xcb + ycb*ycb + zcb*zcb);
		cosine = (xt*xu + yt*yu + zt*zu) / rtru;
		sine = (xcb*xtu + ycb*ytu + zcb*ztu) / (rcb*rtru);		//as in Tinker
		
		
		fai = asin(min(max(sine,-1.0),1.0))*radian;	// [-90,90]
		if(cosine < 0.0)	{	//[90,270]
			if(sine < 0.0)	{	//[-180,-90]
				fai = -180.0 - fai;
			}
			else	{	//[90,180]
				fai = 180.0 - fai;
			}
		}
	}
	
	return fai;
}

void Cal_Net_Charge_Full(void)
{
	net_charge = 0.0;

	for(int i=0; i<Mol.nAtom; i++)	{
		net_charge += Mol.CG[i];
	}
	return;
}

void Write_Full_RTF(void)
{
	FILE *fOut;
	int i, Idx, Atom_Type_ID_Offset=300;

	fOut = fopen("full.rtf", "w");

	fprintf(fOut, "* Topology file generated for amino acid side chain \n* parameter fitting with the program written by Lei Huang.\n   99   1\n");

	fprintf(fOut, "MASS     1 H         1.00800 H ! POLAR H\n");
	fprintf(fOut, "MASS     3 HA        1.00800 H ! NONPOLAR H\n");
	fprintf(fOut, "MASS     6 HB        1.00800 H ! BACKBONE H\n");
	fprintf(fOut, "MASS    20 C        12.01100 C ! CARBONYL C, PEPTIDE BACKBONE\n");
	fprintf(fOut, "MASS    22 CT1      12.01100 C ! ALIPHATIC SP3 C FOR CH\n");
	fprintf(fOut, "MASS    24 CT3      12.01100 C ! ALIPHATIC SP3 C FOR CH3\n");
	fprintf(fOut, "MASS    54 NH1      14.00700 N ! PEPTIDE NITROGEN\n");
	fprintf(fOut, "MASS    70 O        15.99900 O ! CARBONYL OXYGEN\n");

	for(i=0; i<nAtomType_SC; i++)	{
		Idx = Idx_Atom_Type_SC[i];
		fprintf(fOut, "MASS %5d %-8s %8.5lf %-2s\n", 
			Atom_Type_ID_Offset+i, Mol.ChemName[Idx], Mol.mass[Idx], szElem_SC[Idx]);
	}

	fprintf(fOut, "\n");
	fprintf(fOut, "AUTO ANGLES DIHE\n\n");

	fprintf(fOut, "RESI MOL %6.3lf\n", net_charge);

	for(i=0; i<nAtom_Full; i++)	{
		fprintf(fOut, "ATOM %-5s %-8s %8.3lf\n", szAtmName_Full[i], szChemName_Full[i], cg_Full[i]);
	}
	fprintf(fOut, "\n");

	for(i=0; i<nBond_Full; i++)	{
		fprintf(fOut, "BOND %-6s%-6s\n", szAtmName_Full[Bond_List[i][0]], szAtmName_Full[Bond_List[i][1]]);
	}
	fprintf(fOut, "\n");

	// improper
	Output_RTF_Improper(fOut);
	fprintf(fOut, "\n");

	fprintf(fOut, "\nEND\n");

	fclose(fOut);
}

int Is_Existing_Dihe_Para_SC(char szChem_1[], char szChem_2[], char szChem_3[])
{
	int i;

	for(i=0; i<nDihe_Para_SC_Rec; i++)	{
		if( (strcmp(szChem_1, szChem_Dihe_SC_Rec[i][0])==0) && (strcmp(szChem_2, szChem_Dihe_SC_Rec[i][1])==0) && (strcmp(szChem_3, szChem_Dihe_SC_Rec[i][2])==0) )	{
			return 1;
		}
		if( (strcmp(szChem_1, szChem_Dihe_SC_Rec[i][3])==0) && (strcmp(szChem_2, szChem_Dihe_SC_Rec[i][2])==0) && (strcmp(szChem_3, szChem_Dihe_SC_Rec[i][1])==0) )	{
			return 1;
		}
	}
	return 0;
}

void Write_Full_PRM(void)
{
	int i;
	FILE *fOut;
	double k_angle, theta, k_Urey, b0_Urey;
	char szNewChem[16];

	szBondPara[0] = szAnglePara[0] = szDihedralPara[0] = szImproPara[0] = szLJPara[0] = 0;

	strcat(szBondPara, "BONDS\n");
	strcat(szBondPara, "CT1     C         250.000     1.4900\n");
	strcat(szBondPara, "CT3     C         250.000     1.4900\n");
	strcat(szBondPara, "CT3     CT1       222.500     1.5380\n");
	strcat(szBondPara, "HA      CT3       322.000     1.1110\n");
	strcat(szBondPara, "HB      CT1       330.000     1.0800\n");
	strcat(szBondPara, "NH1     C         370.000     1.3450\n");
	strcat(szBondPara, "NH1     CT1       320.000     1.4300\n");
	strcat(szBondPara, "NH1     CT3       320.000     1.4300\n");
	strcat(szBondPara, "NH1     H         440.000     0.9970\n");
	strcat(szBondPara, "O       C         620.000     1.2300\n");
	strcat(szBondPara, "\n");

	strcat(szAnglePara, "ANGLES\n");
	strcat(szAnglePara, "CT1     NH1     C          50.000   120.0000\n");
	strcat(szAnglePara, "CT3     CT1     C          52.000   108.0000\n");
	strcat(szAnglePara, "CT3     NH1     C          50.000   120.0000\n");
	strcat(szAnglePara, "H       NH1     C          34.000   123.0000\n");
	strcat(szAnglePara, "H       NH1     CT1        35.000   117.0000\n");
	strcat(szAnglePara, "H       NH1     CT3        35.000   117.0000\n");
	strcat(szAnglePara, "HA      CT3     C          33.000   109.5000    30.000    2.16300\n");
	strcat(szAnglePara, "HA      CT3     CT1        33.430   110.1000    22.530    2.17900\n");
	strcat(szAnglePara, "HA      CT3     HA         35.500   108.4000     5.400    1.80200\n");
	strcat(szAnglePara, "HB      CT1     C          50.000   109.5000\n");
	strcat(szAnglePara, "HB      CT1     CT3        35.000   111.0000\n");
	strcat(szAnglePara, "NH1     C       CT1        80.000   116.5000\n");
	strcat(szAnglePara, "NH1     C       CT3        80.000   116.5000\n");
	strcat(szAnglePara, "NH1     CT1     C          50.000   107.0000\n");
	strcat(szAnglePara, "NH1     CT1     CT3        70.000   113.5000\n");
	strcat(szAnglePara, "NH1     CT1     HB         48.000   108.0000\n");
	strcat(szAnglePara, "NH1     CT3     HA         51.500   109.5000\n");
	strcat(szAnglePara, "O       C       CT1        80.000   121.0000\n");
	strcat(szAnglePara, "O       C       CT3        80.000   121.0000\n");
	strcat(szAnglePara, "O       C       NH1        80.000   122.5000\n");
	strcat(szAnglePara, "\n");

	

	strcat(szDihedralPara, "DIHEDRALS\n");
	strcat(szDihedralPara, "C       CT1     NH1     C          0.2000         1      180.0\n");
	strcat(szDihedralPara, "CT3     C       NH1     CT1        1.6000         1        0.0\n");
	strcat(szDihedralPara, "CT3     C       NH1     CT1        2.5000         2      180.0\n");
	strcat(szDihedralPara, "CT3     CT1     NH1     C          1.8000         1        0.0\n");
	strcat(szDihedralPara, "CT3     NH1     C       CT1        1.6000         1        0.0\n");
	strcat(szDihedralPara, "CT3     NH1     C       CT1        2.5000         2      180.0\n");
	strcat(szDihedralPara, "H       NH1     C       CT1        2.5000         2      180.0\n");
	strcat(szDihedralPara, "H       NH1     C       CT3        2.5000         2      180.0\n");
	strcat(szDihedralPara, "H       NH1     CT1     C          0.0000         1        0.0\n");
	strcat(szDihedralPara, "H       NH1     CT1     CT3        0.0000         1        0.0\n");
	strcat(szDihedralPara, "HA      CT3     NH1     C          0.0000         3        0.0\n");
	strcat(szDihedralPara, "HA      CT3     NH1     H          0.0000         3        0.0\n");
	strcat(szDihedralPara, "HB      CT1     NH1     C          0.0000         1        0.0\n");
	strcat(szDihedralPara, "HB      CT1     NH1     H          0.0000         1        0.0\n");
	strcat(szDihedralPara, "NH1     C       CT1     CT3        0.0000         1        0.0\n");
	strcat(szDihedralPara, "NH1     C       CT1     HB         0.0000         1        0.0\n");
	strcat(szDihedralPara, "NH1     C       CT1     NH1        0.6000         1        0.0\n");
	strcat(szDihedralPara, "NH1     C       CT3     HA         0.0000         3        0.0\n");
	strcat(szDihedralPara, "O       C       CT1     CT3        1.4000         1        0.0\n");
	strcat(szDihedralPara, "O       C       CT1     HB         0.0000         1        0.0\n");
	strcat(szDihedralPara, "O       C       CT1     NH1        0.0000         1        0.0\n");
	strcat(szDihedralPara, "O       C       CT3     HA         0.0000         3      180.0\n");
	strcat(szDihedralPara, "O       C       NH1     CT1        2.5000         2      180.0\n");
	strcat(szDihedralPara, "O       C       NH1     CT3        2.5000         2      180.0\n");
	strcat(szDihedralPara, "O       C       NH1     H          2.5000         2      180.0\n");
	strcat(szDihedralPara, "X       CT1     CT3     X          0.2000         3        0.0\n");
	strcat(szDihedralPara, "\n");

	strcat(szImproPara, "IMPROPERS\n");
	strcat(szImproPara, "NH1     X       X       H         20.0000         0        0.0\n");
	strcat(szImproPara, "O       X       X       C        120.0000         0        0.0\n");
	strcat(szImproPara, "\n");


	strcat(szLJPara, "NONBONDED\n");
	strcat(szLJPara, "!                EMIN     RMIN/2              EMIN/2     RMIN  (FOR 1-4'S)\n");
	strcat(szLJPara, "!             (KCAL/MOL)    (A)\n");

	strcat(szLJPara, "C        0.00    -0.110000    2.000000   0.00    -0.110000    2.000000\n");
	strcat(szLJPara, "CT1      0.00    -0.020000    2.275000   0.00    -0.010000    1.900000\n");
	strcat(szLJPara, "CT3      0.00    -0.080000    2.060000   0.00    -0.010000    1.900000\n");
	strcat(szLJPara, "H        0.00    -0.046000    0.224500   0.00    -0.046000    0.224500\n");
	strcat(szLJPara, "HA       0.00    -0.022000    1.320000   0.00    -0.022000    1.320000\n");
	strcat(szLJPara, "HB       0.00    -0.022000    1.320000   0.00    -0.022000    1.320000\n");
	strcat(szLJPara, "NH1      0.00    -0.200000    1.850000   0.00    -0.200000    1.550000\n");
	strcat(szLJPara, "O        0.00    -0.120000    1.700000   0.00    -0.120000    1.400000\n");

	strcat(szLJPara, "\n");
	

	Read_PRM_Entries("sc.prm", szBondPara_SC, szAnglePara_SC, szDihedralPara_SC, szImproPara_SC, szLJPara_SC);


	fOut = fopen("full.prm", "w");

	fprintf(fOut, "%s", szBondPara);
	fprintf(fOut, "%s", szBondPara_SC);
	fprintf(fOut, "%-8s %-8s %9.3lf %10.4lf\n", "CT1", szChemName_Full[Idx_Cb_Full], k_b_Ca_Cb, b0_Ca_Cb);	// bond at the interface
	fprintf(fOut, "\n");

	fprintf(fOut, "%s", szAnglePara);
	fprintf(fOut, "%s", szAnglePara_SC);
	// angle at the interface, assuming X-Ca-Cb
	fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf\n", "NH1", "CT1", szChemName_Full[Idx_Cb_Full], 70.000, 111.8);
	fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf\n",  "HB", "CT1", szChemName_Full[Idx_Cb_Full], 35.000, 109.2);
	fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf\n",   "C", "CT1", szChemName_Full[Idx_Cb_Full], 52.000, 110.5);
	fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf\n",  "CC", "CT1", szChemName_Full[Idx_Cb_Full], 52.000, 110.5);	// for the case ACE-MOL-CT2
	for(i=0; i<nBond_Type_Cb; i++)	{
		if(Gaff_Sidechain)	{
			Query_Angle_Para_GAFF("C3",Bonded_Type_Cb_Org_Chem[nBond_Type_Cb], Bonded_Type_Cb_Org_Chem[i], k_angle, theta, k_Urey, b0_Urey);
		}
		else {	// CGenFF
			Query_Angle_Para_GAFF("CG311",Bonded_Type_Cb_Org_Chem[nBond_Type_Cb], Bonded_Type_Cb_Org_Chem[i], k_angle, theta, k_Urey, b0_Urey);
		}
		if(Locate_Character(Bonded_Type_Cb[i], '_') < 0)	{
			sprintf(szNewChem, "%s_",Bonded_Type_Cb[i]);	// chem name for SC atom
		}
		else	{
			strcpy(szNewChem, Bonded_Type_Cb[i]);
		}

		if(fabs(b0_Urey) < 1.0E-2)	{	// zero
			fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf\n", "CT1", szChemName_Full[Idx_Cb_Full], szNewChem, k_angle, theta);
		}
		else {
			fprintf(fOut, "%-8s %-8s %-8s %9.3lf %10.4lf %9.4lf %10.5lf\n", "CT1", szChemName_Full[Idx_Cb_Full], szNewChem, k_angle, theta, k_Urey, b0_Urey);
		}
	}
	fprintf(fOut, "\n");


	fprintf(fOut, "%s", szDihedralPara);
	fprintf(fOut, "%s", szDihedralPara_SC);
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "CC", "NH1", 0.0000, 1, 0.0);	// for the case ACE-MOL-CT2
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "CC",   "O", 1.4000, 1, 0.0);	// for the case ACE-MOL-CT2
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "C", "NH1", 0.0000, 1, 0.0);
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "C",   "O", 1.4000, 1, 0.0);
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "NH1", "C", 1.8000, 1, 0.0);
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", szChemName_Full[Idx_Cb_Full], "CT1", "NH1", "H", 0.0000, 1, 0.0);
	fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", "X", "CT1", szChemName_Full[Idx_Cb_Full], "X", 0.0000, 3, 0.0);
	for(i=0; i<nBond_Type_Cb; i++)	{
		if(Locate_Character(Bonded_Type_Cb[i], '_') < 0)	{
			sprintf(szNewChem, "%s_", Bonded_Type_Cb[i]);	// chem name for SC atom
		}
		else	{
			strcpy(szNewChem, Bonded_Type_Cb[i]);
		}

		if( Is_Existing_Dihe_Para_SC("X", szChemName_Full[Idx_Cb_Full], szNewChem) == 0 )	{
			fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf  %8d %10.1lf\n", "CT1", szChemName_Full[Idx_Cb_Full], szNewChem, "X", 0.0000, 1, 0.0);	// the parameters for this dihedral will be fitted anyway. 
		}
	}
	fprintf(fOut, "\n");



	fprintf(fOut, "%s", szImproPara);
	fprintf(fOut, "%s", szImproPara_SC);
	Output_PRM_Improper(fOut);
	fprintf(fOut, "\n");

	fprintf(fOut, "%s", szLJPara);
	fprintf(fOut, "%s", szLJPara_SC);
	fprintf(fOut, "\n");

//	fprintf(fOut, "END\n");

	fclose(fOut);
}

void Add_Chem_Name_Postfix(char szChem[])
{
	if( (strcmp(szChem, "X")!=0) && (Locate_Character(szChem, '_') < 0) )	{
		strcat(szChem, "_");
	}
}

void Read_PRM_Entries(char szName[], char szPrm_Bond[], char szPrm_Angle[], char szPrm_Dihedral[], char szPrm_Impro[], char szPrm_LJ[])
{
	char szErrorMsg[256], szLine[256], *ReadLine;
	char szChemName[4][256];
	double fDummy_1, fDummy_2, fDummy_3, fDummy_4, fDummy_5, fDummy_6;
	FILE *fIn;
	int ReadItem;

	fIn = fopen(szName, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open parameter file: %s", szName);
		Quit_With_Error_Msg(szErrorMsg);
	}

	//start	to read entries for bond
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "ANGLES", 6)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%lf%lf", szChemName[0], szChemName[1], &fDummy_1, &fDummy_2);
		if(ReadItem == 4)	{
			if( (strcmp(szChemName[0], "HT_W")==0) || (strcmp(szChemName[0], "OT_W")==0) )	{	// skip the parameters for tip3p
				continue;
			}
			if( Is_A_Non_Used_ChemName(szChemName[0]) || Is_A_Non_Used_ChemName(szChemName[1]) )	{	// skip the parameters for nonused chem types
				continue;
			}
			Add_Chem_Name_Postfix(szChemName[0]);
			Add_Chem_Name_Postfix(szChemName[1]);
			sprintf(szLine, "%-8s %-8s %9.3lf %10.4lf\n", szChemName[0], szChemName[1], fDummy_1, fDummy_2);
			strcat(szPrm_Bond, szLine);
		}
	}
	//end	to read entries for bond

	//start	to read entries for angle
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "DIHEDRALS", 9)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%lf%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], &fDummy_1, &fDummy_2, &fDummy_3, &fDummy_4);
		if(ReadItem == 5)	{
			if( (strcmp(szChemName[0], "HT_W")==0) || (strcmp(szChemName[0], "OT_W")==0) )	{	// skip the parameters for tip3p
				continue;
			}
			if( Is_A_Non_Used_ChemName(szChemName[0]) || Is_A_Non_Used_ChemName(szChemName[1]) || Is_A_Non_Used_ChemName(szChemName[2]) )	{	// skip the parameters for nonused chem types
				continue;
			}
			Add_Chem_Name_Postfix(szChemName[0]);
			Add_Chem_Name_Postfix(szChemName[1]);
			Add_Chem_Name_Postfix(szChemName[2]);
			sprintf(szLine, "%-8s %-8s %-8s %9.3lf %10.4lf\n", szChemName[0], szChemName[1], szChemName[2], fDummy_1, fDummy_2);
			strcat(szPrm_Angle, szLine);
		}
		else if(ReadItem == 7)	{
			if( Is_A_Non_Used_ChemName(szChemName[0]) || Is_A_Non_Used_ChemName(szChemName[1]) || Is_A_Non_Used_ChemName(szChemName[2]) )	{	// skip the parameters for nonused chem types
				continue;
			}
			Add_Chem_Name_Postfix(szChemName[0]);
			Add_Chem_Name_Postfix(szChemName[1]);
			Add_Chem_Name_Postfix(szChemName[2]);
			sprintf(szLine, "%-8s %-8s %-8s %9.3lf %10.4lf %9.3lf %10.5lf\n", szChemName[0], szChemName[1], szChemName[2], fDummy_1, fDummy_2, fDummy_3, fDummy_4);
			strcat(szPrm_Angle, szLine);
		}
	}
	//end	to read entries for angle

	//start	to read entries for dihedral
	nDihe_Para_SC_Rec = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "IMPROPERS", 9)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			if( Is_A_Non_Used_ChemName(szChemName[0]) || Is_A_Non_Used_ChemName(szChemName[1]) || Is_A_Non_Used_ChemName(szChemName[2]) || Is_A_Non_Used_ChemName(szChemName[3]) )	{	// skip the parameters for nonused chem types
				continue;
			}
			Add_Chem_Name_Postfix(szChemName[0]);
			Add_Chem_Name_Postfix(szChemName[1]);
			Add_Chem_Name_Postfix(szChemName[2]);
			Add_Chem_Name_Postfix(szChemName[3]);
			sprintf(szLine, "%-8s %-8s %-8s %-8s %9.4lf  %8.0lf %10.1lf\n", szChemName[0], szChemName[1], szChemName[2], szChemName[3], fDummy_1, fDummy_2, fDummy_3);

			strcat(szPrm_Dihedral, szLine);

			strcpy(szChem_Dihe_SC_Rec[nDihe_Para_SC_Rec][0], szChemName[0]);
			strcpy(szChem_Dihe_SC_Rec[nDihe_Para_SC_Rec][1], szChemName[1]);
			strcpy(szChem_Dihe_SC_Rec[nDihe_Para_SC_Rec][2], szChemName[2]);
			strcpy(szChem_Dihe_SC_Rec[nDihe_Para_SC_Rec][3], szChemName[3]);
			nDihe_Para_SC_Rec++;
		}
	}
	//end	to read entries for dihedral

	//start	to read entries for improper dihedral
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "NONBONDED", 9)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			if( Is_A_Non_Used_ChemName(szChemName[0]) || Is_A_Non_Used_ChemName(szChemName[1]) || Is_A_Non_Used_ChemName(szChemName[2]) || Is_A_Non_Used_ChemName(szChemName[3]) )	{	// skip the parameters for nonused chem types
				continue;
			}
			Add_Chem_Name_Postfix(szChemName[0]);
			Add_Chem_Name_Postfix(szChemName[1]);
			Add_Chem_Name_Postfix(szChemName[2]);
			Add_Chem_Name_Postfix(szChemName[3]);
			sprintf(szLine, "%-8s %-8s %-8s %-8s %9.4lf  %8.0lf %10.1lf\n", szChemName[0], szChemName[1], szChemName[2], szChemName[3], fDummy_1, fDummy_2, fDummy_3);
			strcat(szPrm_Impro, szLine);
		}
	}
	//end	to read entries for improper dihedral

	//start	to read entries for LJ
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%lf%lf%lf%lf%lf%lf", szChemName[0], &fDummy_1, &fDummy_2, &fDummy_3, &fDummy_4, &fDummy_5, &fDummy_6);
		if( (ReadItem == 4) || (ReadItem == 7) )	{
			if( (strcmp(szChemName[0], "HT_W")==0) || (strcmp(szChemName[0], "OT_W")==0) )	{	// skip the parameters for tip3p
				continue;
			}
			if( Is_A_Non_Used_ChemName(szChemName[0]) )	{	// skip the parameters for nonused chem types
				continue;
			}

			Add_Chem_Name_Postfix(szChemName[0]);
			if(ReadItem == 4)	{
				sprintf(szLine, "%-8s  0.00 %12.6lf%12.6lf\n", szChemName[0], fDummy_2, fDummy_3);
			}
			else if(ReadItem == 7)	{
				sprintf(szLine, "%-8s  0.00 %12.6lf%12.6lf  0.00 %12.6lf%12.6lf\n", szChemName[0], fDummy_2, fDummy_3, fDummy_5, fDummy_6);
			}
			strcat(szPrm_LJ, szLine);
		}
	}
	//end	to read entries for LJ

	
	fclose(fIn);
}

void Determine_Bond_Para_CA_CB_GAFF(void)
{
	int ReadItem;
	char szChemType[256], szChemName[2][256];
	FILE *fIn;
	double k_bond, b0;

	strcpy(szChemType, Mol.ChemName[Idx_Cb_SC]);
//	strcpy(szChemType, szOrgChemName_SC[Idx_Cb_SC]);

	k_b_Ca_Cb = -1.0;	// an invalid parameter for k_Bond

	fIn = fopen("gaff-bond-c3-organized.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file gaff-bond-c3-organized.txt for reading.\nQuit\n");
	}

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadItem = fscanf(fIn, "%s%s%lf%lf", szChemName[0], szChemName[1], &k_bond, &b0);
		if(ReadItem == 4)	{
			if(strcmp(szChemName[1],szChemType)==0)	{	// the type of Cb
				k_b_Ca_Cb = k_bond;
				b0_Ca_Cb = b0;
				break;
			}
		}
	}

	fclose(fIn);

	if(k_b_Ca_Cb < 0.0)	{
		Quit_With_Error_Msg("Fail to find the bonding parameter for Cb in gaff-bond-c3-organized.txt.\nQuit\n");
	}
}


void Determine_Bond_Para_CA_CB_CGenFF(void)
{
	int ReadItem;
	char szChemType[16], szChemName[2][16];
	FILE *fIn;
	double k_bond, b0;

	strcpy(szChemType, szOrgChemName_SC[Idx_Cb_SC]);

	k_b_Ca_Cb = -1.0;	// an invalid parameter for k_Bond

	fIn = fopen("cgenff_bond_cg311.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file gaff-bond-c3-organized.txt for reading.\nQuit\n");
	}

	while(1)	{
		ReadItem = fscanf(fIn, "%s%s%lf%lf", szChemName[0], szChemName[1], &k_bond, &b0);
		if(ReadItem == 4)	{
			if(strcmp(szChemName[1],szChemType)==0)	{	// the type of Cb
				k_b_Ca_Cb = k_bond;
				b0_Ca_Cb = b0;
				break;
			}
		}
	}

	fclose(fIn);

	if(k_b_Ca_Cb < 0.0)	{
		Quit_With_Error_Msg("Fail to find the bonding parameter for Cb in cgenff_bond_cg311.txt.\nQuit\n");
	}
}


void To_Upper_Case(char szBuff[])
{
	char gap;
	int i=0;

	gap = 'A'-'a';

	while(1)	{
		if(szBuff[i]==0)	{
			break;
		}
		if( (szBuff[i]>='a') && (szBuff[i]<='z') )	{
			szBuff[i] += gap;
		}
		i++;
	}
}

void Read_Angle_Para_GAFF(void)
{
	FILE *fIn;
	char szLine[256], *ReadLine;
	int ReadItem;

	fIn = fopen("gaff-angle-c3.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file: gaff-angle-c3.txt for read.\nQuit\n");
	}

	nRec_Angle_Para_Gaff = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%lf%lf", szAngleGaffChem[nRec_Angle_Para_Gaff][0], szAngleGaffChem[nRec_Angle_Para_Gaff][1], 
			szAngleGaffChem[nRec_Angle_Para_Gaff][2], &(k_Angle_Gaff[nRec_Angle_Para_Gaff]), &(theta_Angle_Gaff[nRec_Angle_Para_Gaff]));
		if(ReadItem == 5)	{
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][0]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][1]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][2]);
			nRec_Angle_Para_Gaff++;
		}
	}


	fclose(fIn);
}

void Read_Angle_Para_CGenFF(void)
{
	FILE *fIn;
	char szLine[256], *ReadLine;
	int ReadItem;

	fIn = fopen("cgenff_angle_cg311.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file: cgenff_angle_cg311.txt for read.\nQuit\n");
	}

	nRec_Angle_Para_Gaff = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%lf%lf%lf%lf", szAngleGaffChem[nRec_Angle_Para_Gaff][0], szAngleGaffChem[nRec_Angle_Para_Gaff][1], 
			szAngleGaffChem[nRec_Angle_Para_Gaff][2], &(k_Angle_Gaff[nRec_Angle_Para_Gaff]), &(theta_Angle_Gaff[nRec_Angle_Para_Gaff]), 
			&(Para_k_Urey[nRec_Angle_Para_Gaff]), &(Para_b0_Urey[nRec_Angle_Para_Gaff]));

		if(ReadItem == 5)	{
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][0]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][1]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][2]);
			Para_k_Urey[nRec_Angle_Para_Gaff] = 0.0;
			Para_b0_Urey[nRec_Angle_Para_Gaff] = 0.0;
			nRec_Angle_Para_Gaff++;
		}
		else if(ReadItem == 7)	{
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][0]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][1]);
			To_Upper_Case(szAngleGaffChem[nRec_Angle_Para_Gaff][2]);
			nRec_Angle_Para_Gaff++;
		}
	}

	fclose(fIn);
}


void Query_Angle_Para_GAFF(char szChem_1[], char szChem_2[], char szChem_3[], double& k_Angle, double& theta, double& k_Urey, double& b0_Urey)
{
	int i, iPos;
	char szErrorMsg[256], szChem_1_New[256], szChem_2_New[256], szChem_3_New[256];
	char szChemName[8][N_LEN_CHEM_NAME];
	double Para_List[MAX_DIH_ITEM*3];

	strcpy(szChem_1_New, szChem_1);
	strcpy(szChem_2_New, szChem_2);
	strcpy(szChem_3_New, szChem_3);

	iPos = Locate_Character(szChem_1_New, '_');
	if(iPos > 0)	{
		szChem_1_New[iPos] = 0;
	}
	iPos = Locate_Character(szChem_2_New, '_');
	if(iPos > 0)	{
		szChem_2_New[iPos] = 0;
	}
	iPos = Locate_Character(szChem_3_New, '_');
	if(iPos > 0)	{
		szChem_3_New[iPos] = 0;
	}

	for(i=0; i<nRec_Angle_Para_Gaff; i++)	{
		if( (strcmp(szChem_1_New, szAngleGaffChem[i][0])==0) && (strcmp(szChem_2_New, szAngleGaffChem[i][1])==0) && (strcmp(szChem_3_New, szAngleGaffChem[i][2])==0) )	{
			k_Angle = k_Angle_Gaff[i];
			theta = theta_Angle_Gaff[i];
			k_Urey = Para_k_Urey[i];
			b0_Urey = Para_b0_Urey[i];
			return;
		}
	}

	for(i=0; i<nRec_Angle_Para_Gaff; i++)	{
		if( (strcmp(szChem_3_New, szAngleGaffChem[i][0])==0) && (strcmp(szChem_2_New, szAngleGaffChem[i][1])==0) && (strcmp(szChem_1_New, szAngleGaffChem[i][2])==0) )	{
			k_Angle = k_Angle_Gaff[i];
			theta = theta_Angle_Gaff[i];
			k_Urey = Para_k_Urey[i];
			b0_Urey = Para_b0_Urey[i];
			return;
		}
	}

	if(Gaff_Sidechain)	{
		sprintf(szErrorMsg, "Fatal error!\nCan't find the parameters for angle %s, %s, %s\nQuit.\n", szChem_1, szChem_2, szChem_3);
		Quit_With_Error_Msg(szErrorMsg);
	}
	else	{
		strcpy(szChemName[0], szChem_1_New);
		strcpy(szChemName[1], szChem_2_New);
		strcpy(szChemName[2], szChem_3_New);
		if(ff_Methyl_Mol.GetPara_Angle(szChemName, Para_List) < 0)	{
			sprintf(szErrorMsg, "Fatal error!\nCan't find the parameters for angle %s, %s, %s\nQuit.\n", szChem_1, szChem_2, szChem_3);
			Quit_With_Error_Msg(szErrorMsg);
		}
		else	{
			k_Angle = Para_List[0];
			theta = Para_List[1];
			k_Urey = Para_List[2];
			b0_Urey = Para_List[3];
		}
	}
	
	return;
}

int Exist_Type_in_List_Cb(char szType[])
{
	for(int i=0; i<nBond_Type_Cb; i++)	{
		if(strcmp(szType, Bonded_Type_Cb[i])==0)	{
			return i;
		}
	}

	return -1;
}

void Determine_Atom_Bonded_with_Cb(void)
{
	int i, iPos, ia, ib;

	memset(F_Chem_Type_Changed, 0, sizeof(int)*Mol.nAtom);

	nBond_Type_Cb = 0;
	for(i=0; i<Mol.nBond; i++)	{
		iPos = 2 * i;
		ia = Mol.BondList[iPos  ];
		ib = Mol.BondList[iPos+1];
		if( (ia != Idx_H_To_del) && (ib != Idx_H_To_del) )	{
			if(ia == Idx_Cb_SC)	{
				if(Gaff_Sidechain == 0)	{	// CGenFF, update the atom type
					if(strcmp(Mol.ChemName[ib], szOrgChemName_SC[ib]) != 0)	{
						F_Chem_Type_Changed[ib] = 1;
						strcpy(Mol.ChemName[ib], szOrgChemName_SC[ib]);
					}
				}
				if( Exist_Type_in_List_Cb(Mol.ChemName[ib]) < 0)	{
					strcpy(Bonded_Type_Cb[nBond_Type_Cb], Mol.ChemName[ib]);
					strcpy(Bonded_Type_Cb_Org_Chem[nBond_Type_Cb], szOrgChemName_SC[ib]);
					nBond_Type_Cb++;
				}
			}
			else if(ib == Idx_Cb_SC)	{
				if(Gaff_Sidechain == 0)	{	// CGenFF, update the atom type
					if(strcmp(Mol.ChemName[ia], szOrgChemName_SC[ia]) != 0)	{
						F_Chem_Type_Changed[ia] = 1;
						strcpy(Mol.ChemName[ia], szOrgChemName_SC[ia]);
					}
				}
				if( Exist_Type_in_List_Cb(Mol.ChemName[ia]) < 0)	{
					strcpy(Bonded_Type_Cb[nBond_Type_Cb], Mol.ChemName[ia]);
					strcpy(Bonded_Type_Cb_Org_Chem[nBond_Type_Cb], szOrgChemName_SC[ia]);
					nBond_Type_Cb++;
				}
			}
		}
	}

	if(strcmp(Mol.ChemName[Idx_Cb_SC], szOrgChemName_SC[Idx_Cb_SC]) != 0)	{
		F_Chem_Type_Changed[Idx_Cb_SC] = 1;
		strcpy(Mol.ChemName[Idx_Cb_SC], szOrgChemName_SC[Idx_Cb_SC]);
	}
	strcpy(Bonded_Type_Cb[nBond_Type_Cb], szOrgChemName_SC[Idx_Cb_SC]);	// Chem name of CB
	strcpy(Bonded_Type_Cb_Org_Chem[nBond_Type_Cb], szOrgChemName_SC[Idx_Cb_SC]);	// Chem name of CB

	for(i=0; i<=nBond_Type_Cb; i++)	{
		Modify_Chem_Name_SC_Back(Bonded_Type_Cb[i]);
		To_Upper_Case(Bonded_Type_Cb[i]);
		To_Upper_Case(Bonded_Type_Cb_Org_Chem[i]);
	}

	for(i=0; i<Mol.nAtom; i++)	{
		strcpy(szChemName_SC_Bak[i], Mol.ChemName[i]);
	}
}

void Modify_Chem_Name_SC_Back(char szBuff[])
{
	int nLen=0;

	nLen = strlen(szBuff);
	if(szBuff[nLen-1] == '_')	{
		szBuff[nLen-1] = 0;
	}
}

void Output_RTF_Improper(FILE *fOut)
{
	int Idx[4], i, j, iPos;

	for(i=0; i<Mol.nImpro; i++)	{
		iPos = 4*i;
		for(j=0; j<4; j++)	{
			Idx[j] = Mol.ImprDihedralList[iPos+j];
			Idx[j] = Idx_SC_in_Full_Mol[Idx[j]];
			if(Idx[j] < 0)	{	// H to be deleted
				Idx[j] = IDX_CA;
			}
		}
//		fprintf(fOut, "IMPH %-7s%-7s%-7s%-7s\n", szAtmName_Full[Idx[0]], szAtmName_Full[Idx[1]], szAtmName_Full[Idx[2]], szAtmName_Full[Idx[3]]);
		fprintf(fOut, "IMPR %-7s%-7s%-7s%-7s\n", szAtmName_Full[Idx[0]], szAtmName_Full[Idx[1]], szAtmName_Full[Idx[2]], szAtmName_Full[Idx[3]]);
	}	
}

void Output_PRM_Improper(FILE *fOut)
{
	int Idx[4], i, j, iPos, Output;

	for(i=0; i<Mol.nImpro; i++)	{
		iPos = 4*i;

		Output = 0;
		for(j=0; j<4; j++)	{
			Idx[j] = Mol.ImprDihedralList[iPos+j];
			Idx[j] = Idx_SC_in_Full_Mol[Idx[j]];
			if(Idx[j] < 0)	{	// H to be deleted
				Idx[j] = IDX_CA;
				Output = 1;
			}
		}
		if(Output)	{
			fprintf(fOut, "%-8s %-8s %-8s %-8s %9.4lf %9.0lf %10.1lf\n", 
				szChemName_Full[Idx[0]], szChemName_Full[Idx[1]], szChemName_Full[Idx[2]], szChemName_Full[Idx[3]], 
				Mol.Para_k_ImpDih[i], Mol.Para_Type_ImpDih[i], Mol.Para_Imp_phi[i]*radian);
		}
	}	
}

void Build_Dist_Matrix(void)
{
	int i, j, k, l;
	int Atom_i, Atom_j, Atom_k, Atom_l;

	//start	to constrcut distance matrix
	memset(DistMatrix, 99, sizeof(char)*MAX_ATOM*MAX_ATOM);	//99, an arbitrary large numer
	for(i=0; i<nAtom_Full; i++)	{	// i-i, itself. |d| = zero
		DistMatrix[i][i] = 0;
	}

	for(i=0; i<nAtom_Full; i++)	{	//start	enumeration
		Atom_i = i;

		for(j=0; j<Bond_Count[Atom_i]; j++)	{	//i->j
			Atom_j = Bond_Array[Atom_i][j];

			if(DistMatrix[Atom_i][Atom_j] > 1)	{
				DistMatrix[Atom_i][Atom_j] = 1;
				DistMatrix[Atom_j][Atom_i] = 1;
			}

			for(k=0; k<Bond_Count[Atom_j]; k++)	{	//i->j->k
				Atom_k = Bond_Array[Atom_j][k];

				if(DistMatrix[Atom_i][Atom_k] > 2)	{
					DistMatrix[Atom_i][Atom_k] = 2;
					DistMatrix[Atom_k][Atom_i] = 2;
				}
				
				for(l=0; l<Bond_Count[Atom_k]; l++)	{	//i->j->k->l
					Atom_l = Bond_Array[Atom_k][l];
					
					if(DistMatrix[Atom_i][Atom_l] > 3)	{
						DistMatrix[Atom_i][Atom_l] = 3;
						DistMatrix[Atom_l][Atom_i] = 3;
					}
				}
			}
		}
	}
	//end	to constrcut distance matrix

	//start	to build a list of nonbonded atom pairs
	nNonbond_Pair = 0;
	for(i=0; i<nAtom_Full; i++)	{
		for(j=i+1; j<nAtom_Full; j++)	{
			if( (Is_BB_Atom[i] != Is_BB_Atom[j]) && (DistMatrix[i][j] >=3) )	{	// one from BB and one from side chain
				NonBonded_Pair[nNonbond_Pair][0] = i;
				NonBonded_Pair[nNonbond_Pair][1] = j;

//				if(DistMatrix[i][j] == 3)	{	//1-4 interactions
//					Para_LJ_Pair_Epsilon[nNonbond_Pair] = sqrt( E_min_Full[i] * E_min_Full[j] );
//					Para_LJ_Pair_Sigma[nNonbond_Pair] = ( R_min_Full[i] + R_min_Full[j] );
//				}
//				else	{
					Para_LJ_Pair_Epsilon[nNonbond_Pair] = sqrt( E_min_Full[i] * E_min_Full[j] );
					Para_LJ_Pair_Sigma[nNonbond_Pair] = ( R_min_Full[i] + R_min_Full[j] );
//				}

				Para_LJ_Pair_Sigma_Pow_6[nNonbond_Pair] = Para_LJ_Pair_Sigma[nNonbond_Pair]*Para_LJ_Pair_Sigma[nNonbond_Pair]*Para_LJ_Pair_Sigma[nNonbond_Pair];
				Para_LJ_Pair_Sigma_Pow_6[nNonbond_Pair] *= Para_LJ_Pair_Sigma_Pow_6[nNonbond_Pair];
				Para_LJ_Pair_Sigma_Pow_12[nNonbond_Pair] = Para_LJ_Pair_Sigma_Pow_6[nNonbond_Pair] * Para_LJ_Pair_Sigma_Pow_6[nNonbond_Pair];
				Para_Elec_Pair[nNonbond_Pair] = MD_COULOMB * cg_Full[i] * cg_Full[j];

				nNonbond_Pair++;
			}
		}
	}
	//end	to build a list of nonbonded atom pairs
}

void Cal_Nonbonded_VDW_Elec_BB_SC(double& E_VDW, double& E_Elec)
{
	int i, j, Idx;
	double dxij, dyij, dzij, Rij_SQ, Rij, R6, R12, dE;

	E_VDW = E_Elec = 0.0;
	
	for(Idx=0; Idx<nNonbond_Pair; Idx++)	{
		i = NonBonded_Pair[Idx][0];
		j = NonBonded_Pair[Idx][1];
		
		dxij=x_Full[j]-x_Full[i];
		dyij=y_Full[j]-y_Full[i];
		dzij=z_Full[j]-z_Full[i];
		
		Rij_SQ=dxij*dxij+dyij*dyij+dzij*dzij;
		
		//start	to calculate VDW energy and gradient
		R6=Rij_SQ*Rij_SQ*Rij_SQ;
		R12=R6*R6;
		
		
		dE = Para_LJ_Pair_Epsilon[Idx] * ( Para_LJ_Pair_Sigma_Pow_12[Idx]/R12 - 2.0*(Para_LJ_Pair_Sigma_Pow_6[Idx]/R6) );
		
		E_VDW += (dE);
		
//		printf("E_VDW:  %3d %3d  %20.15lf\n", i+1, j+1, dE);
		
		
		//start	to calculate elec energy and gradient
		Rij = sqrt(Rij_SQ);
		dE = Para_Elec_Pair[Idx] / Rij;
		E_Elec += dE;
		
	}
}

/*
void Read_Org_Chem_Type_Side_Chain(void)
{
	char szName[]="org-sc.rtf", szErrorMsg[256], szLine[256], *ReadLine, szTag[256], szChemName_Org_SC[256], szTmp[256];
	FILE *fIn;
	int nAtom_Local, ReadItem;
	double chg=0.0;

	fIn = fopen(szName, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szName);
		Quit_With_Error_Msg(szErrorMsg);
	}

	nAtom_Local = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		else	{
			if(strncmp(szLine, "ATOM", 4)==0)	{
				ReadItem = sscanf(szLine, "%s%s%s%lf", szTmp, szTag, szChemName_Org_SC, &chg);
				if(ReadItem == 4)	{
					strcpy(szOrgChemName_SC[nAtom_Local], szChemName_Org_SC);
					To_Upper_Case(szOrgChemName_SC[nAtom_Local]);
					nAtom_Local++;
				}
			}
		}
	}

	fclose(fIn);

	if(nAtom_Local != Mol.nAtom)	{
		Quit_With_Error_Msg("The number of atoms in org-sc.rtf is NOT consistent with sc.rtf.\nQuit\n");
	}
}
*/


void Read_Chem_Type_Methyl_Side_Chain(void)
{
	char szName[]="methyl_mol.rtf", szErrorMsg[256], szLine[256], *ReadLine, szTag[256], szChemName[256], szTmp[256];
	FILE *fIn;
	int nAtom_Local, ReadItem, i;
	double chg=0.0;

	fIn = fopen(szName, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szName);
		Quit_With_Error_Msg(szErrorMsg);
	}

	nAtom_Local = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		else	{
			if(strncmp(szLine, "ATOM", 4)==0)	{
				ReadItem = sscanf(szLine, "%s%s%s%lf", szTmp, szTag, szChemName, &chg);
				if(ReadItem == 4)	{
					strcpy(szChemName_Methyl_SC[nAtom_Local], szChemName);
					To_Upper_Case(szChemName_Methyl_SC[nAtom_Local]);
					nAtom_Local++;
				}
			}
		}
	}

	fclose(fIn);

	if(nAtom_Local != (Mol.nAtom+3))	{
		Quit_With_Error_Msg("The number of atoms in org-sc.rtf is NOT consistent with sc.rtf.\nQuit\n");
	}

	for(i=0; i<Idx_H_To_del; i++)	{
		strcpy(szOrgChemName_SC[i], szChemName_Methyl_SC[i]);
	}
	for(i=Idx_H_To_del+1; i<Mol.nAtom; i++)	{
		strcpy(szOrgChemName_SC[i], szChemName_Methyl_SC[i-1]);
	}
}

void Check_SC_Parameters(void)
{
	int i, j, iPos, Atom_1, Atom_2, Atom_3, Atom_4, LocalCount;
	char szChemName[8][N_LEN_CHEM_NAME], szErrorMsg[256];
	double Para_List[MAX_DIH_ITEM*3];

	ff.Quit_on_Error = 0;	// to check which parameters are needed

	ff_Methyl_Mol.ReadForceField("methyl_mol.prm");
	ff_Methyl_Mol.Quit_on_Error = 0;

	nBond_Add = nAngle_Add = nDihedral_Add = nImproper_Add = nLJ_Add = 0;

	//start	to generate the list of new bond entries
	iPos = 0;
	for(i=0; i<Mol.nBond; i++, iPos+=2)	{
		Atom_1 = Mol.BondList[iPos  ];
		Atom_2 = Mol.BondList[iPos+1];

		if( (Idx_H_To_del == Atom_1) || (Idx_H_To_del == Atom_2) )	{
			continue;
		}

		if( (F_Chem_Type_Changed[Atom_1] + F_Chem_Type_Changed[Atom_2]) == 0 )	{
			continue;
		}

		strcpy(szChemName[0], Mol.ChemName[Atom_1]);
		strcpy(szChemName[1], Mol.ChemName[Atom_2]);

		if(ff.GetPara_Bond(szChemName, Para_List) < 0)	{	// Need to add new bond parameters
			if(ff_Methyl_Mol.GetPara_Bond(szChemName, Para_List) < 0)	{	// fail to find the parameters, then use current parameters
			}
			else	{
				Mol.Para_k_b[i] = Para_List[0];
				Mol.Para_b0[i] = Para_List[1];
			}
			strcpy(Bond_Rec_Add[nBond_Add].Chem[0], szChemName[0]);
			strcpy(Bond_Rec_Add[nBond_Add].Chem[1], szChemName[1]);
			Bond_Rec_Add[nBond_Add].para[0] = Mol.Para_k_b[i];
			Bond_Rec_Add[nBond_Add].para[1] = Mol.Para_b0[i];
			To_Add_Bond[nBond_Add] = 1;
			nBond_Add++;
		}
	}
	//end	to generate the list of new bond entries

	//start	to re-organize the new bond entries, delete redundant entries
	for(i=0; i<nBond_Add; i++)	{
		for(j=i+1; j<nBond_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Bond[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(Bond_Rec_Add[i].Chem[0], Bond_Rec_Add[j].Chem[0])==0) && (strcmp(Bond_Rec_Add[i].Chem[1], Bond_Rec_Add[j].Chem[1])==0) ) || 
				( (strcmp(Bond_Rec_Add[i].Chem[0], Bond_Rec_Add[j].Chem[1])==0) && (strcmp(Bond_Rec_Add[i].Chem[1], Bond_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(Bond_Rec_Add[i].para[0]-Bond_Rec_Add[j].para[0]) < 1.0E-7) && (fabs(Bond_Rec_Add[i].para[1]-Bond_Rec_Add[j].para[1]) < 1.0E-7) )	{
					To_Add_Bond[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new bond entries, delete redundant entries


	//start	to assign parameters for angle
	iPos = 0;
	for(i=0; i<Mol.nAngle; i++, iPos+=3)	{
		Atom_1 = Mol.AngleList[iPos  ];
		Atom_2 = Mol.AngleList[iPos+1];
		Atom_3 = Mol.AngleList[iPos+2];

		if( (Idx_H_To_del == Atom_1) || (Idx_H_To_del == Atom_2) || (Idx_H_To_del == Atom_3) )	{
			continue;
		}

		if( (F_Chem_Type_Changed[Atom_1] + F_Chem_Type_Changed[Atom_2] + F_Chem_Type_Changed[Atom_3]) == 0 )	{
			continue;
		}

		strcpy(szChemName[0], Mol.ChemName[Atom_1]);
		strcpy(szChemName[1], Mol.ChemName[Atom_2]);
		strcpy(szChemName[2], Mol.ChemName[Atom_3]);

		if(ff.GetPara_Angle(szChemName, Para_List) < 0)	{	// Need to add new angle parameters
			if(ff_Methyl_Mol.GetPara_Angle(szChemName, Para_List) < 0)	{	// fail to find the parameters, then use current parameters
			}
			else	{
				Mol.Para_k_a[i] = Para_List[0];
				Mol.Para_theta0[i] = Para_List[1] * radianInv;
				Mol.Para_k_Urey[i] = Para_List[2];
				Mol.Para_b0_Urey[i] = Para_List[3];
			}
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[0], szChemName[0]);
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[1], szChemName[1]);
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[2], szChemName[2]);

			Angle_Rec_Add[nAngle_Add].para[0] = Mol.Para_k_a[i];
			Angle_Rec_Add[nAngle_Add].para[1] = Mol.Para_theta0[i]*radian;
			Angle_Rec_Add[nAngle_Add].para[2] = Mol.Para_k_Urey[i];
			Angle_Rec_Add[nAngle_Add].para[3] = Mol.Para_b0_Urey[i];
			To_Add_Angle[nAngle_Add] = 1;
			nAngle_Add++;
		}
	}
	//end	to assign parameters for angle

	//start	to re-organize the new angle entries, delete redundant entries
	for(i=0; i<nAngle_Add; i++)	{
		for(j=i+1; j<nAngle_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Angle[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(Angle_Rec_Add[i].Chem[0], Angle_Rec_Add[j].Chem[0])==0) && (strcmp(Angle_Rec_Add[i].Chem[1], Angle_Rec_Add[j].Chem[1])==0) && (strcmp(Angle_Rec_Add[i].Chem[2], Angle_Rec_Add[j].Chem[2])==0) ) || 
				( (strcmp(Angle_Rec_Add[i].Chem[0], Angle_Rec_Add[j].Chem[2])==0) && (strcmp(Angle_Rec_Add[i].Chem[1], Angle_Rec_Add[j].Chem[1])==0) && (strcmp(Angle_Rec_Add[i].Chem[2], Angle_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(Angle_Rec_Add[i].para[0]-Angle_Rec_Add[j].para[0]) < 1.0E-7) && (fabs(Angle_Rec_Add[i].para[1]-Angle_Rec_Add[j].para[1]) < 1.0E-7) )	{
					To_Add_Angle[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new Angle entries, delete redundant entries


	//start	to assign parameters for dihedral
	iPos = 0;
	for(i=0; i<Mol.nDihedral; i++, iPos+=4)	{
		Atom_1 = Mol.DihedralList[iPos  ];
		Atom_2 = Mol.DihedralList[iPos+1];
		Atom_3 = Mol.DihedralList[iPos+2];
		Atom_4 = Mol.DihedralList[iPos+3];

		if( (Idx_H_To_del == Atom_1) || (Idx_H_To_del == Atom_2) || (Idx_H_To_del == Atom_3) || (Idx_H_To_del == Atom_4) )	{
			continue;
		}

		if( (F_Chem_Type_Changed[Atom_1] + F_Chem_Type_Changed[Atom_2] + F_Chem_Type_Changed[Atom_3] + F_Chem_Type_Changed[Atom_4]) == 0 )	{
			continue;
		}

		strcpy(szChemName[0], Mol.ChemName[Atom_1]);
		strcpy(szChemName[1], Mol.ChemName[Atom_2]);
		strcpy(szChemName[2], Mol.ChemName[Atom_3]);
		strcpy(szChemName[3], Mol.ChemName[Atom_4]);

		memset(Para_List, 0, sizeof(double)*MAX_DIH_ITEM*3);
		if(ff.GetPara_Dihedral(szChemName, Para_List) < 0)	{	// Need to add new dihedral parameters
			if(ff_Methyl_Mol.GetPara_Dihedral(szChemName, Para_List) < 0)	{	// fail to find the parameters, then use current parameters
			}
			else	{
				for(j=1; j<MAX_DIH_ITEM; j++)	{
					if(fabs(Para_List[j*3]) > 1.0E-50)	{	//valid parameter
						Mol.Para_k_Dih[i][j] = Para_List[j*3];
						Mol.Para_phi[i][j] = Para_List[j*3+2] * radianInv;
					}
				}
			}

			LocalCount = 0;
			for(j=1; j<=6; j++)	{
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[0], szChemName[0]);
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[1], szChemName[1]);
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[2], szChemName[2]);
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[3], szChemName[3]);
				
				Dihedral_Rec_Add[nDihedral_Add].para[0] = Mol.Para_k_Dih[i][j];
				Dihedral_Rec_Add[nDihedral_Add].para[1] = 1.0*j;
				Dihedral_Rec_Add[nDihedral_Add].para[2] = Mol.Para_phi[i][j]*radian;
				if(fabs(Dihedral_Rec_Add[nDihedral_Add].para[0]) > 1.0E-6)	{	// a valid entry
					To_Add_Dihedral[nDihedral_Add] = 1;
					nDihedral_Add++;
					LocalCount++;
				}
			}
			if(LocalCount == 0)	{
				j = 3;
				Dihedral_Rec_Add[nDihedral_Add].para[0] = 0.0;
				Dihedral_Rec_Add[nDihedral_Add].para[1] = 1.0*j;
				Dihedral_Rec_Add[nDihedral_Add].para[2] = Mol.Para_phi[i][j]*radian;
				To_Add_Dihedral[nDihedral_Add] = 1;
				nDihedral_Add++;
			}
		}
	}
	//end	to assign parameters for dihedral


	//start	to re-organize the new dihedral entries, delete redundant entries
	for(i=0; i<nDihedral_Add; i++)	{
		for(j=i+1; j<nDihedral_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Dihedral[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(Dihedral_Rec_Add[i].Chem[0], Dihedral_Rec_Add[j].Chem[0])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[1], Dihedral_Rec_Add[j].Chem[1])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[2], Dihedral_Rec_Add[j].Chem[2])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[3], Dihedral_Rec_Add[j].Chem[3])==0) ) || 
				( (strcmp(Dihedral_Rec_Add[i].Chem[0], Dihedral_Rec_Add[j].Chem[3])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[1], Dihedral_Rec_Add[j].Chem[2])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[2], Dihedral_Rec_Add[j].Chem[1])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[3], Dihedral_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(Dihedral_Rec_Add[i].para[0]-Dihedral_Rec_Add[j].para[0]) < 1.0E-3) && (fabs(Dihedral_Rec_Add[i].para[1]-Dihedral_Rec_Add[j].para[1]) < 1.0E-3) && (fabs(Dihedral_Rec_Add[i].para[2]-Dihedral_Rec_Add[j].para[2]) < 1.0E-3) )	{
					To_Add_Dihedral[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new Dihedral entries, delete redundant entries


	//start	to assign parameters for improper dihedral
	iPos = 0;
	for(i=0; i<Mol.nImpro; i++, iPos+=4)	{
		Atom_1 = Mol.ImprDihedralList[iPos  ];
		Atom_2 = Mol.ImprDihedralList[iPos+1];
		Atom_3 = Mol.ImprDihedralList[iPos+2];
		Atom_4 = Mol.ImprDihedralList[iPos+3];

		if( (Idx_H_To_del == Atom_1) || (Idx_H_To_del == Atom_2) || (Idx_H_To_del == Atom_3) || (Idx_H_To_del == Atom_4) )	{
			continue;
		}

		if( (F_Chem_Type_Changed[Atom_1] + F_Chem_Type_Changed[Atom_2] + F_Chem_Type_Changed[Atom_3] + F_Chem_Type_Changed[Atom_4]) == 0 )	{
			continue;
		}

		strcpy(szChemName[0], Mol.ChemName[Atom_1]);
		strcpy(szChemName[1], Mol.ChemName[Atom_2]);
		strcpy(szChemName[2], Mol.ChemName[Atom_3]);
		strcpy(szChemName[3], Mol.ChemName[Atom_4]);

		if(ff.GetPara_ImproDIhedral(szChemName, Para_List) < 0)	{	// Need to add new improper parameters
			if(ff_Methyl_Mol.GetPara_ImproDIhedral(szChemName, Para_List) < 0)	{	// fail to find the parameters, then use current parameters
			}
			else	{
				Mol.Para_k_ImpDih[i] = Para_List[0];
				Mol.Para_Imp_phi[i] = Para_List[1] * radianInv;
				Mol.Para_Type_ImpDih[i] = Para_List[2];
			}

			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[0], szChemName[0]);
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[1], szChemName[1]);
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[2], szChemName[2]);
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[3], szChemName[3]);
			
			ImproDihedral_Rec_Add[nImproper_Add].para[0] = Mol.Para_k_ImpDih[i];
			ImproDihedral_Rec_Add[nImproper_Add].para[1] = Mol.Para_Imp_phi[i]*radian;
			ImproDihedral_Rec_Add[nImproper_Add].para[2] = Mol.Para_Type_ImpDih[i];
			if(Mol.Para_k_ImpDih[i] > 1.0E-3)	{	// a valid entry
				To_Add_Improper[nImproper_Add] = 1;
				nImproper_Add++;
			}
		}
	}
	//end	to assign parameters for improper dihedral

	//start	to re-organize the new improper entries, delete redundant entries
	for(i=0; i<nImproper_Add; i++)	{
		for(j=i+1; j<nImproper_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Improper[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(ImproDihedral_Rec_Add[i].Chem[0], ImproDihedral_Rec_Add[j].Chem[0])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[1], ImproDihedral_Rec_Add[j].Chem[1])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[2], ImproDihedral_Rec_Add[j].Chem[2])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[3], ImproDihedral_Rec_Add[j].Chem[3])==0) ) || 
				( (strcmp(ImproDihedral_Rec_Add[i].Chem[0], ImproDihedral_Rec_Add[j].Chem[3])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[1], ImproDihedral_Rec_Add[j].Chem[2])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[2], ImproDihedral_Rec_Add[j].Chem[1])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[3], ImproDihedral_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(ImproDihedral_Rec_Add[i].para[0]-ImproDihedral_Rec_Add[j].para[0]) < 1.0E-3) && (fabs(ImproDihedral_Rec_Add[i].para[1]-ImproDihedral_Rec_Add[j].para[1]) < 1.0E-3) && (fabs(ImproDihedral_Rec_Add[i].para[2]-ImproDihedral_Rec_Add[j].para[2]) < 1.0E-3) )	{
					To_Add_Improper[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new improper entries, delete redundant entries

	//start	to assign parameters for LJ
	for(i=0; i<Mol.nAtom; i++)	{
		if(F_Chem_Type_Changed[i] == 0)	{
			continue;
		}

		strcpy(szChemName[0], Mol.ChemName[i]);

		if(ff.GetPara_LJ(szChemName, Para_List) < 0)	{	// Need to add new dihedral parameters
			if(ff_Methyl_Mol.GetPara_LJ(szChemName, Para_List) < 0)	{	// must be something wrong
				sprintf(szErrorMsg, "Fail to determine the LJ parameters for atom %s in methyl_mol.prm.\n");
				Quit_With_Error_Msg(szErrorMsg);
			}
			else	{
				Mol.Para_LJ_Epsilon[i] = Para_List[1];
				Mol.Para_LJ_Sigma[i] = Para_List[2];
				Mol.Para_LJ_Epsilon_14[i] = Para_List[4];
				Mol.Para_LJ_Sigma_14[i] = Para_List[5];
			}
			strcpy(LJ_Rec_Add[nLJ_Add].Chem, szChemName[0]);
			
			LJ_Rec_Add[nLJ_Add].para[0] = 0.0;
			LJ_Rec_Add[nLJ_Add].para[1] = Mol.Para_LJ_Epsilon[i];
			LJ_Rec_Add[nLJ_Add].para[2] = Mol.Para_LJ_Sigma[i];
			LJ_Rec_Add[nLJ_Add].para[3] = 0.0;
			LJ_Rec_Add[nLJ_Add].para[4] = Mol.Para_LJ_Epsilon_14[i];
			LJ_Rec_Add[nLJ_Add].para[5] = Mol.Para_LJ_Sigma_14[i];
			To_Add_LJ[nLJ_Add] = 1;
			nLJ_Add++;
		}

	}
	//end	to assign parameters for LJ

	//start	to re-organize the new LJ entries, delete redundant entries
	for(i=0; i<nLJ_Add; i++)	{
		for(j=i+1; j<nLJ_Add; j++)	{	// to find out those redundant entries
			if(To_Add_LJ[j] == 0)	{	// already deleted
				continue;
			}
			if( strcmp(LJ_Rec_Add[i].Chem, LJ_Rec_Add[j].Chem) == 0 )	{
				To_Add_LJ[j] = 0;
			}
		}
	}
	//end	to re-organize the new LJ entries, delete redundant entries
}

void Add_SC_Parameters_New_Types(void)
{
	int j;
	char szLine[256];

	for(j=0; j<nBond_Add; j++)	{
		if(To_Add_Bond[j])	{
			Add_Chem_Name_Postfix(Bond_Rec_Add[j].Chem[0]);
			Add_Chem_Name_Postfix(Bond_Rec_Add[j].Chem[1]);
			sprintf(szLine, "%-8s %-8s  %8.3lf %7.3lf\n", Bond_Rec_Add[j].Chem[0], Bond_Rec_Add[j].Chem[1], Bond_Rec_Add[j].para[0], Bond_Rec_Add[j].para[1]);
			strcat(szBondPara_SC, szLine);
		}
	}
	
	for(j=0; j<nAngle_Add; j++)	{
		if(To_Add_Angle[j])	{
			Add_Chem_Name_Postfix(Angle_Rec_Add[j].Chem[0]);
			Add_Chem_Name_Postfix(Angle_Rec_Add[j].Chem[1]);
			Add_Chem_Name_Postfix(Angle_Rec_Add[j].Chem[2]);
			if(Angle_Rec_Add[j].para[3] == 0.0)	{
				sprintf(szLine, "%-8s %-8s %-8s  %8.3lf %12.3lf\n", 
					Angle_Rec_Add[j].Chem[0], Angle_Rec_Add[j].Chem[1], Angle_Rec_Add[j].Chem[2], Angle_Rec_Add[j].para[0], Angle_Rec_Add[j].para[1]);
			}
			else	{
				sprintf(szLine, "%-8s %-8s %-8s  %8.3lf %12.3lf %9.3lf %10.5lf\n", 
					Angle_Rec_Add[j].Chem[0], Angle_Rec_Add[j].Chem[1], Angle_Rec_Add[j].Chem[2], Angle_Rec_Add[j].para[0], Angle_Rec_Add[j].para[1], 
					Angle_Rec_Add[j].para[2], Angle_Rec_Add[j].para[3]);
			}
			strcat(szAnglePara_SC, szLine);
		}
	}
	
	for(j=0; j<nDihedral_Add; j++)	{
		if(To_Add_Dihedral[j])	{
			Add_Chem_Name_Postfix(Dihedral_Rec_Add[j].Chem[0]);
			Add_Chem_Name_Postfix(Dihedral_Rec_Add[j].Chem[1]);
			Add_Chem_Name_Postfix(Dihedral_Rec_Add[j].Chem[2]);
			Add_Chem_Name_Postfix(Dihedral_Rec_Add[j].Chem[3]);
			sprintf(szLine, "%-8s %-8s %-8s %-8s %9.4lf  %8.0lf %10.1lf\n", 
				Dihedral_Rec_Add[j].Chem[0], Dihedral_Rec_Add[j].Chem[1], Dihedral_Rec_Add[j].Chem[2], Dihedral_Rec_Add[j].Chem[3], 
				Dihedral_Rec_Add[j].para[0], Dihedral_Rec_Add[j].para[1], Dihedral_Rec_Add[j].para[2]);
			strcat(szDihedralPara_SC, szLine);
		}
	}

	for(j=0; j<nImproper_Add; j++)	{
		if(To_Add_Improper[j])	{
			Add_Chem_Name_Postfix(ImproDihedral_Rec_Add[j].Chem[0]);
			Add_Chem_Name_Postfix(ImproDihedral_Rec_Add[j].Chem[1]);
			Add_Chem_Name_Postfix(ImproDihedral_Rec_Add[j].Chem[2]);
			Add_Chem_Name_Postfix(ImproDihedral_Rec_Add[j].Chem[3]);
			sprintf(szLine, "%-8s %-8s %-8s %-8s  %7.3lf   %3.0lf %9.1lf\n", 
				ImproDihedral_Rec_Add[j].Chem[0], ImproDihedral_Rec_Add[j].Chem[1], ImproDihedral_Rec_Add[j].Chem[2], ImproDihedral_Rec_Add[j].Chem[3], 
				ImproDihedral_Rec_Add[j].para[0], ImproDihedral_Rec_Add[j].para[2], ImproDihedral_Rec_Add[j].para[1]);
			strcat(szImproPara_SC, szLine);
		}
	}

	for(j=0; j<nLJ_Add; j++)	{
		if(To_Add_LJ[j])	{
			Add_Chem_Name_Postfix(LJ_Rec_Add[j].Chem);
			if( (fabs(LJ_Rec_Add[j].para[1]-LJ_Rec_Add[j].para[4]) < 1.0E-4) && (fabs(LJ_Rec_Add[j].para[2]-LJ_Rec_Add[j].para[5]) < 1.0E-4) )	{	// Not output LJ14 parameters
				sprintf(szLine, "%-8s  0.00 %12.6lf%12.6lf\n", LJ_Rec_Add[j].Chem, LJ_Rec_Add[j].para[1], LJ_Rec_Add[j].para[2]);
			}
			else	{
				sprintf(szLine, "%-8s  0.00 %12.6lf%12.6lf  0.00 %12.6lf%12.6lf\n", LJ_Rec_Add[j].Chem, LJ_Rec_Add[j].para[1], LJ_Rec_Add[j].para[2], LJ_Rec_Add[j].para[4], LJ_Rec_Add[j].para[5]);
			}
			strcat(szLJPara_SC, szLine);
		}
	}

}

int Is_A_Non_Used_ChemName(char szName[])
{
	int i, nAtom;

	nAtom = Mol.nAtom;
	for(i=0; i<nAtom; i++)	{
		if(i == Idx_H_To_del)	{
			continue;
		}
		if(strcmp(szName, szChemName_SC_Bak[i])==0)	{
			return 0;
		}
	}
	if( (strcmp(szName, "X")==0) || (strcmp(szName, "x")==0) )	{
		return 0;
	}

	return 1;
}

