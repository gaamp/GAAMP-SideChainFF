#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE	(100000)

char szRtf_charmm[]="top_all27_prot_na.rtf";
char szPrm_charmm[]="par_all27_prot_na.prm";

char szRtf_new[]="aa.rtf";
char szPrm_new[]="aa.prm";

void Merge_Rtf(void);
void Merge_Prm(void);
void Quit_With_Message(char szMsg[]);

int main(void)
{
	Merge_Rtf();
	Merge_Prm();

	return 0;
}

char szRtf_mass[4096];
char szRtf_Resi[65536];
char szRtf_Full[MAX_LINE][256];

void Merge_Rtf(void)
{
	FILE *fIn, *fOut;
	char szLine[256], *ReadLine, szErrorMsg[256];
	int i, nLine, Idx_mass, Idx_Resi;

	szRtf_mass[0] = 0;
	szRtf_Resi[0] = 0;

	fIn = fopen(szRtf_new, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szRtf_new);
		Quit_With_Message(szErrorMsg);
	}

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "RESI MOL", 8)==0)	{
			strcat(szRtf_Resi, szLine);
			break;
		}
		if(strncmp(szLine, "MASS", 4)==0)	{
			strcat(szRtf_mass, szLine);
		}
	}

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strncmp(szLine, "END", 3)==0)	{
			break;
		}
		strcat(szRtf_Resi, szLine);
	}

	fclose(fIn);


	fIn = fopen(szRtf_charmm, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szRtf_charmm);
		Quit_With_Message(szErrorMsg);
	}

	Idx_mass = Idx_Resi = -1;

	nLine = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "!MOL_MASS", 9)==0)	{
			if(Idx_mass < 0)	{
				Idx_mass = nLine;
			}
		}
		if(strncmp(szLine, "DECL", 4)==0)	{
			if(Idx_mass < 0)	{
				Idx_mass = nLine-1;
			}
		}
		if(strncmp(szLine, "!MOL_RESI", 9)==0)	{
			if(Idx_Resi < 0)	{
				Idx_Resi = nLine;
			}
		}
		if(strncmp(szLine, "RESI ", 5)==0)	{
			if(Idx_Resi < 0)	{
				Idx_Resi = nLine-1;
			}
		}
		strcpy(szRtf_Full[nLine], szLine);
		nLine++;
	}

	fclose(fIn);

	if(Idx_mass < 0)	{
		Quit_With_Message("Fail to indentify the position for inserting mass entries!\n");
	}

	if(Idx_Resi < 0)	{
		Quit_With_Message("Fail to indentify the position for inserting RESI entries!\n");
	}

	fOut = fopen(szRtf_charmm, "w");
	for(i=0; i<nLine; i++)	{
		fprintf(fOut, "%s", szRtf_Full[i]);
		if(i == Idx_mass)	{
			fprintf(fOut, "\n%s\n\n", szRtf_mass);
		}
		if(i == Idx_Resi)	{
			fprintf(fOut, "\n%s\n\n", szRtf_Resi);
		}
	}
	fclose(fOut);
}

char szPrm_Bond[65536];
char szPrm_Angle[65536];
char szPrm_Dihedral[65536];
char szPrm_Improper[65536];
char szPrm_Nonbonded[65536];
char szPrm_Full[MAX_LINE][256];

void Merge_Prm(void)
{
	FILE *fIn, *fOut;
	char szLine[256], *ReadLine, szChemName[4][256], szErrorMsg[256];
	int i, nLine, Idx_Bond, Idx_Angle, Idx_Dihedral, Idx_Improper, Idx_Nonbonded, ReadItem;
	double fDummy_1=0.0, fDummy_2, fDummy_3;

	szPrm_Bond[0] = szPrm_Angle[0] = szPrm_Dihedral[0] = szPrm_Improper[0] = szPrm_Nonbonded[0] = 0;

	fIn = fopen(szPrm_new, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szPrm_new);
		Quit_With_Message(szErrorMsg);
	}

	while(1)	{	// bond
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "ANGLE", 5)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%lf%lf", szChemName[0], szChemName[1], &fDummy_1, &fDummy_2);
		if(ReadItem == 4)	{
			strcat(szPrm_Bond, szLine);
		}
	}

	while(1)	{	// angle
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "DIHEDRAL", 8)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%lf%lf", szChemName[0], szChemName[1], szChemName[2], &fDummy_1, &fDummy_2);
		if(ReadItem == 5)	{
			strcat(szPrm_Angle, szLine);
		}
	}

	while(1)	{	// dihedral
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "IMPROPER", 8)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			strcat(szPrm_Dihedral, szLine);
		}
	}

	while(1)	{	// improper
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "NONBONDED", 9)==0)	{
			break;
		}
		ReadItem = sscanf(szLine, "%s%s%s%s%lf%lf%lf", szChemName[0], szChemName[1], szChemName[2], szChemName[3], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 7)	{
			strcat(szPrm_Improper, szLine);
		}
	}

	while(1)	{	// LJ
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		ReadItem = sscanf(szLine, "%s%lf%lf%lf", szChemName[0], &fDummy_1, &fDummy_2, &fDummy_3);
		if(ReadItem == 4)	{
			strcat(szPrm_Nonbonded, szLine);
		}
	}

	fclose(fIn);


	Idx_Bond = Idx_Angle = Idx_Dihedral = Idx_Improper = Idx_Nonbonded = -1;
	fIn = fopen(szPrm_charmm, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file: %s\n", szPrm_charmm);
		Quit_With_Message(szErrorMsg);
	}

	nLine = 0;
	while(1)	{
		if(fIn == NULL)	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if(strncmp(szLine, "!MOL_BOND", 9)==0)	{
			if(Idx_Bond < 0)	{
				Idx_Bond = nLine;
			}
		}
		if(strncmp(szLine, "ANGLES", 6)==0)	{
			if(Idx_Bond < 0)	{
				Idx_Bond = nLine - 1;
			}
		}

		if(strncmp(szLine, "!MOL_ANGLE", 10)==0)	{
			if(Idx_Angle < 0)	{
				Idx_Angle = nLine;
			}
		}
		if(strncmp(szLine, "DIHEDRALS", 9)==0)	{
			if(Idx_Angle < 0)	{
				Idx_Angle = nLine - 1;
			}
		}

		if(strncmp(szLine, "!MOL_DIHEDRAL", 13)==0)	{
			if(Idx_Dihedral < 0)	{
				Idx_Dihedral = nLine;
			}
		}
		if(strncmp(szLine, "IMPROPER", 8)==0)	{
			if(Idx_Dihedral < 0)	{
				Idx_Dihedral = nLine - 1;
			}
		}


		if(strncmp(szLine, "!MOL_IMPROPER", 13)==0)	{
			if(Idx_Improper < 0)	{
				Idx_Improper = nLine;
			}
		}
		if(strncmp(szLine, "CMAP", 4)==0)	{
			if(Idx_Improper < 0)	{
				Idx_Improper = nLine - 1;
			}
		}

		if(strncmp(szLine, "!MOL_NONBONDED", 14)==0)	{
			if(Idx_Nonbonded < 0)	{
				Idx_Nonbonded = nLine;
			}
		}
		if(strncmp(szLine, "HBOND", 5)==0)	{
			if(Idx_Nonbonded < 0)	{
				Idx_Nonbonded = nLine - 1;
			}
		}

		strcpy(szPrm_Full[nLine], szLine);
		nLine++;
	}

	if(Idx_Bond < 0)	{
		Quit_With_Message("Fail to indentify the position to insert bond information!\n");
	}
	if(Idx_Angle < 0)	{
		Quit_With_Message("Fail to indentify the position to insert angle information!\n");
	}
	if(Idx_Dihedral < 0)	{
		Quit_With_Message("Fail to indentify the position to insert diheral information!\n");
	}
	if(Idx_Improper < 0)	{
		Quit_With_Message("Fail to indentify the position to insert improper information!\n");
	}
	if(Idx_Nonbonded < 0)	{
		Quit_With_Message("Fail to indentify the position to insert nonbonded information!\n");
	}

	fclose(fIn);

	fOut = fopen(szPrm_charmm, "w");
	for(i=0; i<nLine; i++)	{
		fprintf(fOut, "%s", szPrm_Full[i]);

		if(i == Idx_Bond)	{
			fprintf(fOut, "\n%s\n", szPrm_Bond);
		}
		if(i == Idx_Angle)	{
			fprintf(fOut, "\n%s\n", szPrm_Angle);
		}
		if(i == Idx_Dihedral)	{
			fprintf(fOut, "\n%s\n", szPrm_Dihedral);
		}
		if(i == Idx_Improper)	{
			fprintf(fOut, "\n%s\n", szPrm_Improper);
		}
		if(i == Idx_Nonbonded)	{
			fprintf(fOut, "\n%s\n", szPrm_Nonbonded);
		}
	}
	fclose(fOut);
}

void Quit_With_Message(char szMsg[])
{
	printf("%s\nQuit\n", szRtf_mass);
	exit(1);
}


