#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_ATOM	(256)
#define MAX_LEN_LINE	(256)

FILE *fFile_Run_Log;

char szPdbName[256];
int nAtom, Idx_H, Idx_Cb;
double x[MAX_ATOM], y[MAX_ATOM], z[MAX_ATOM];
double x_CH4[MAX_ATOM], y_CH4[MAX_ATOM], z_CH4[MAX_ATOM];
char szElemName[MAX_ATOM][16];

double vx_Ca_Cb, vy_Ca_Cb, vz_Ca_Cb;

void ReadPDB(char szNamePdb[]);
void Determine_CB(void);
double Normalize(double& vect_x, double& vect_y, double& vect_z);
double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b);
void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product);
void Save_Full_Pdb(char szName[]);
void Assign_CH4_Coord(void);
void Rotate_Side_Chain_Mol(void);

int main(int argc, char *argv[])
{
	FILE *fOut;

	fFile_Run_Log = fopen("log-cap-pdb-methyl.txt", "w");
	if(fFile_Run_Log==NULL)	{
		printf("Fail to create the log file.\n\n");
		exit(1);
	}

	if(argc != 3)	{
		printf("Usage: cap_pdb_methyl mol.pdb Idx_H\n");
		exit(1);
	}

	strcpy(szPdbName, argv[1]);
	Idx_H = atoi(argv[2]) - 1;

	ReadPDB(szPdbName);
	Determine_CB();

	Assign_CH4_Coord();
	Rotate_Side_Chain_Mol();
	Save_Full_Pdb("methyl_mol.pdb");

	fOut = fopen("idx_cb.txt", "w");
	if(Idx_Cb < Idx_H)	{
		fprintf(fOut, "%d", Idx_Cb+1);
	}
	else	{
		fprintf(fOut, "%d", Idx_Cb);
	}
	fclose(fOut);

	fclose(fFile_Run_Log);


	return 0;
}

void Save_Full_Pdb(char szName[])
{
	FILE *fOut;
	int i, iCount=0;
	char szElem_CH4[][16]={"C", "CL", "CL", "H", "H"};

	fOut = fopen(szName, "w");

	for(i=0; i<nAtom; i++)	{
		if(i == Idx_H)	{
			continue;
		}
		fprintf(fOut, "ATOM%7d  %-3s %-4sA%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00          %2s\n", 
			iCount+1, szElemName[i], "MOL ", 1, x[i], y[i], z[i],szElemName[i]);
		iCount++;
	}

	for(i=0; i<4; i++)	{
		fprintf(fOut, "ATOM%7d  %-3s %-4sA%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00          %2s\n", 
			iCount+1, szElem_CH4[i], "MOL ", 1, x_CH4[i], y_CH4[i], z_CH4[i],szElem_CH4[i]);
		iCount++;
	}

	fprintf(fOut, "END\n");

	fclose(fOut);
}


void Quit_With_Error_Msg(char szMsg[])
{
	fprintf(fFile_Run_Log, "%s", szMsg);
	fflush(fFile_Run_Log);
	exit(1);
}

void ReadPDB(char szNamePdb[])
{
	FILE *fIn;
	int ReadItem;
	char szLine[256], szErrorMsg[256], *ReadLine;
	double fTmp=0.0;

	fIn = fopen(szNamePdb, "r");
	if(fIn == NULL)	{
		sprintf(szErrorMsg, "Fail to open file %s\nQuit\n", szNamePdb);
		Quit_With_Error_Msg(szErrorMsg);
	}

	nAtom = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, MAX_LEN_LINE, fIn);
		if(ReadLine == NULL)	{
			break;
		}

		if( (strncmp(szLine, "ATOM", 4) == 0) || (strncmp(szLine, "HETATM", 6) == 0) )	{ 
			ReadItem = sscanf(szLine+30, "%lf %lf %lf", &(x[nAtom]), &(y[nAtom]), &(z[nAtom]));
			if(ReadItem == 3)	{
				sscanf(szLine+76, "%s", szElemName[nAtom]);
				nAtom++;
			}
			else	{
				sprintf(szErrorMsg, "Error in reading file: %s\n%s\nQuit\n", szNamePdb, szLine);
				Quit_With_Error_Msg(szErrorMsg);
			}
		}
	}
	fclose(fIn);
}

void Determine_CB(void)
{
	int i;
	double dx, dy, dz, R_SQ, R_SQ_Min=1.0E100;

	for(i=0; i<nAtom; i++)	{
		if(i==Idx_H)	{
			continue;
		}

		dx = x[i] - x[Idx_H];
		dy = y[i] - y[Idx_H];
		dz = z[i] - z[Idx_H];
		R_SQ = dx*dx + dy*dy + dz*dz;
		if(R_SQ < R_SQ_Min)	{
			R_SQ_Min = R_SQ;
			Idx_Cb = i;
		}
	}

}


#define LEN_C_H	(1.0967)
void Assign_CH4_Coord(void)	// assume alad is in alpha-helix form
{
	double vx, vy, vz, r, d_Ca_Cb, x_Ca, y_Ca, z_Ca;
	int nAtom_BB=19, IDX_H_L=4, IDX_CA=0;
	int Idx_SC_BB=IDX_H_L;

	x_CH4[ 0] =  -0.344;   y_CH4[ 0] =  -0.336;   z_CH4[ 0] =   0.000; 
	x_CH4[ 1] =   0.243;   y_CH4[ 1] =  -1.996;   z_CH4[ 1] =   0.000; 
	x_CH4[ 2] =   0.243;   y_CH4[ 2] =   0.493;   z_CH4[ 2] =   1.437; 
	x_CH4[ 3] =   0.013;   y_CH4[ 3] =   0.168;   z_CH4[ 3] =  -0.874; 
	x_CH4[ 4] =  -1.414;   y_CH4[ 4] =  -0.336;   z_CH4[ 4] =   0.000; 

	vx = x_CH4[IDX_H_L] - x_CH4[IDX_CA];
	vy = y_CH4[IDX_H_L] - y_CH4[IDX_CA];
	vz = z_CH4[IDX_H_L] - z_CH4[IDX_CA];

	r = Normalize(vx, vy, vz);

	x_CH4[IDX_H_L] = x_CH4[IDX_CA] + LEN_C_H * vx;	// generate the coordinates for H atom 
	y_CH4[IDX_H_L] = y_CH4[IDX_CA] + LEN_C_H * vy;
	z_CH4[IDX_H_L] = z_CH4[IDX_CA] + LEN_C_H * vz;


	//start	to determine the proper bond length betweeb Ca and Cb (it could be other element than carbon)
	if(strcmp(szElemName[Idx_Cb],"H")==0)	{	// should never happen
		d_Ca_Cb = 1.10;
	}
	else if(strcmp(szElemName[Idx_Cb],"B")==0)	{
		d_Ca_Cb = 1.56;
	}
	else if(strcmp(szElemName[Idx_Cb],"C")==0)	{
		d_Ca_Cb = 1.54;
	}
	else if(strcmp(szElemName[Idx_Cb],"SI")==0)	{
		d_Ca_Cb = 1.94;
	}
	else if(strcmp(szElemName[Idx_Cb],"N")==0)	{
		d_Ca_Cb = 1.47;
	}
	else if(strcmp(szElemName[Idx_Cb],"P")==0)	{
		d_Ca_Cb = 1.87;
	}
	else if(strcmp(szElemName[Idx_Cb],"O")==0)	{
		d_Ca_Cb = 1.43;
	}
	else if(strcmp(szElemName[Idx_Cb],"S")==0)	{
		d_Ca_Cb = 1.81;
	}
	else	{
		Quit_With_Error_Msg("Unsupported element at Cb position!\nQuit.\n");
	}
	//end	to determine the proper bond length betweeb Ca and Cb (it could be other element than carbon)


	vx = x_CH4[Idx_SC_BB] - x_CH4[IDX_CA];
	vy = y_CH4[Idx_SC_BB] - y_CH4[IDX_CA];
	vz = z_CH4[Idx_SC_BB] - z_CH4[IDX_CA];

	r = Normalize(vx, vy, vz);

	x_CH4[Idx_SC_BB] = x_CH4[IDX_CA] + d_Ca_Cb * vx;	// generate the coordinates for Cb atom 
	y_CH4[Idx_SC_BB] = y_CH4[IDX_CA] + d_Ca_Cb * vy;
	z_CH4[Idx_SC_BB] = z_CH4[IDX_CA] + d_Ca_Cb * vz;

	vx_Ca_Cb=vx; vy_Ca_Cb=vy; vz_Ca_Cb=vz;

	x_Ca = x_CH4[IDX_CA];
	y_Ca = y_CH4[IDX_CA];
	z_Ca = z_CH4[IDX_CA];

	//start	to translate the molecule to position Ca at origin
	for(int i=0; i<nAtom_BB; i++)	{
		x_CH4[i] -= x_Ca;
		y_CH4[i] -= y_Ca;
		z_CH4[i] -= z_Ca;
	}
	//end	to translate the molecule to position Ca at origin
}
#undef LEN_C_H

void Rotate_Side_Chain_Mol(void)
{
	double diag_x=vx_Ca_Cb, diag_y=vy_Ca_Cb, diag_z=vz_Ca_Cb;
	double cos_theta, sin_theta, RotM[3][3], dot_H_Cb;
	double Cen_x, Cen_y, Cen_z, x_New, y_New, z_New;
	double *x_Mol, *y_Mol, *z_Mol;
	double x_H_Cb, y_H_Cb, z_H_Cb;
	double x_H, y_H, z_H, dx, dy, dz;
	int i;

	x_Mol = x;
	y_Mol = y;
	z_Mol = z;

	//start	to do translation for the side chain molecule to make H atom at origin
	x_H = x_Mol[Idx_H];  y_H = y_Mol[Idx_H];  z_H = z_Mol[Idx_H];
	for(i=0; i<nAtom; i++)	{
		x_Mol[i] -= x_H;
		y_Mol[i] -= y_H;
		z_Mol[i] -= z_H;
	}
	//end	to do translation for the side chain molecule to make H atom at origin


	Normalize(diag_x, diag_y, diag_z);

	x_H_Cb = x_Mol[Idx_Cb] - x_Mol[Idx_H];
	y_H_Cb = y_Mol[Idx_Cb] - y_Mol[Idx_H];
	z_H_Cb = z_Mol[Idx_Cb] - z_Mol[Idx_H];
	Normalize(x_H_Cb, y_H_Cb, z_H_Cb);


	cos_theta = Dot_Product(x_H_Cb, y_H_Cb, z_H_Cb, diag_x, diag_y, diag_z);
	sin_theta = sqrt(1.0 - cos_theta*cos_theta);

	Cross_Product(x_H_Cb, y_H_Cb, z_H_Cb, diag_x, diag_y, diag_z, Cen_x, Cen_y, Cen_z);

	RotM[0][0] = Cen_x*Cen_x + (1-Cen_x*Cen_x)*cos_theta;
	RotM[0][1] = Cen_x*Cen_y*(1.0-cos_theta) - Cen_z*sin_theta;
	RotM[0][2] = Cen_x*Cen_z*(1.0-cos_theta) + Cen_y*sin_theta;
	
	RotM[1][0] = Cen_x*Cen_y*(1.0-cos_theta) + Cen_z*sin_theta;
	RotM[1][1] = Cen_y*Cen_y + (1-Cen_y*Cen_y)*cos_theta;
	RotM[1][2] = Cen_y*Cen_z*(1.0-cos_theta) - Cen_x*sin_theta;
	
	RotM[2][0] = Cen_x*Cen_z*(1.0-cos_theta) - Cen_y*sin_theta;
	RotM[2][1] = Cen_y*Cen_z*(1.0-cos_theta) + Cen_x*sin_theta;
	RotM[2][2] = Cen_z*Cen_z + (1-Cen_z*Cen_z)*cos_theta;

	//start	to calculate the determinant of RotM[3][3]
	double Sum=0.0;
	Sum = RotM[0][0] * ( RotM[1][1]*RotM[2][2] - RotM[1][2]*RotM[2][1] ) + 
		RotM[0][1] * ( RotM[1][2]*RotM[2][0] - RotM[1][0]*RotM[2][2] ) + 
		RotM[0][2] * ( RotM[1][0]*RotM[2][1] - RotM[1][1]*RotM[2][0] );
	//end	to calculate the determinant of RotM[3][3]


	for(i=0; i<nAtom; i++)	{
		x_New = RotM[0][0] * x_Mol[i] + RotM[0][1] * y_Mol[i] + RotM[0][2] * z_Mol[i];
		y_New = RotM[1][0] * x_Mol[i] + RotM[1][1] * y_Mol[i] + RotM[1][2] * z_Mol[i];
		z_New = RotM[2][0] * x_Mol[i] + RotM[2][1] * y_Mol[i] + RotM[2][2] * z_Mol[i];

		x_Mol[i] = x_New;
		y_Mol[i] = y_New;
		z_Mol[i] = z_New;
	}

	dot_H_Cb = Dot_Product(x_Mol[Idx_Cb]-x_Mol[Idx_H], y_Mol[Idx_Cb]-y_Mol[Idx_H], z_Mol[Idx_Cb]-z_Mol[Idx_H], diag_x, diag_y, diag_z);

	if(dot_H_Cb < 0.0)	{	// flip the coordinates
		for(i=0; i<nAtom; i++)	{
			x_Mol[i] = -x_Mol[i];
			y_Mol[i] = -y_Mol[i];
			z_Mol[i] = -z_Mol[i];
		}
	}

	dx = x_CH4[4] - x_Mol[Idx_Cb];
	dy = y_CH4[4] - y_Mol[Idx_Cb];
	dz = z_CH4[4] - z_Mol[Idx_Cb];

	//start	to translate
	for(i=0; i<nAtom; i++)	{
		x_Mol[i] += dx;
		y_Mol[i] += dy;
		z_Mol[i] += dz;
	}
	//end	to translate

}


inline double Dot_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b)
{
	return (x_a*x_b + y_a*y_b + z_a*z_b);
}

inline void Cross_Product(double x_a, double y_a, double z_a, double x_b, double y_b, double z_b, double& x_Product, double& y_Product, double& z_Product)
{
	x_Product = y_a*z_b - y_b*z_a;
	y_Product = z_a*x_b - z_b*x_a;
	z_Product = x_a*y_b - x_b*y_a;

	Normalize(x_Product, y_Product, z_Product);
}

double Normalize(double& vect_x, double& vect_y, double& vect_z)
{
	double dist, dist_Inv;

	dist = sqrt(vect_x*vect_x + vect_y*vect_y + vect_z*vect_z);
	dist_Inv = 1.0/dist;
	vect_x *= dist_Inv;
	vect_y *= dist_Inv;
	vect_z *= dist_Inv;
	return dist;
}

