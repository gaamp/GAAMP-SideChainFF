#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ff.h"

void Quit_With_Error_Msg(char szMsg[]);

FILE *fFile_Run_Log;	// will be shared by other source code


char szName_Force_Field[]="mol.prm";
char szName_Mol_Psf[]="mol.xpsf";
char szName_Mol_Crd[]="mol.crd";

CMol Mol;
CForceField ForceField;

int nAtom, *Order_of_Print=NULL;
int Start_New_Mol, End_New_Mol, Atom_Cb=-1, Atom_CA=-1;

#define N_ELEM	(109)
char Name_Elem[N_ELEM][16]={"H", "HE", "LI", "BE", "B", "C", "N", "O", "F", "NE", "NA", "MG", "AL", "SI", "P", "S", "CL", "K", "AR", "CA", 
		"SC", "TI", "V", "CR", "MN", "FE", "NI", "CO", "CU", "ZN", "GA", "GE", "AS", "SE", "BR", "KR", "RB", "SR", "Y", "ZR", "NB", "MO", "TC", 
		"RU", "RH", "PD", "AG", "CD", "IN", "SN", "SB", "I", "TE", "XE", "CS", "BA", "LA", "CE", "PR", "ND", "PM", "SM", "EU", "GD", "TB", "DY", 
		"HO", "ER", "TM", "YB", "LU", "HF", "TA", "W", "RE", "OS", "IR", "PT", "AU", "HG", "TL", "PB", "BI", "PO", "AT", "RN", "FR", "RA", "AC", 
		"PA", "TH", "NP", "U", "AM", "PU", "BK", "CM", "CF", "ES", "FM", "MD", "NO", "RF", "LR", "DB", "BH", "SG", "MT", "HS"};
double Mass_List[N_ELEM]={1.0079, 4.0026, 6.941, 9.0122, 10.811, 12.0107, 14.0067, 15.9994, 18.9984, 20.1797, 22.9897, 24.305, 26.9815, 28.0855, 
		30.9738, 32.065, 35.453, 39.0983, 39.948, 40.078, 44.9559, 47.867, 50.9415, 51.9961, 54.938, 55.845, 58.6934, 58.9332, 63.546, 65.39, 
		69.723, 72.64, 74.9216, 78.96, 79.904, 83.8, 85.4678, 87.62, 88.9059, 91.224, 92.9064, 95.94, 98, 101.07, 102.9055, 106.42, 107.8682, 
		112.411, 114.818, 118.71, 121.76, 126.9045, 127.6, 131.293, 132.9055, 137.327, 138.9055, 140.116, 140.9077, 144.24, 145, 150.36, 151.964, 
		157.25, 158.9253, 162.5, 164.9303, 167.259, 168.9342, 173.04, 174.967, 178.49, 180.9479, 183.84, 186.207, 190.23, 192.217, 195.078, 196.9665, 
		200.59, 204.3833, 207.2, 208.9804, 209, 210, 222, 223, 226, 227, 231.0359, 232.0381, 237, 238.0289, 243, 244, 247, 247, 251, 252, 257, 258, 
		259, 261, 262, 262, 264, 266, 268, 277};

char szFileElemList[]="elem-list.txt";
int AtomType[MAX_ATOM];


double Normalize(double& vect_x, double& vect_y, double& vect_z);
int DetermineAtomType(char szName[], double mass);
void To_Identify_Backbone_Atoms();	// not applicable for Pro (which has a ring)
void Write_ReOrdered_Pdb(char szName[]);
void Write_Side_Chain_Pdb(char szName[]);
void Write_ReOrdered_Crd(char szName[]);
void Write_ReOrdered_Rtf(char szName[]);	// no water, all are consistent with GAFF at this moment. Only atom orders are updated. 
void Build_Element_List(void);



int main(int argc, char *argv[])
{
	fFile_Run_Log = fopen("log-re-organize.txt", "w");
	if(fFile_Run_Log==NULL)	{
		printf("Fail to create the log file.\n\n");
		exit(1);
	}

	ForceField.ReadForceField(szName_Force_Field);

	Mol.ReadPSF(szName_Mol_Psf, 0);
//	Mol.ReadPSF("mol-ordered.xpsf", 0);
	Mol.AssignForceFieldParameters(&ForceField);
	Mol.ReadCRD(szName_Mol_Crd);
//	Mol.ReadPDB("ordered.pdb");

//	Mol.Cal_E(1);

	nAtom = Mol.nAtom;
	To_Identify_Backbone_Atoms();

	Write_ReOrdered_Pdb("ordered.pdb");
	Write_Side_Chain_Pdb("side-chain.pdb");	// used for a new charge and torsion fitting. chg(H) for atom 1 is fixed as 0. 

	Write_ReOrdered_Rtf("ordered.rtf");
	Build_Element_List();


	fclose(fFile_Run_Log);

	if(Order_of_Print)	{
		delete []Order_of_Print;
	}

	return 0;
}

#define MAX_LINE_RTF	(4096)
char szRtfTxt[MAX_LINE_RTF][256];

void Write_ReOrdered_Rtf(char szName[])
{
	FILE *fIn, *fOut;
	int i, nLine, FirstAtom=-1, LastAtom=-1, FirstRes=1, Count=0, Idx;
	char *ReadLine;

	fIn = fopen("mol.rtf", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file: mol.rtf\nQuit\n");
	}
	
	nLine = 0;
	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szRtfTxt[nLine], 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		else	{
			if(strncmp(szRtfTxt[nLine], "RESI TIP3", 9)==0)	{
				FirstRes = 0;
			}
			if(FirstRes)	{
				if(strncmp(szRtfTxt[nLine], "ATOM", 4)==0)	{
					LastAtom = nLine;
					if(FirstAtom < 0)	{
						FirstAtom = LastAtom;
					}
				}
			}
			nLine++;
			if(nLine >= MAX_LINE_RTF)	{
				fclose(fIn);
				Quit_With_Error_Msg("nLine >= MAX_LINE_RTF in Write_ReOrdered_Rtf().\nQuit\n");
			}
		}
	}
	fclose(fIn);

	fOut = fopen(szName, "w");
	for(i=0; i<nLine; i++)	{
		if( (i>=FirstAtom) && (i<=LastAtom) && (strncmp(szRtfTxt[i], "ATOM", 4)==0) )	{
			Idx = Order_of_Print[Count];
			sprintf(szRtfTxt[i], "ATOM %-5s%-5s%9.4lf\n", Mol.AtomName[Idx], Mol.ChemName[Idx], Mol.CG[Idx]);
			Count++;
		}
		fprintf(fOut, "%s", szRtfTxt[i]);
	}
	fclose(fOut);
}

void Quit_With_Error_Msg(char szMsg[])
{
	fprintf(fFile_Run_Log, "%s", szMsg);
	fflush(fFile_Run_Log);
	exit(1);
}

void To_Identify_Backbone_Atoms()	// not applicable for Pro (which has a ring)
{
	int i, j, k, Atom_N=-1, Atom_CH3=-1, Atom_C=-1, nBond, Done=0, Count, Index, Idx_Cb_Prev;
	int Atom_CH3_H[3], Atom_CH3_2=-1, Atom_CH3_2_H[3], Atom_HN=-1, Atom_HA=-1, Atom_O=-1, *AtomBackbone;
	double *mass;

	mass = Mol.mass;

	for(i=0; i<nAtom; i++)	{
		Atom_N=-1;

		if( fabs(mass[i]-14.007) < 0.1 )	{	// N
			if( (Mol.Bonded_H_Count[i] == 1) && (Mol.Bonded_C_Count[i] == 2) )	{	// HN, CH3, CA
				nBond = Mol.BondCount[i];
				if( (nBond == 3) )	{	// might be backbone N
					for(j=0; j<nBond; j++)	{
						Atom_CH3 = Mol.Bonded_Atoms[i][j];
						if( (Mol.Bonded_H_Count[Atom_CH3]==3) && (fabs(mass[Atom_CH3]-12.011) < 0.1) )	{	// a SP3 C bonded with 3 H
							Atom_N = i;
							break;
						}
					}

					if(Atom_N >= 0)	{	// found a N
						for(j=0; j<nAtom; j++)	{
							if( (Mol.DistMatrix[i][j] == 2) && (fabs(mass[j]-12.011) < 0.1) && (Mol.BondCount[j]==3) && (Mol.Bonded_O_Count[j]==1) && (Mol.Bonded_C_Count[j]==2) )	{
								for(k=0; k<3; k++)	{
									Atom_CH3_2 = Mol.Bonded_Atoms[j][k];
									if(Mol.Bonded_H_Count[Atom_CH3_2]==3)	{	// it is the other -CH3
										Atom_C = j;
										Done = 1;
										break;
									}
								}
								if(Done)	{
									break;
								}
							}
						}
					}
				}
			}
		}
		if(Done)	{
			break;
		}
	}

	if( Done == 0 )	{
		Quit_With_Error_Msg("Fail to recognise the amino acid backbone atoms.\nQuit\n");
	}

	// start	to determine 3 H within -CH3
	Count = 0;
	for(i=0; i<4; i++)	{
		Index = Mol.Bonded_Atoms[Atom_CH3][i];
		if( fabs(mass[Index]-1.008) < 0.1 )	{	// H
			Atom_CH3_H[Count] = Index;
			Count++;
		}
	}

	Count = 0;
	for(i=0; i<4; i++)	{
		Index = Mol.Bonded_Atoms[Atom_CH3_2][i];
		if( fabs(mass[Index]-1.008) < 0.1 )	{	// H
			Atom_CH3_2_H[Count] = Index;
			Count++;
		}
	}
	// end		to determine 3 H within -CH3

	for(i=0; i<3; i++)	{
		Index = Mol.Bonded_Atoms[Atom_N][i];
		if( fabs(mass[Index]-1.008) < 0.1 )	{	// H
			Atom_HN = Index;
		}
		if( fabs(mass[Index]-12.011) < 0.1 )	{	// C
			if( Index !=  Atom_CH3)	{
				Atom_CA = Index;
			}
		}
	}

	if(Mol.Bonded_H_Count[Atom_CA] > 1)	{
		Quit_With_Error_Msg("There are more than 1 H attached on Ca atom. \nQuit\n");
	}
	if(Mol.BondCount[Atom_CA] != 4)	{
		Quit_With_Error_Msg("The number of atoms bonded with Ca atom is not 4! \nQuit\n");
	}
	for(i=0; i<4; i++)	{
		Index = Mol.Bonded_Atoms[Atom_CA][i];
		if( fabs(mass[Index]-1.008) < 0.1 )	{	// H
			Atom_HA = Index;
		}
		else	{	// not H atom
			if( (Index != Atom_C) && (Index != Atom_N) )	{
				Atom_Cb = Index;
			}
		}
	}
	
	for(i=0; i<3; i++)	{
		Index = Mol.Bonded_Atoms[Atom_C][i];
		if( fabs(mass[Index]-15.999) < 0.1 )	{	// O
			Atom_O = Index;
		}
	}

	AtomBackbone = new int[nAtom];
	Order_of_Print = new int[nAtom];

	memset(AtomBackbone, 0, sizeof(int)*nAtom);

	AtomBackbone[Atom_CH3] = 1;
	AtomBackbone[Atom_CH3_H[0]] = 1;
	AtomBackbone[Atom_CH3_H[1]] = 1;
	AtomBackbone[Atom_CH3_H[2]] = 1;

	AtomBackbone[Atom_N] = 1;
	AtomBackbone[Atom_HN] = 1;
	AtomBackbone[Atom_CA] = 1;
	AtomBackbone[Atom_HA] = 1;

	AtomBackbone[Atom_C] = 1;
	AtomBackbone[Atom_O] = 1;

	AtomBackbone[Atom_CH3_2] = 1;
	AtomBackbone[Atom_CH3_2_H[0]] = 1;
	AtomBackbone[Atom_CH3_2_H[1]] = 1;
	AtomBackbone[Atom_CH3_2_H[2]] = 1;


	Order_of_Print[0] = Atom_CH3;
	Order_of_Print[1] = Atom_CH3_H[0];
	Order_of_Print[2] = Atom_CH3_H[1];
	Order_of_Print[3] = Atom_CH3_H[2];

	Order_of_Print[4] = Atom_N;
	Order_of_Print[5] = Atom_HN;
	Order_of_Print[6] = Atom_CA;
	Order_of_Print[7] = Atom_HA;

	Count = 8;
	Start_New_Mol = Count;
	for(i=0; i<nAtom; i++)	{
		if(AtomBackbone[i] == 0)	{
			Order_of_Print[Count] = i;
			Count++;
		}
	}
	End_New_Mol = Count-1;

	//start	to make sure the Cb is the first atom between [Start_New_Mol, End_New_Mol]
	if(Order_of_Print[Start_New_Mol] != Atom_Cb)	{	// Cb is NOT place as the first atom in this group
		Idx_Cb_Prev = -1;
		for(i=Start_New_Mol+1; i<=End_New_Mol; i++)	{
			if(Order_of_Print[i] == Atom_Cb)	{	// to change the position
				Idx_Cb_Prev = i;
				Order_of_Print[i] = Order_of_Print[Start_New_Mol];
				Order_of_Print[Start_New_Mol] = Atom_Cb;
				break;
			}
		}
		if(Idx_Cb_Prev < 0)	{
			Quit_With_Error_Msg("Fail to position the Cb as the first atom in the group of side chain atoms.\n");
		}
	}
	//end	to make sure the Cb is the first atom between [Start_New_Mol, End_New_Mol]

	Order_of_Print[Count  ] = Atom_C;
	Order_of_Print[Count+1] = Atom_O;
	Order_of_Print[Count+2] = Atom_CH3_2;
	Order_of_Print[Count+3] = Atom_CH3_2_H[0];
	Order_of_Print[Count+4] = Atom_CH3_2_H[1];
	Order_of_Print[Count+5] = Atom_CH3_2_H[2];
	Count += 6;


	delete []AtomBackbone;

	return;
}

void Write_ReOrdered_Pdb(char szName[])
{
	int n, Idx;
	FILE *fOut;
	char szAtomName[16], szResName[16];

	fOut = fopen(szName, "w");
	fprintf(fOut, "REMARK PDB file generated by Lei's code.\n");
	for(n=0; n<nAtom; n++)	{
		Idx = Order_of_Print[n];
		strcpy(szAtomName, Mol.AtomName[Idx]);
		szAtomName[3] = 0;
		strcpy(szResName, Mol.ResName[Idx]);
		szResName[3] = 0;
		fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
			n+1, szAtomName, szResName, Mol.SegID[Idx], Mol.x[Idx], Mol.y[Idx], Mol.z[Idx]);
	}
	fprintf(fOut, "END\n");
	fclose(fOut);
}

#define BOND_LEN_H	(1.1)
void Write_Side_Chain_Pdb(char szName[])
{
	double dx, dy, dz;
	double H_Added_x, H_Added_y, H_Added_z;
	int n, Idx, Count;
	FILE *fOut;
	char szAtomName[16], szResName[16];

	dx = Mol.x[Atom_CA] - Mol.x[Atom_Cb];
	dy = Mol.y[Atom_CA] - Mol.y[Atom_Cb];
	dz = Mol.z[Atom_CA] - Mol.z[Atom_Cb];

	Normalize(dx, dy, dz);
	H_Added_x = Mol.x[Atom_Cb] + dx * BOND_LEN_H;
	H_Added_y = Mol.y[Atom_Cb] + dy * BOND_LEN_H;
	H_Added_z = Mol.z[Atom_Cb] + dz * BOND_LEN_H;
	
	fOut = fopen(szName, "w");
	fprintf(fOut, "REMARK PDB file generated by Lei's code.\n");

	Idx = Order_of_Print[Start_New_Mol];
	strcpy(szAtomName, Mol.AtomName[Idx]);
	szAtomName[3] = 0;
	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
		1, szAtomName, "MOL", Mol.SegID[Idx], Mol.x[Idx], Mol.y[Idx], Mol.z[Idx]);

	fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
		2, "H", "MOL", Mol.SegID[0], H_Added_x, H_Added_y, H_Added_z);

	Count=2;
	for(n=Start_New_Mol+1; n<=End_New_Mol; n++)	{
		Idx = Order_of_Print[n];
		strcpy(szAtomName, Mol.AtomName[Idx]);
		szAtomName[3] = 0;
		strcpy(szResName, Mol.ResName[Idx]);
		szResName[3] = 0;
		Count++;
		fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
			Count, szAtomName, szResName, Mol.SegID[Idx], Mol.x[Idx], Mol.y[Idx], Mol.z[Idx]);
	}
	fprintf(fOut, "END\n");
	fclose(fOut);

}
#undef BOND_LEN_H

double Normalize(double& vect_x, double& vect_y, double& vect_z)
{
	double dist, dist_Inv;

	dist = sqrt(vect_x*vect_x + vect_y*vect_y + vect_z*vect_z);
	if(dist < 1.0E-100)	{
		printf("Warning> Three atoms used in dihedral calculation are colinear!\n");
	}
	dist_Inv = 1.0/dist;
	vect_x *= dist_Inv;
	vect_y *= dist_Inv;
	vect_z *= dist_Inv;
	return dist;
}

int DetermineAtomType(char szName[], double mass)
{
	int i;
	char ErrorMsg[256];

	for(i=0; i<N_ELEM; i++)	{
		if( (Name_Elem[i][0] == szName[0]) && (fabs(mass - Mass_List[i]) < 0.2) )	{
			return i;
		}
	}

	sprintf(ErrorMsg, "Fail to identify atom: %s with mass = %8.3lf\n", szName, mass);

	Quit_With_Error_Msg(ErrorMsg);

	return -1;
}

void Build_Element_List(void)
{
	FILE *fOut;
	int i, Idx;

	fOut = fopen(szFileElemList, "w");
	for(i=0; i<nAtom; i++)	{
		Idx = Order_of_Print[i];
		AtomType[i] = DetermineAtomType(Mol.AtomName[Idx], Mol.mass[Idx]);

		fprintf(fOut, "%s\n", Name_Elem[AtomType[i]]);
	}
	fclose(fOut);
}

