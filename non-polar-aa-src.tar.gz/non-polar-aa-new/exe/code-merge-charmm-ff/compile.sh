#!/bin/bash

g++ -O2 -o merge-charmm merge-rtf-prm.cpp 

cp merge-charmm ..
chmod g+rx ../merge-charmm

