#!/bin/bash

g++ -O2 -o opt_sc opt-sc.cpp ff.cpp 

cp opt_sc ..
chmod g+rx ../opt_sc

