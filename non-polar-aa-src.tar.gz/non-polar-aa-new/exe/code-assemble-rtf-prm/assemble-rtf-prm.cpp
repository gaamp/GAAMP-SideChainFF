#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ff.h"

//#define MAX_TXT_LEN	(262144)

#define MAX_ANGLE_ADD		(64)
#define MAX_DIHEDRAL_ADD	(1536)
#define MAX_IMPROPER_ADD	(1536)

#define radian	(57.29577951308232088)

void Quit_With_Error_Msg(char szMsg[]);

FILE *fFile_Run_Log;	// will be shared by other source code

CMol Full, SideChain;
CForceField ff_Full, ff_sc;
int netcharge_mol;

int To_Add_Angle[MAX_ANGLE_ADD], To_Add_Dihedral[MAX_DIHEDRAL_ADD], To_Add_Improper[MAX_IMPROPER_ADD];
int nAngle_Add, nDihedral_Add, nImproper_Add;
ANGLE_REC Angle_Rec_Add[MAX_ANGLE_ADD];
DIHEDRAL_REC Dihedral_Rec_Add[MAX_DIHEDRAL_ADD];
IMPRODIHEDRAL_REC ImproDihedral_Rec_Add[MAX_IMPROPER_ADD];
char szNewChemName[MAX_ATOM][24];
char szNewAtomName[MAX_ATOM][24];

int Idx_Cb=-1;	// the index of the atom connecting with H (atom2), Ca
int Idx_Cb_in_AA=-1;
char Flag_Is_Backbone_Atom[MAX_ATOM];
int Idx_Start_SideChain, Idx_End_SideChain;


void Write_Assembled_Rtf(void);
void Write_Assembled_Pdb(void);
void Write_Assembled_Crd(void);
void Write_Assembled_Prm(void);
void Get_Netcharge_From_Xpsf(void);
void Chop(char szBuff[]);
int Is_Atom_in_TIP3(char szAtom[]);
void Identify_All_Backbone_Atoms(void);
char* Get_Atom_Chem_Name(int Idx, char ChemName[]);
void Identify_Params_between_Backbone_Sidechain(void);

int main(void)
{
	fFile_Run_Log = fopen("log-assemble-ff.txt", "w");
	if(fFile_Run_Log==NULL)	{
		printf("Fail to create the log file.\n\n");
		exit(1);
	}

/*
	ff_Full.ReadForceField("assembled.prm");
	Full.ReadPSF("assembled.xpsf",0);
	Full.AssignForceFieldParameters(&ff_Full);
	Full.ReadPDB("assembled.pdb");
	Full.Cal_E(1);

	Full.FullGeometryOptimization_LBFGS();

	Full.Cal_E(1);
	Full.SavePdb("test.pdb");
	Full.SaveCrd("mol-opt.crd");
*/

	ff_Full.ReadForceField("full.prm");
	ff_sc.ReadForceField("sc.prm");

	Full.ReadPSF("mol-ordered.xpsf",0);
	Full.AssignForceFieldParameters(&ff_Full);
	Full.ReadPDB("ordered.pdb");

	Get_Netcharge_From_Xpsf();

	SideChain.ReadPSF("sc.xpsf", 0);
	SideChain.AssignForceFieldParameters(&ff_sc);
	
	Idx_Cb = SideChain.Bonded_Atoms[1][0];	// the side-chain atom bonded with Ca

	Identify_All_Backbone_Atoms();

	Write_Assembled_Rtf();
	Write_Assembled_Pdb();
	Write_Assembled_Crd();

	Identify_Params_between_Backbone_Sidechain();

	Write_Assembled_Prm();

	
	fclose(fFile_Run_Log);


	return 0;
}


void Quit_With_Error_Msg(char szMsg[])
{
	fprintf(fFile_Run_Log, "%s", szMsg);
	fflush(fFile_Run_Log);
	exit(1);
}

void Write_Assembled_Rtf(void)
{
	FILE *fOut, *fIn;
	char szLine[256], *ReadLine;
	int i, iPos, Atom_1, Atom_2, nAtom_SC, nBond_SC;

	nBond_SC = SideChain.nBond;

	fOut = fopen("assembled.rtf", "w");

	fprintf(fOut, "* Topology File.\n");
	fprintf(fOut, "* \n");
	fprintf(fOut, "   99   1\n");

	fprintf(fOut, "MASS     1 H      1.00800 H ! POLAR H\n");
	fprintf(fOut, "MASS     3 HA     1.00800 H ! NONPOLAR H\n");
	fprintf(fOut, "MASS     6 HB     1.00800 H ! BACKBONE H\n");
	fprintf(fOut, "MASS    20 C     12.01100 C ! CARBONYL C, PEPTIDE BACKBONE\n");
	fprintf(fOut, "MASS    22 CT1   12.01100 C ! ALIPHATIC SP3 C FOR CH\n");
	fprintf(fOut, "MASS    24 CT3   12.01100 C ! ALIPHATIC SP3 C FOR CH3\n");
	fprintf(fOut, "MASS    54 NH1   14.00700 N ! PEPTIDE NITROGEN\n");
	fprintf(fOut, "MASS    70 O     15.99900 O ! CARBONYL OXYGEN\n");

	fIn = fopen("mass-sc.txt", "r");
	if(fIn == NULL)	{
		Quit_With_Error_Msg("Fail to open file: mass-sc.txt.\n");
	}

	while(1)	{
		if(feof(fIn))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fIn);
		if(ReadLine == NULL)	{
			break;
		}
		if(strlen(szLine) > 8)	{
			Chop(szLine);
			fprintf(fOut, "%s\n", szLine);
		}
	}
	fclose(fIn);

	fprintf(fOut, "\nAUTO ANGLES DIHE\n\n");



	fprintf(fOut, "RESI MOL %7.3lf\n", 1.0*netcharge_mol);

	fprintf(fOut, "GROUP\n");
	fprintf(fOut, "ATOM CL   CT3    -0.27\n");
	fprintf(fOut, "ATOM HL1  HA      0.09\n");
	fprintf(fOut, "ATOM HL2  HA      0.09\n");
	fprintf(fOut, "ATOM HL3  HA      0.09\n");

	fprintf(fOut, "GROUP\n");
	fprintf(fOut, "ATOM N    NH1    -0.47\n");
	fprintf(fOut, "ATOM HN   H       0.31\n");
	fprintf(fOut, "ATOM CA   CT1     0.07\n");
	fprintf(fOut, "ATOM HA   HB      0.09\n");

	fprintf(fOut, "GROUP\n");

	nAtom_SC = SideChain.nAtom;
	for(i=0; i<nAtom_SC; i++)	{
		if(i != 1)	{	// skip H atom
			fprintf(fOut, "ATOM %-5s%-5s %7.3lf\n", SideChain.AtomName[i], SideChain.ChemName[i], SideChain.CG[i]);
		}
	}

	fprintf(fOut, "GROUP\n");
	fprintf(fOut, "ATOM C    C       0.51\n");
	fprintf(fOut, "ATOM O    O      -0.51\n");



	fprintf(fOut, "GROUP\n");
//	fprintf(fOut, "ATOM CR   CT3    -0.11\n");
	fprintf(fOut, "ATOM CR   CT3    -0.27\n");
	fprintf(fOut, "ATOM HR1  HA      0.09\n");
	fprintf(fOut, "ATOM HR2  HA      0.09\n");
	fprintf(fOut, "ATOM HR3  HA      0.09\n");

	fprintf(fOut, "\n");

	fprintf(fOut, "BOND CL HL1  CL HL2  CL HL3\n");
	fprintf(fOut, "BOND CL N    HN N    N  CA\n");
	fprintf(fOut, "BOND HA CA   CA C    CA %s\n", SideChain.AtomName[Idx_Cb]);
	fprintf(fOut, "BOND C  O    C  CR\n");
	fprintf(fOut, "BOND CR HR1  CR HR2  CR HR3\n");

	iPos = 0;
	for(i=0; i<nBond_SC; i++)	{
		Atom_1 = SideChain.BondList[iPos  ];
		Atom_2 = SideChain.BondList[iPos+1];
		iPos += 2;
		if( (Atom_1==1) || (Atom_2==1) )	{	// skip the bond ATOM_H_2 involved
			continue;
		}
		fprintf(fOut, "BOND %-5s %-5s\n", SideChain.AtomName[Atom_1], SideChain.AtomName[Atom_2]);
	}
	
	fprintf(fOut, "\nIMPR C  CA  CR O\n");
	fprintf(fOut, "\nPATCH FIRST NONE LAST NONE\n\nEND\n");


	fclose(fOut);

	strcpy(szNewChemName[0], "CT3");	// CL
	strcpy(szNewChemName[1], "HA");		// HL1
	strcpy(szNewChemName[2], "HA");		// HL2
	strcpy(szNewChemName[3], "HA");		// HL3
	strcpy(szNewChemName[4], "NH1");	// N
	strcpy(szNewChemName[5], "H");		// HN
	strcpy(szNewChemName[6], "CT1");	// CA
	strcpy(szNewChemName[7], "HB");		// HA

	strcpy(szNewChemName[Idx_End_SideChain+1], "C");	// C
	strcpy(szNewChemName[Idx_End_SideChain+2], "O");	// O
	strcpy(szNewChemName[Idx_End_SideChain+3], "CT3");	// CR
	strcpy(szNewChemName[Idx_End_SideChain+4], "HA");	// HR1
	strcpy(szNewChemName[Idx_End_SideChain+5], "HA");	// HR2
	strcpy(szNewChemName[Idx_End_SideChain+6], "HA");	// HR3


	strcpy(szNewAtomName[0], "CL");	// CL
	strcpy(szNewAtomName[1], "HL1");		// HL1
	strcpy(szNewAtomName[2], "HL2");		// HL2
	strcpy(szNewAtomName[3], "HL3");		// HL3
	strcpy(szNewAtomName[4], "N");	// N
	strcpy(szNewAtomName[5], "HN");		// HN
	strcpy(szNewAtomName[6], "CA");	// CA
	strcpy(szNewAtomName[7], "HA");		// HA

	strcpy(szNewAtomName[8], SideChain.AtomName[0]);
	for(i=2; i<SideChain.nAtom; i++)	{
		strcpy(szNewAtomName[Idx_Start_SideChain-1+i], SideChain.AtomName[i]);
	}

	strcpy(szNewAtomName[Idx_End_SideChain+1], "C");	// C
	strcpy(szNewAtomName[Idx_End_SideChain+2], "O");	// O
	strcpy(szNewAtomName[Idx_End_SideChain+3], "CR");	// CR
	strcpy(szNewAtomName[Idx_End_SideChain+4], "HR1");	// HR1
	strcpy(szNewAtomName[Idx_End_SideChain+5], "HR2");	// HR2
	strcpy(szNewAtomName[Idx_End_SideChain+6], "HR3");	// HR3
}

void Write_Assembled_Prm(void)
{
	FILE *fOut;
	int i;
	char szChemName[8][N_LEN_CHEM_NAME];
	double Para_List[MAX_DIH_ITEM*3];

	fOut = fopen("assembled.prm", "w");

	fprintf(fOut, "* FORCE FIELD PARAMETER FILE.\n");
	fprintf(fOut, "* \n\n");

	fprintf(fOut, "BONDS\n");
	fprintf(fOut, "CT1     C         250.000     1.4900\n");
	fprintf(fOut, "CT3     C         250.000     1.4900\n");
	fprintf(fOut, "HA      CT3       322.000     1.1110\n");
	fprintf(fOut, "HB      CT1       330.000     1.0800\n");
	fprintf(fOut, "NH1     C         370.000     1.3450\n");	// bond beween two amino acids
	fprintf(fOut, "NH1     CT1       320.000     1.4300\n");
	fprintf(fOut, "NH1     CT3       320.000     1.4300\n");
	fprintf(fOut, "NH1     H         440.000     0.9970\n");
	fprintf(fOut, "O       C         620.000     1.2300\n");

	for(i=0; i<ff_sc.n_Rec_Bond; i++)	{
		if( (Is_Atom_in_TIP3(ff_sc.Bond_Rec[i].Chem[0])==0) && (Is_Atom_in_TIP3(ff_sc.Bond_Rec[i].Chem[1])==0))	{
			fprintf(fOut, "%-7s %-7s %10.3lf %10.4lf\n", 
				ff_sc.Bond_Rec[i].Chem[0], ff_sc.Bond_Rec[i].Chem[1], ff_sc.Bond_Rec[i].para[0], ff_sc.Bond_Rec[i].para[1]);
		}
	}

	strcpy(szChemName[0], Full.ChemName[6]);				// "CA" atom
	strcpy(szChemName[1], Full.ChemName[8]);	// atom type for "Cb"
	
	ff_Full.GetPara_Bond(szChemName, Para_List);
	fprintf(fOut, "%-7s %-7s %10.3lf %10.4lf\n", 
		"CT1", SideChain.ChemName[0], Para_List[0], Para_List[1]);
//CT3     CT1       222.500     1.5380

	fprintf(fOut, "\n");


	fprintf(fOut, "ANGLES\n");
	fprintf(fOut, "CT1     NH1     C          50.000   120.0000\n");
	fprintf(fOut, "H       NH1     C          34.000   123.0000\n");
	fprintf(fOut, "H       NH1     CT1        35.000   117.0000\n");
	fprintf(fOut, "H       NH1     CT3        35.000   117.0000\n");
	fprintf(fOut, "HA      CT3     C          33.000   109.5000    30.000    2.16300\n");
	fprintf(fOut, "HA      CT3     HA         35.500   108.4000     5.400    1.80200\n");
	fprintf(fOut, "HB      CT1     C          50.000   109.5000\n");
	fprintf(fOut, "NH1     CT1     C          50.000   107.0000\n");
	fprintf(fOut, "NH1     CT1     HB         48.000   108.0000\n");
	fprintf(fOut, "NH1     CT3     HA         51.500   109.5000\n");
	fprintf(fOut, "O       C       CT1        80.000   121.0000\n");
	fprintf(fOut, "O       C       CT3        80.000   121.0000\n");

	fprintf(fOut, "CT3     NH1     CT1        64.010   110.9000 ! from GAFF, C3 N3 C3\n");
	fprintf(fOut, "CT1     C       CT3        62.820   116.0500 ! from GAFF, C3 C  C3\n");


//!CT3     CT1     C          52.000   108.0000
//!CT3     NH1     C          50.000   120.0000
//!HA      CT3     CT1        33.430   110.1000    22.530    2.17900
//!HB      CT1     CT3        35.000   111.0000
//NH1     C       CT1        80.000   116.5000
//!NH1     C       CT3        80.000   116.5000
//!NH1     CT1     CT3        70.000   113.5000
//O       C       NH1        80.000   122.5000

	for(i=0; i<ff_sc.n_Rec_Angle; i++)	{
		if( (Is_Atom_in_TIP3(ff_sc.Angle_Rec[i].Chem[0])==0) && (Is_Atom_in_TIP3(ff_sc.Angle_Rec[i].Chem[1])==0) && (Is_Atom_in_TIP3(ff_sc.Angle_Rec[i].Chem[2])==0) )	{
			if(fabs(ff_sc.Angle_Rec[i].para[2]) > 1.0E-4)	{
				fprintf(fOut, "%-7s %-7s %-7s %9.3lf %10.4lf %9.3lf %10.5lf\n", 
					ff_sc.Angle_Rec[i].Chem[0], ff_sc.Angle_Rec[i].Chem[1], ff_sc.Angle_Rec[i].Chem[2], 
					ff_sc.Angle_Rec[i].para[0], ff_sc.Angle_Rec[i].para[1], ff_sc.Angle_Rec[i].para[2], ff_sc.Angle_Rec[i].para[3]);
			}
			else	{
				fprintf(fOut, "%-7s %-7s %-7s %9.3lf %10.4lf\n", 
					ff_sc.Angle_Rec[i].Chem[0], ff_sc.Angle_Rec[i].Chem[1], ff_sc.Angle_Rec[i].Chem[2], 
					ff_sc.Angle_Rec[i].para[0], ff_sc.Angle_Rec[i].para[1]);
			}
		}
	}
	for(i=0; i<nAngle_Add; i++)	{
		if(To_Add_Angle[i])	{
			fprintf(fOut, "%-7s %-7s %-7s %9.3lf %10.4lf\n", 
				Angle_Rec_Add[i].Chem[0], Angle_Rec_Add[i].Chem[1], Angle_Rec_Add[i].Chem[2], Angle_Rec_Add[i].para[0], Angle_Rec_Add[i].para[1]);
		}
	}

	fprintf(fOut, "\n");


	fprintf(fOut, "DIHEDRALS\n");
	fprintf(fOut, "H       NH1     CT1     C          0.0000         1        0.0\n");
	fprintf(fOut, "HA      CT3     NH1     H          0.0000         3        0.0\n");
	fprintf(fOut, "HB      CT1     NH1     H          0.0000         1        0.0\n");
	fprintf(fOut, "O       C       CT1     HB         0.0000         1        0.0\n");
	fprintf(fOut, "O       C       CT1     NH1        0.0000         1        0.0\n");
	fprintf(fOut, "O       C       CT3     HA         0.0000         3      180.0\n");

	fprintf(fOut, "CT3     NH1     CT1     HB         0.300          3        0.0  ! GAFF X  C3 N3 X\n");
	fprintf(fOut, "CT3     NH1     CT1     C          0.300          3        0.0  ! GAFF X  C3 N3 X\n");
	fprintf(fOut, "HA      CT3     NH1     CT1        0.300          3        0.0  ! GAFF X  C3 N3 X\n");

	fprintf(fOut, "NH1     CT1     C       CT3        0.000          2      180.0  !GAFF X  C  C3 X\n");
	fprintf(fOut, "CT1     C       CT3     HA         0.000          2      180.0  !GAFF X  C  C3 X\n");
	fprintf(fOut, "HB      CT1     C       CT3        0.000          2      180.0  !GAFF X  C  C3 X\n");

//!C       CT1     NH1     C          0.2000         1      180.0
//!CT3     C       NH1     CT1        1.6000         1        0.0
//!CT3     C       NH1     CT1        2.5000         2      180.0
//!CT3     CT1     NH1     C          1.8000         1        0.0
//!CT3     NH1     C       CT1        1.6000         1        0.0
//!CT3     NH1     C       CT1        2.5000         2      180.0
//!H       NH1     C       CT1        2.5000         2      180.0
//!H       NH1     C       CT3        2.5000         2      180.0
//!H       NH1     CT1     CT3        0.0000         1        0.0
//!HA      CT3     NH1     C          0.0000         3        0.0
//!HB      CT1     NH1     C          0.0000         1        0.0
//!NH1     C       CT1     CT3        0.0000         1        0.0
//!NH1     C       CT1     HB         0.0000         1        0.0
//!NH1     C       CT1     NH1        0.6000         1        0.0
//!NH1     C       CT3     HA         0.0000         3        0.0
//!O       C       CT1     CT3        1.4000         1        0.0
//O       C       NH1     CT1        2.5000         2      180.0
//O       C       NH1     CT3        2.5000         2      180.0
//!O       C       NH1     H          2.5000         2      180.0
//!X       CT1     CT3     X          0.2000         3        0.0

	for(i=0; i<ff_sc.n_Rec_Dihedral; i++)	{
		if( (Is_Atom_in_TIP3(ff_sc.Dihedral_Rec[i].Chem[0])==0) && (Is_Atom_in_TIP3(ff_sc.Dihedral_Rec[i].Chem[1])==0) && (Is_Atom_in_TIP3(ff_sc.Dihedral_Rec[i].Chem[2])==0) && (Is_Atom_in_TIP3(ff_sc.Dihedral_Rec[i].Chem[3])==0) )	{
				fprintf(fOut, "%-5s %-5s %-5s %-5s  %7.3lf %3.0lf %9.1lf\n", 
					ff_sc.Dihedral_Rec[i].Chem[0], ff_sc.Dihedral_Rec[i].Chem[1], ff_sc.Dihedral_Rec[i].Chem[2], ff_sc.Dihedral_Rec[i].Chem[3], 
					ff_sc.Dihedral_Rec[i].para[0], ff_sc.Dihedral_Rec[i].para[1], ff_sc.Dihedral_Rec[i].para[2]);
		}
	}
	for(i=0; i<nDihedral_Add; i++)	{
		if(To_Add_Dihedral[i])	{
					fprintf(fOut, "%-5s %-5s %-5s %-5s  %7.3lf %3.0lf %9.1lf\n", 
						Dihedral_Rec_Add[i].Chem[0], Dihedral_Rec_Add[i].Chem[1], Dihedral_Rec_Add[i].Chem[2], Dihedral_Rec_Add[i].Chem[3], 
						Dihedral_Rec_Add[i].para[0], Dihedral_Rec_Add[i].para[1], Dihedral_Rec_Add[i].para[2]);
		}
	}
	fprintf(fOut, "\n");

	fprintf(fOut, "IMPROPERS\n");
	fprintf(fOut, "NH1     X       X       H         20.0000         0        0.0\n");
	fprintf(fOut, "O       X       X       C        120.0000         0        0.0\n");

	for(i=0; i<nImproper_Add; i++)	{
		if(To_Add_Improper[i])	{
					fprintf(fOut, "%-5s %-5s %-5s %-5s  %7.3lf %3.0lf %9.1lf\n", 
						ImproDihedral_Rec_Add[i].Chem[0], ImproDihedral_Rec_Add[i].Chem[1], ImproDihedral_Rec_Add[i].Chem[2], ImproDihedral_Rec_Add[i].Chem[3], 
						ImproDihedral_Rec_Add[i].para[0], ImproDihedral_Rec_Add[i].para[1], ImproDihedral_Rec_Add[i].para[2]);
		}
	}


	fprintf(fOut, "\n");
	fprintf(fOut, "NONBONDED\n");
	fprintf(fOut, "!                EMIN     RMIN/2\n");
	fprintf(fOut, "!             (KCAL/MOL)    (A)\n");

	fprintf(fOut, "C        0.00    -0.110000    2.000000   0.00    -0.110000    2.000000\n");
	fprintf(fOut, "CT1      0.00    -0.020000    2.275000   0.00    -0.010000    1.900000\n");
	fprintf(fOut, "CT3      0.00    -0.080000    2.060000   0.00    -0.010000    1.900000\n");
	fprintf(fOut, "H        0.00    -0.046000    0.224500   0.00    -0.046000    0.224500\n");
	fprintf(fOut, "HA       0.00    -0.022000    1.320000   0.00    -0.022000    1.320000\n");
	fprintf(fOut, "HB       0.00    -0.022000    1.320000   0.00    -0.022000    1.320000\n");
	fprintf(fOut, "NH1      0.00    -0.200000    1.850000   0.00    -0.200000    1.550000\n");
	fprintf(fOut, "O        0.00    -0.120000    1.700000   0.00    -0.120000    1.400000\n");

	for(i=0; i<ff_sc.n_Rec_LJ; i++)	{
		if( Is_Atom_in_TIP3(ff_sc.LJ_Rec[i].Chem)==0)	{
				fprintf(fOut, "%-7s  0.00   %10.6lf  %10.6lf\n", 
					ff_sc.LJ_Rec[i].Chem, ff_sc.LJ_Rec[i].para[1], ff_sc.LJ_Rec[i].para[2]);
		}
	}


	fprintf(fOut, "\n\nEND\n");


	fclose(fOut);
}

void Get_Netcharge_From_Xpsf(void)
{
	int i, nAtom;
	double cg_sum=0.0;
	char szCharge[16];

	nAtom = Full.nAtom;
	for(i=0; i<nAtom; i++)	{
		cg_sum += Full.CG[i];
	}
	sprintf(szCharge, "%.0lf", cg_sum);

	netcharge_mol = atoi(szCharge);	// assuming the netcharge is an integer !!!
}

void Chop(char szBuff[])
{
	int nLen;
	char c;

	nLen = strlen(szBuff);

	c = szBuff[nLen-1];
	if( (c==0xD) || (c==0xA) )	{
		szBuff[nLen-1] = 0;
	}

	if(nLen >= 2)	{
		c = szBuff[nLen-2];
		if( (c==0xD) || (c==0xA) )	{
			szBuff[nLen-2] = 0;
		}
	}
	return;
}

inline int Is_Atom_in_TIP3(char szAtom[])
{
	if( (strcmp(szAtom,"HT_W") == 0) || (strcmp(szAtom,"OT_W") == 0) )	{
		return 1;
	}
	return 0;
}

void Identify_All_Backbone_Atoms(void)
{
	int nAtom_SideChain;

	Idx_Start_SideChain = 8;
	Idx_End_SideChain = Full.nAtom-7;
	nAtom_SideChain = SideChain.nAtom-1;	// cut the H (atom2)
	memset(Flag_Is_Backbone_Atom, 1, sizeof(char)*Full.nAtom);
	memset(Flag_Is_Backbone_Atom+Idx_Start_SideChain, 0, sizeof(char)*nAtom_SideChain);

}

char* Get_Atom_Chem_Name(int Idx, char ChemName[])
{
	if(Flag_Is_Backbone_Atom[Idx])	{	// backbone
		strcpy(ChemName, szNewChemName[Idx]);
	}
	else	{
		if(Idx == Idx_Start_SideChain)	{
			strcpy(ChemName, SideChain.ChemName[Idx-Idx_Start_SideChain]);
		}
		else	{
			strcpy(ChemName, SideChain.ChemName[Idx-Idx_Start_SideChain+1]);	// H (atom 2) is skipped
		}
	}
	return ChemName;
}

void Write_Assembled_Pdb(void)
{
	int n, nLen;
	FILE *fOut;
	char szAtomName[16], szResName[16];

	fOut = fopen("assembled.pdb", "w");
	fprintf(fOut, "REMARK PDB file generated by Lei's code.\n");
	for(n=0; n<Full.nAtom; n++)	{
		strcpy(szAtomName, szNewAtomName[n]);
		nLen = strlen(szAtomName);

		if(nLen == 4)	{
			strcpy(szResName, Full.ResName[n]);
			szResName[3] = 0;
			fprintf(fOut, "ATOM%7d %-4s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
				n+1, szAtomName, szResName, Full.SegID[n], Full.x[n], Full.y[n], Full.z[n]);
		}
		else	{
			szAtomName[3] = 0;
			strcpy(szResName, Full.ResName[n]);
			szResName[3] = 0;
			fprintf(fOut, "ATOM%7d  %-3s %-3s A%4d    %8.3lf%8.3lf%8.3lf  1.00  0.00\n", 
				n+1, szAtomName, szResName, Full.SegID[n], Full.x[n], Full.y[n], Full.z[n]);
		}
	}
	fprintf(fOut, "END\n");
	fclose(fOut);
}

void Write_Assembled_Crd(void)
{
	int n;
	FILE *fOut;
	char szAtomName[16], szResName[16];

	fOut = fopen("assembled.crd", "w");
	fprintf(fOut, "%5d\n", Full.nAtom);
	for(n=0; n<Full.nAtom; n++)	{
		strcpy(szAtomName, szNewAtomName[n]);
		szAtomName[4] = 0;
		strcpy(szResName, Full.ResName[n]);
		szResName[4] = 0;
		fprintf(fOut, "%5d%5d %-4s %-4s%10.5lf%10.5lf%10.5lf %-4s%2d      0.00000\n", 
				n+1, Full.SegID[n], szResName, szAtomName, Full.x[n], Full.y[n], Full.z[n], 
				szResName, Full.SegID[n]);
	}
	fclose(fOut);
}



void Identify_Params_between_Backbone_Sidechain(void)
{
	int i, j, iPos, nAtom, Atom_1, Atom_2, Atom_3, Atom_4, Count_Backbone_Atom, Count;
	char szChemName[N_LEN_CHEM_NAME];

	nAtom = Full.nAtom;

	nAngle_Add = nDihedral_Add = nImproper_Add = 0;

	for(i=0; i<Full.nAngle; i++)	{
		iPos = 3 * i;
		Atom_1 = Full.AngleList[iPos  ];
		Atom_2 = Full.AngleList[iPos+1];
		Atom_3 = Full.AngleList[iPos+2];

		Count_Backbone_Atom = Flag_Is_Backbone_Atom[Atom_1] + Flag_Is_Backbone_Atom[Atom_2] + Flag_Is_Backbone_Atom[Atom_3];

		if( (Count_Backbone_Atom<3) && (Count_Backbone_Atom>0) )	{	// both backbone and side-chain atoms exist
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[0], Get_Atom_Chem_Name(Atom_1, szChemName));
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[1], Get_Atom_Chem_Name(Atom_2, szChemName));
			strcpy(Angle_Rec_Add[nAngle_Add].Chem[2], Get_Atom_Chem_Name(Atom_3, szChemName));

			// no 1-3 term (Urey-Bradley) in GAFF
			Angle_Rec_Add[nAngle_Add].para[0] = Full.Para_k_a[i];
			Angle_Rec_Add[nAngle_Add].para[1] = Full.Para_theta0[i]*radian;
			To_Add_Angle[nAngle_Add] = 1;
			nAngle_Add++;
		}
	}


	//start	to re-organize the new angle entries, delete redundant entries
	for(i=0; i<nAngle_Add; i++)	{
		for(j=i+1; j<nAngle_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Angle[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(Angle_Rec_Add[i].Chem[0], Angle_Rec_Add[j].Chem[0])==0) && (strcmp(Angle_Rec_Add[i].Chem[1], Angle_Rec_Add[j].Chem[1])==0) && (strcmp(Angle_Rec_Add[i].Chem[2], Angle_Rec_Add[j].Chem[2])==0) ) || 
				( (strcmp(Angle_Rec_Add[i].Chem[0], Angle_Rec_Add[j].Chem[2])==0) && (strcmp(Angle_Rec_Add[i].Chem[1], Angle_Rec_Add[j].Chem[1])==0) && (strcmp(Angle_Rec_Add[i].Chem[2], Angle_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(Angle_Rec_Add[i].para[0]-Angle_Rec_Add[j].para[0]) < 1.0E-7) && (fabs(Angle_Rec_Add[i].para[1]-Angle_Rec_Add[j].para[1]) < 1.0E-7) )	{
					To_Add_Angle[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new Angle entries, delete redundant entries



	for(i=0; i<Full.nDihedral; i++)	{
		iPos = 4 * i;
		Atom_1 = Full.DihedralList[iPos  ];
		Atom_2 = Full.DihedralList[iPos+1];
		Atom_3 = Full.DihedralList[iPos+2];
		Atom_4 = Full.DihedralList[iPos+3];

		Count_Backbone_Atom = Flag_Is_Backbone_Atom[Atom_1] + Flag_Is_Backbone_Atom[Atom_2] + 
			Flag_Is_Backbone_Atom[Atom_3] + Flag_Is_Backbone_Atom[Atom_4];

		if((Count_Backbone_Atom<4) && (Count_Backbone_Atom>0))	{	// both backbone and side-chain atoms exist
			Count = 0;
			for(j=1; j<=6; j++)	{
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[0], Get_Atom_Chem_Name(Atom_1, szChemName));
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[1], Get_Atom_Chem_Name(Atom_2, szChemName));
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[2], Get_Atom_Chem_Name(Atom_3, szChemName));
				strcpy(Dihedral_Rec_Add[nDihedral_Add].Chem[3], Get_Atom_Chem_Name(Atom_4, szChemName));
				
				Dihedral_Rec_Add[nDihedral_Add].para[0] = Full.Para_k_Dih[i][j];
				Dihedral_Rec_Add[nDihedral_Add].para[1] = 1.0*j;
				Dihedral_Rec_Add[nDihedral_Add].para[2] = Full.Para_phi[i][j]*radian;
				if(fabs(Dihedral_Rec_Add[nDihedral_Add].para[0]) > 1.0E-6)	{	// a valid entry
					To_Add_Dihedral[nDihedral_Add] = 1;
					nDihedral_Add++;
					Count++;
				}
			}
			if(Count == 0)	{	// no parameters added
				j = 2;
				Dihedral_Rec_Add[nDihedral_Add].para[0] = Full.Para_k_Dih[i][j];
				Dihedral_Rec_Add[nDihedral_Add].para[1] = 1.0*j;
				Dihedral_Rec_Add[nDihedral_Add].para[2] = Full.Para_phi[i][j]*radian;
				To_Add_Dihedral[nDihedral_Add] = 1;
				nDihedral_Add++;
			}
		}
	}

	//start	to re-organize the new dihedral entries, delete redundant entries
	for(i=0; i<nDihedral_Add; i++)	{
		for(j=i+1; j<nDihedral_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Dihedral[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(Dihedral_Rec_Add[i].Chem[0], Dihedral_Rec_Add[j].Chem[0])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[1], Dihedral_Rec_Add[j].Chem[1])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[2], Dihedral_Rec_Add[j].Chem[2])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[3], Dihedral_Rec_Add[j].Chem[3])==0) ) || 
				( (strcmp(Dihedral_Rec_Add[i].Chem[0], Dihedral_Rec_Add[j].Chem[3])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[1], Dihedral_Rec_Add[j].Chem[2])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[2], Dihedral_Rec_Add[j].Chem[1])==0) && (strcmp(Dihedral_Rec_Add[i].Chem[3], Dihedral_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(Dihedral_Rec_Add[i].para[0]-Dihedral_Rec_Add[j].para[0]) < 1.0E-3) && (fabs(Dihedral_Rec_Add[i].para[1]-Dihedral_Rec_Add[j].para[1]) < 1.0E-3) && (fabs(Dihedral_Rec_Add[i].para[2]-Dihedral_Rec_Add[j].para[2]) < 1.0E-3) )	{
					To_Add_Dihedral[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new Dihedral entries, delete redundant entries




	//start	to generate the list of new Improper entries
	// assume there in only one entry for each four atoms, which should hold always
	for(i=0; i<Full.nImpro; i++)	{
		iPos = 4*i;
		Atom_1 = Full.ImprDihedralList[iPos  ];
		Atom_2 = Full.ImprDihedralList[iPos+1];
		Atom_3 = Full.ImprDihedralList[iPos+2];
		Atom_4 = Full.ImprDihedralList[iPos+3];
		
		Count_Backbone_Atom = Flag_Is_Backbone_Atom[Atom_1] + Flag_Is_Backbone_Atom[Atom_2] + 
			Flag_Is_Backbone_Atom[Atom_3] + Flag_Is_Backbone_Atom[Atom_4];

		if( (Count_Backbone_Atom<4) && (Count_Backbone_Atom>0) )	{
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[0], Get_Atom_Chem_Name(Atom_1, szChemName));
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[1], Get_Atom_Chem_Name(Atom_2, szChemName));
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[2], Get_Atom_Chem_Name(Atom_3, szChemName));
			strcpy(ImproDihedral_Rec_Add[nImproper_Add].Chem[3], Get_Atom_Chem_Name(Atom_4, szChemName));
			
			ImproDihedral_Rec_Add[nImproper_Add].para[0] = Full.Para_k_ImpDih[i];
			ImproDihedral_Rec_Add[nImproper_Add].para[1] = Full.Para_Imp_phi[i]*radian;
			ImproDihedral_Rec_Add[nImproper_Add].para[2] = Full.Para_Type_ImpDih[i];
			if(Full.Para_k_ImpDih[i] > 1.0E-3)	{	// a valid entry
				To_Add_Improper[nImproper_Add] = 1;
				nImproper_Add++;
			}
		}
	}
	//end	to generate the list of new Improper entries

	//start	to re-organize the new improper entries, delete redundant entries
	for(i=0; i<nImproper_Add; i++)	{
		for(j=i+1; j<nImproper_Add; j++)	{	// to find out those redundant entries
			if(To_Add_Improper[j] == 0)	{	// already deleted
				continue;
			}
			if( ( (strcmp(ImproDihedral_Rec_Add[i].Chem[0], ImproDihedral_Rec_Add[j].Chem[0])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[1], ImproDihedral_Rec_Add[j].Chem[1])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[2], ImproDihedral_Rec_Add[j].Chem[2])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[3], ImproDihedral_Rec_Add[j].Chem[3])==0) ) || 
				( (strcmp(ImproDihedral_Rec_Add[i].Chem[0], ImproDihedral_Rec_Add[j].Chem[3])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[1], ImproDihedral_Rec_Add[j].Chem[2])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[2], ImproDihedral_Rec_Add[j].Chem[1])==0) && (strcmp(ImproDihedral_Rec_Add[i].Chem[3], ImproDihedral_Rec_Add[j].Chem[0])==0) ) )	{
				if( (fabs(ImproDihedral_Rec_Add[i].para[0]-ImproDihedral_Rec_Add[j].para[0]) < 1.0E-3) && (fabs(ImproDihedral_Rec_Add[i].para[1]-ImproDihedral_Rec_Add[j].para[1]) < 1.0E-3) && (fabs(ImproDihedral_Rec_Add[i].para[2]-ImproDihedral_Rec_Add[j].para[2]) < 1.0E-3) )	{
					To_Add_Improper[j] = 0;
				}
			}
		}
	}
	//end	to re-organize the new improper entries, delete redundant entries

}
