#!/bin/bash

g++ -O2 -o cap_methyl cap_methyl.cpp

cp cap_methyl ..
chmod a+rx ../cap_methyl

