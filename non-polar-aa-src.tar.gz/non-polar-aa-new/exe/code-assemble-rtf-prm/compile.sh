#!/bin/bash

g++ -O2 -o assemble_rtf_prm assemble-rtf-prm.cpp ff.cpp 

cp assemble_rtf_prm ..
chmod g+rx ../assemble_rtf_prm
