#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE	(2048)
#define MAX_LEN		(256)
#define MAX_ATM_TYPE	(256)
#define MAX_ATOM	(256)
#define MAX_MEMBER	(128)

#define TYPE_ID_OFFSET	(300)
//char szExtName[]="__";
char szExtName[]="_";
char szExtAtomName[]="_";

char szTxtPrm[MAX_LINE][MAX_LEN];
char szTxtRtf[MAX_LINE][MAX_LEN];
int nLine_Rtf;
char szRtfFile[MAX_LEN];
char szPrmFile[MAX_LEN];

int GroupMember[MAX_ATOM], MemberList[MAX_ATOM][MAX_MEMBER];

void Add_Tip3_Rtf_File(void);
void Add_Tip3_Prm_File(void);
void To_Upper_Case(char szBuff[]);
int FindString(char szBuff[], const char szTag[]);
int Is_Atom_in_Water(char szName[]);
void From_Old_Name_To_New_Name(char OldName[], char NewName[]);

//start	data for one line
int nItem_Line;
char szItemLine[64][128];
//end	data for one line

int Split_Str_One_Line(char szBuff[]);

typedef struct	{
	int idx;
	char Name[16];
	char NewName[16];
	double mass;
}ATOM_TYPE, *PATOM_TYPE;

typedef struct	{
	char Name[16];
	char NewName[16];
	char type[16];
	int type_id;
	double cg;
}ATOM_INFO, *PATOM_INFO;


ATOM_TYPE Atm_List[MAX_ATM_TYPE];
int n_Atom_Type;

char szAtomName[MAX_ATOM];
int Atom_Fisrt, Atom_Last;
ATOM_INFO Mol[MAX_ATOM];
int nAtom, BondCount[MAX_ATOM], BondList[MAX_ATOM][4];
double mass[MAX_ATOM];

int n_Line;

int QueryAtomType(char szAtomName[]);

int QueryAtomIndex(char szAtomName[]);


int main(int argc, char *argv[])
{
	if(argc != 3)	{
		printf("Usage: reformat your-rtf your-prm\nQuit\n");
		return 1;
	}

	strcpy(szRtfFile, argv[1]);
	strcpy(szPrmFile, argv[2]);

	Add_Tip3_Rtf_File();

	Add_Tip3_Prm_File();


	return 0;
}

void Add_Tip3_Prm_File(void)
{
	FILE *fOut;
	char *ReadLine, Atom_1[64], Atom_2[64], Atom_3[64], Atom_4[64], szPrmFile_New[256];
	char New_Atom_1[64], New_Atom_2[64], New_Atom_3[64], New_Atom_4[64];
	int ReadItem, Phi_Order;
	int i, Bond_Begin, Bond_End, Angle_Begin, Angle_End, Dihedral_Begin, Dihedral_End, Improper_Begin, Improper_End, LJ_Begin, LJ_End;
	double k, b0, theta0, phi, fTmp, E_Min, r_Min, E_Min_14, r_Min_14;

	fOut = fopen(szPrmFile, "r");
	if(fOut == NULL)	{
		printf("Error in open file: %s\nQuit\n", szPrmFile);
		exit(1);
	}
	else	{
		n_Line = 0;

		while(1)	{
			if(feof(fOut))	{
				break;
			}
			ReadLine = fgets(szTxtPrm[n_Line], MAX_LEN, fOut);
			To_Upper_Case(szTxtPrm[n_Line]);
			if(ReadLine == NULL)	{
				break;
			}
			else	{
				if(strncmp(szTxtPrm[n_Line], "BONDS", 5)==0)	{
					Bond_Begin = n_Line + 1;
				}
				else if(strncmp(szTxtPrm[n_Line], "ANGLES", 6)==0)	{
					Bond_End = n_Line - 1;
					Angle_Begin = n_Line + 1;
				}
				else if(strncmp(szTxtPrm[n_Line], "DIHEDRALS", 9)==0)	{
					Angle_End = n_Line - 1;
					Dihedral_Begin = n_Line + 1;
				}
				else if(strncmp(szTxtPrm[n_Line], "IMPROPERS", 9)==0)	{
					Dihedral_End = n_Line - 1;
					Improper_Begin = n_Line + 1;
				}
				else if(strncmp(szTxtPrm[n_Line], "NONBONDED", 9)==0)	{
					Improper_End = n_Line - 1;
					LJ_Begin = n_Line + 1;
				}

				n_Line++;
				if(n_Line >= MAX_LINE)	{
					printf("n_Line >= MAX_LINE\nQuit\n");
					fclose(fOut);
					exit(1);
				}
			}
		}
		LJ_End = n_Line-1;
		fclose(fOut);
	}

	for(i=Bond_Begin; i<=Bond_End; i++)	{
		ReadItem = sscanf(szTxtPrm[i], "%s %s %lf %lf", Atom_1, Atom_2, &k, &b0);
		if(ReadItem == 4)	{
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			From_Old_Name_To_New_Name(Atom_2, New_Atom_2);
			sprintf(szTxtPrm[i], "%-5s %-5s  %8.3lf %7.3lf\n", New_Atom_1, New_Atom_2, k, b0);
		}
	}


	for(i=Angle_Begin; i<=Angle_End; i++)	{
		ReadItem = sscanf(szTxtPrm[i], "%s %s %s %lf %lf", Atom_1, Atom_2, Atom_3, &k, &theta0);
		if(ReadItem == 5)	{
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			From_Old_Name_To_New_Name(Atom_2, New_Atom_2);
			From_Old_Name_To_New_Name(Atom_3, New_Atom_3);
			sprintf(szTxtPrm[i], "%-5s %-5s %-5s  %8.3lf %12.3lf\n", New_Atom_1, New_Atom_2, New_Atom_3, k, theta0);
		}
	}


	for(i=Dihedral_Begin; i<=Dihedral_End; i++)	{
		ReadItem = sscanf(szTxtPrm[i], "%s %s %s %s %lf %d %lf", Atom_1, Atom_2, Atom_3, Atom_4, &k, &Phi_Order, &phi);
		if(ReadItem == 7)	{
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			From_Old_Name_To_New_Name(Atom_2, New_Atom_2);
			From_Old_Name_To_New_Name(Atom_3, New_Atom_3);
			From_Old_Name_To_New_Name(Atom_4, New_Atom_4);
			sprintf(szTxtPrm[i], "%-5s %-5s %-5s %-5s  %7.3lf %3d %9.1lf\n", New_Atom_1, New_Atom_2, New_Atom_3, New_Atom_4, k, Phi_Order, phi);
		}
	}

	for(i=Improper_Begin; i<=Improper_End; i++)	{
		ReadItem = sscanf(szTxtPrm[i], "%s %s %s %s %lf %d %lf", Atom_1, Atom_2, Atom_3, Atom_4, &k, &Phi_Order, &phi);
		if(ReadItem == 7)	{
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			From_Old_Name_To_New_Name(Atom_2, New_Atom_2);
			From_Old_Name_To_New_Name(Atom_3, New_Atom_3);
			From_Old_Name_To_New_Name(Atom_4, New_Atom_4);
			sprintf(szTxtPrm[i], "%-5s %-5s %-5s %-5s  %7.3lf %3d %9.1lf\n", New_Atom_1, New_Atom_2, New_Atom_3, New_Atom_4, k, Phi_Order, phi);
		}
	}

	for(i=LJ_Begin; i<=LJ_End; i++)	{
		ReadItem = sscanf(szTxtPrm[i], "%s %lf %lf %lf %lf %lf %lf", Atom_1, &fTmp, &E_Min, &r_Min, &fTmp, &E_Min_14, &r_Min_14);
		if(ReadItem == 7)	{
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			sprintf(szTxtPrm[i], "%-5s   0.00 %9.4lf %9.4lf     0.00 %9.4lf %9.4lf\n", 
				New_Atom_1, E_Min, r_Min, E_Min_14, r_Min_14);
		}
		else if(ReadItem == 4)	{	// no 14 parameters
			From_Old_Name_To_New_Name(Atom_1, New_Atom_1);
			sprintf(szTxtPrm[i], "%-5s   0.00 %9.4lf %9.4lf\n", 
				New_Atom_1, E_Min, r_Min);
		}
	}


	sprintf(szPrmFile_New, "new-%s", szPrmFile);
	fOut = fopen(szPrmFile_New, "w");
	for(i=0; i<n_Line; i++)	{
		fprintf(fOut, "%s", szTxtPrm[i]);
	}
	fclose(fOut);
}


void Add_Tip3_Rtf_File(void)
{
	FILE *fOut;
	char *ReadLine, szLine[256], szTmp[256], szAtom_1[256], szAtom_2[256], szRtfFile_New[256];
	int i, j, k, ReadItem, Atom_1, Atom_2, Begin_TIP3_Entry=0, ToSave, Last_Line_Mass, Last_Line_Atom=100000, nItem, FirstRes=1;
	double fTmp=0.0;

	fOut = fopen(szRtfFile, "r");
	if(fOut == NULL)	{
		printf("Error in open file: %s\nQuit\n", szRtfFile);
		exit(1);
	}

	nLine_Rtf = 0;
	n_Atom_Type = 0;
	nAtom = 0;

	while(1)	{
		if(feof(fOut))	{
			break;
		}
		ReadLine = fgets(szLine, 256, fOut);
		if(ReadLine == NULL)	{
			break;
		}
		To_Upper_Case(szLine);

		ToSave = 1;	// to save into szTxtRtf[]
		
		if(Begin_TIP3_Entry==0)	{
			if(strncmp(szLine, "RESI TIP3", 9)==0)	{
				Begin_TIP3_Entry = 1;
			}
			else if(strncmp(szLine, "RESI SWM4", 9)==0)	{
				Begin_TIP3_Entry = 1;
			}
			else if(strncmp(szLine, "MASS", 4)==0)	{
				ReadItem = sscanf(szLine, "%s %d %s %lf", szTmp, &(Atm_List[n_Atom_Type].idx), Atm_List[n_Atom_Type].Name, &(Atm_List[n_Atom_Type].mass));
				if(ReadItem == 4)	{
					if(nLine_Rtf < Last_Line_Atom)	{
						ToSave = 0;
						n_Atom_Type++;
						Last_Line_Mass = nLine_Rtf;
					}
				}
			}
			else if(strncmp(szLine, "ATOM", 4)==0)	{
				ReadItem = sscanf(szLine, "%s %s %s %lf", szTmp, Mol[nAtom].Name, Mol[nAtom].type, &(Mol[nAtom].cg));
				if(ReadItem == 4)	{
					ToSave = 0;
					Mol[nAtom].type_id = QueryAtomType(Mol[nAtom].type);
					nAtom++;
					Last_Line_Atom = nLine_Rtf;
				}
			}
			else if(strncmp(szLine, "BOND", 4)==0)	{
				ReadItem = sscanf(szLine, "%s %s %s", szTmp, szAtom_1, szAtom_2);
				if(ReadItem == 3)	{
					Atom_1 = QueryAtomIndex(szAtom_1);
					Atom_2 = QueryAtomIndex(szAtom_2);
					BondList[Atom_1][BondCount[Atom_1]] = Atom_2;
					BondCount[Atom_1] ++;
					BondList[Atom_2][BondCount[Atom_2]] = Atom_1;
					BondCount[Atom_2] ++;
				}
			}
			else if(strncmp(szLine, "GROUP", 5)==0)	{
				ToSave = 0;
			}
		}

		if(ToSave)	{
			strcpy(szTxtRtf[nLine_Rtf], szLine);
			nLine_Rtf++;
		}
	}
	fclose(fOut);

	//start	to organize the group information. Any heavy atom together the hydrogen or lone pair connected form a group
	memset(GroupMember, 0, sizeof(int)*MAX_ATOM);
	memset(MemberList, 0, sizeof(int)*MAX_ATOM*MAX_MEMBER);

	for(i=0; i<nAtom; i++)	{
		MemberList[0][i] = i;
	}
	GroupMember[0] = nAtom;


/*
	for(i=0; i<nAtom; i++)	{
		if(Atm_List[Mol[i].type_id].mass > 1.5)	{	// a heavy atom
			MemberList[i][GroupMember[i]] = i;
			GroupMember[i]++;
			for(j=0; j<BondCount[i]; j++)	{
				if(Atm_List[Mol[BondList[i][j]].type_id].mass < 1.5)	{	// H atom or lone pair
					MemberList[i][GroupMember[i]] = BondList[i][j];
					GroupMember[i]++;
				}
			}
		}
	}
*/
	//end	to organize the group information. Any heavy atom together the hydrogen or lone pair connected form a group

	for(j=0; j<n_Atom_Type; j++)	{
		sprintf(Atm_List[j].NewName, "%s%s", Atm_List[j].Name, szExtName);
	}
	for(j=0; j<nAtom; j++)	{
		strcpy(Mol[j].type, Atm_List[Mol[j].type_id].NewName);	// new Chem name !
		sprintf(Mol[j].NewName, "%s%s", Mol[j].Name, szExtAtomName);	// new atom name !
	}


	sprintf(szRtfFile_New, "new-%s", szRtfFile);
	fOut = fopen(szRtfFile_New, "w");
	for(i=0; i<nLine_Rtf; i++)	{
		if(i==Last_Line_Mass)	{
			for(j=0; j<n_Atom_Type; j++)	{
				fprintf(fOut, "MASS %5d %-6s%10.6lf\n", Atm_List[j].idx+TYPE_ID_OFFSET, Atm_List[j].NewName, Atm_List[j].mass);
			}
		}
		else if(i==Last_Line_Atom)	{
			for(j=0; j<nAtom; j++)	{
				if(GroupMember[j] > 0)	{	// a new group
					fprintf(fOut, "GROUP\n");
					for(k=0; k<GroupMember[j]; k++)	{
//						fprintf(fOut, "ATOM %-6s%-6s%10.6lf\n", Mol[MemberList[j][k]].Name, Mol[MemberList[j][k]].type, Mol[MemberList[j][k]].cg);
						fprintf(fOut, "ATOM %-6s%-6s%7.3lf\n", Mol[MemberList[j][k]].NewName, Mol[MemberList[j][k]].type, Mol[MemberList[j][k]].cg);
					}
				}
			}
		}
		if(strncmp(szTxtRtf[i], "RESI TIP3", 9)==0)	{
			FirstRes = 0;
		}
		if(FirstRes)	{
			if(strncmp(szTxtRtf[i], "BOND", 4)==0)	{
				nItem = Split_Str_One_Line(szTxtRtf[i]);
				if(nItem >= 3)	{
					sprintf(szTxtRtf[i], "BOND %-6s%-6s\n", Mol[QueryAtomIndex(szItemLine[1])].NewName, Mol[QueryAtomIndex(szItemLine[2])].NewName);
				}
			}
			else if(strncmp(szTxtRtf[i], "ANGL", 4)==0)	{
				nItem = Split_Str_One_Line(szTxtRtf[i]);
				if(nItem >= 4)	{
					sprintf(szTxtRtf[i], "ANGL %-6s%-6s%-6s\n", 
						Mol[QueryAtomIndex(szItemLine[1])].NewName, Mol[QueryAtomIndex(szItemLine[2])].NewName, Mol[QueryAtomIndex(szItemLine[3])].NewName);
				}
			}
			else if(strncmp(szTxtRtf[i], "DIHE", 4)==0)	{
				nItem = Split_Str_One_Line(szTxtRtf[i]);
				if(nItem >= 5)	{
					sprintf(szTxtRtf[i], "DIHE %-6s%-6s%-6s%-6s\n", 
						Mol[QueryAtomIndex(szItemLine[1])].NewName, Mol[QueryAtomIndex(szItemLine[2])].NewName, Mol[QueryAtomIndex(szItemLine[3])].NewName, Mol[QueryAtomIndex(szItemLine[4])].NewName);
				}
			}
			else if(strncmp(szTxtRtf[i], "IMPH", 4)==0)	{
				nItem = Split_Str_One_Line(szTxtRtf[i]);
				if(nItem >= 5)	{
					sprintf(szTxtRtf[i], "IMPH %-6s%-6s%-6s%-6s\n", 
						Mol[QueryAtomIndex(szItemLine[1])].NewName, Mol[QueryAtomIndex(szItemLine[2])].NewName, Mol[QueryAtomIndex(szItemLine[3])].NewName, Mol[QueryAtomIndex(szItemLine[4])].NewName);
				}
			}
		}
		fprintf(fOut, "%s", szTxtRtf[i]);
	}
	fclose(fOut);
}

void To_Upper_Case(char szBuff[])
{
	char gap;
	int i=0;

	gap = 'A'-'a';

	while(1)	{
		if(szBuff[i]==0)	{
			break;
		}
		if( (szBuff[i]>='a') && (szBuff[i]<='z') )	{
			szBuff[i] += gap;
		}
		i++;
	}
}

int FindString(char szBuff[], const char szTag[])
{
	int Len_Buff, Len_Tag, iPos, iPos_Max;

	Len_Tag = strlen(szTag);
	Len_Buff = strlen(szBuff);

	iPos_Max = Len_Buff-Len_Tag;

	for(iPos=0; iPos<iPos_Max; iPos++)	{
		if(strncmp(szBuff+iPos, szTag, Len_Tag) == 0)	{
			return iPos;
		}
	}
	return (-1);
}

int QueryAtomIndex(char szAtomName[])
{
	int i;

	for(i=0; i<nAtom; i++)	{
		if(strcmp(szAtomName, Mol[i].Name)==0)	{
			return i;
		}
	}
	printf("Fail to find the index of atom: %s\nQuit\n", szAtomName);
	exit(1);

	return -1;
}

int QueryAtomType(char szTypeName[])
{
	int i;

	for(i=0; i<n_Atom_Type; i++)	{
		if(strcmp(szTypeName, Atm_List[i].Name)==0)	{
			return i;
		}
	}
	printf("Fail to find the type of atom: %s\nQuit\n", szTypeName);
	exit(1);

	return -1;
}


int Is_Atom_in_Water(char szName[])
{
	if(strcmp(szName, "HT_W")==0)	{
		return 1;
	}
	else if(strcmp(szName, "OT_W")==0)	{
		return 1;
	}

	// to add for drude model


	return 0;
}

void From_Old_Name_To_New_Name(char OldName[], char NewName[])
{
	int TypeID;

	if(strcmp(OldName, "X")==0)	{
		strcpy(NewName, OldName);
	}
	else if(Is_Atom_in_Water(OldName))	{
		strcpy(NewName, OldName);
	}
	else	{
		TypeID = QueryAtomType(OldName);
		strcpy(NewName, Atm_List[TypeID].NewName);
	}
	return;
}


int Split_Str_One_Line(char szBuff[])
{
	int iLen, iPos, iPos_End, CountChange=0, iLen_Atom_Name;
	char c, szBak[256];

	nItem_Line = 0;

	iLen = strlen(szBuff);
	strcpy(szBak, szBuff);

	iPos = 0;
	while(1)	{
		while(1)	{	// to find the beginning of a string
			c = szBuff[iPos];
			if( (c != 0xA) && (c != 0xD) && (c != 0x20)  && (c != '\t') && (c != 0) )	{
				break;
			}
			iPos++;
			if(iPos >= iLen)	{
				break;
			}
		}
		if(iPos >= iLen)	{
			break;
		}

		iPos_End = iPos;
		while(1)	{	// to find the end of a string
			c = szBuff[iPos_End];
			if( (c == 0xA) || (c == 0xD) || (c == 0x20)  || (c == '\t') || (c == 0) )	{
				break;
			}
			iPos_End++;
			if(iPos >= iLen)	{
				break;
			}
		}

		iLen_Atom_Name = iPos_End-iPos;
		memcpy(szItemLine[nItem_Line], szBuff+iPos, iLen_Atom_Name);
		szItemLine[nItem_Line][iLen_Atom_Name] = 0;	// end
		nItem_Line++;


		iPos = iPos_End;
	}

	return nItem_Line;
}

