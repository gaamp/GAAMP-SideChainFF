#!/bin/bash

g++ -O2 -o extract-aa-ff extract-rtf-prm.cpp 

cp extract-aa-ff ..
chmod g+rx ../extract-aa-ff

