#!/bin/bash


#mpicxx -O3 -o qm-1d-scan_para QM_1D_scan.cpp ff.cpp ../../opt/nlopt-2.4.2/.libs/libnlopt.a 
mpicxx -O3 -o qm-1d-scan_para QM_1D_scan_mpp.cpp ff.cpp ../../opt/nlopt-2.4.2/.libs/libnlopt.a 

cp qm-1d-scan_para ..
chmod g+rx ../qm-1d-scan_para
